/**
 * Geometry-first PDF structure reconstruction. No DOM, network, or translation calls.
 * `bbox` is always original PDF user space; `rect` is unscaled visual top-left space.
 * Every paragraph retains its physical lines and original spans for tracing/selection.
 */
import {normalizeText,joinSpans,joinLineFragments,collectWordEvidence} from './text-reflow.js';
import {studyLayout,prepareStudySpans,studyLineRole,cleanArticleText} from './study-layout.js';

export const STRUCTURE_VERSION=4;
const median=values=>{const v=values.filter(Number.isFinite).sort((a,b)=>a-b);return v.length?v[Math.floor(v.length/2)]:0;};
const quantile=(values,q)=>{const v=[...values].sort((a,b)=>a-b);return v.length?v[Math.min(v.length-1,Math.floor((v.length-1)*q))]:0;};
const union=rects=>[Math.min(...rects.map(r=>r[0])),Math.min(...rects.map(r=>r[1])),Math.max(...rects.map(r=>r[2])),Math.max(...rects.map(r=>r[3]))];
const width=r=>r[2]-r[0],height=r=>r[3]-r[1];
const point=(m,x,y)=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]];
const rectFromPoints=points=>[Math.min(...points.map(p=>p[0])),Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[0])),Math.max(...points.map(p=>p[1]))];
const multiply=(a,b)=>[a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];
const decorative=new Set(['header','footer','page_number']);
const special=new Set(['title','subtitle','heading','caption','formula','table_row','rotated']);
const section=/^(?:(?:\d+(?:\.\d+)*|[IVX]+)[.)]?\s+)?(?:abstract|introduction|background|methods?|materials(?:\s+and\s+methods)?|results?|discussion|conclusions?|limitations?|acknowledg(?:e)?ments?|references|bibliography|supplementary\s+(?:material|information))\s*[:.]?$/i;
const referenceStart=/^(?:\[\d+\]|\d+[.)]\s+|[A-Z][\p{L}'’-]+,\s+[A-Z])/u;
const listStart=/^(?:[•●▪◦‣–—]\s*|[-*]\s+|\(?[a-zA-Z\d]{1,3}[.)]\s+)/;

function weightedMode(values,tolerance=.5){
  const buckets=new Map();
  for(const [value,weight] of values){const key=Math.round(value/tolerance)*tolerance;buckets.set(key,(buckets.get(key)||0)+weight);}
  return [...buckets].sort((a,b)=>b[1]-a[1] || a[0]-b[0])[0]?.[0] || 11;
}

function makeSpans(items,styles,transform,pageNumber,source){
  return items.flatMap((item,itemIndex)=>{
    if(typeof item.str!=='string' || !item.str.length || !item.transform?.every(Number.isFinite))return [];
    const t=item.transform,style=styles[item.fontName] || {};
    const size=Math.hypot(t[2],t[3]) || Math.abs(item.height) || Math.hypot(t[0],t[1]) || 11;
    const advance=Math.hypot(t[0],t[1]) || size,ux=t[0]/advance,uy=t[1]/advance;
    const ascent=Number.isFinite(style.ascent)?style.ascent:.8,descent=Number.isFinite(style.descent)?style.descent:-.2;
    const spanWidth=Math.abs(item.width || 0),base=[t[4],t[5]];
    const quad=[[base[0]+t[2]*descent,base[1]+t[3]*descent],
      [base[0]+ux*spanWidth+t[2]*descent,base[1]+uy*spanWidth+t[3]*descent],
      [base[0]+ux*spanWidth+t[2]*ascent,base[1]+uy*spanWidth+t[3]*ascent],
      [base[0]+t[2]*ascent,base[1]+t[3]*ascent]];
    const baseline=point(transform,...base),end=point(transform,base[0]+ux,base[1]+uy);
    const angle=Math.atan2(end[1]-baseline[1],end[0]-baseline[0])*180/Math.PI;
    return [{id:`p${pageNumber}-${source}-s${itemIndex}`,pageNumber,itemIndex,rawText:item.str,text:normalizeText(item.str),
      bbox:rectFromPoints(quad),rect:rectFromPoints(quad.map(p=>point(transform,...p))),baseline:baseline[1],
      fontSize:size,fontName:item.fontName || '',fontFamily:style.fontFamily || '',
      bold:!!style.bold || /bold|black|heavy/i.test((style.fontFamily || '')+' '+(item.fontName || '')),
      italic:!!style.italic || /italic|oblique/i.test((style.fontFamily || '')+' '+(item.fontName || '')),
      angle,hasEOL:!!item.hasEOL,source,confidence:item.ocr?.confidence ?? null,
      original:{transform:[...t],width:item.width,height:item.height,dir:item.dir || 'ltr',...(item.ocr?{ocr:{...item.ocr}}:{})}}];
  });
}

function groupRows(spans,bodySize){
  const rows=[];
  for(const span of [...spans].sort((a,b)=>a.baseline-b.baseline || a.rect[0]-b.rect[0])){
    if(!span.text)continue;
    let row=null;
    // Look only at nearby baselines; superscripts are attached in a separate pass.
    for(let n=rows.length-1;n>=0;n--){
      const candidate=rows[n];if(span.baseline-candidate.baseline>bodySize*.55)break;
      if(Math.abs(candidate.baseline-span.baseline)<=Math.max(1.2,Math.min(candidate.fontSize,span.fontSize)*.23)){row=candidate;break;}
    }
    if(row){row.spans.push(span);row.fontSize=Math.max(row.fontSize,span.fontSize);}
    else rows.push({baseline:span.baseline,fontSize:span.fontSize,spans:[span]});
  }
  for(const row of [...rows]){
    if(row.fontSize>=bodySize*.82)continue;
    const near=rows.filter(r=>r!==row && r.fontSize>row.fontSize*1.2 && Math.abs(r.baseline-row.baseline)<bodySize*.8)
      .find(r=>row.spans.every(s=>r.spans.some(t=>s.rect[0]<=t.rect[2]+bodySize*.6 && s.rect[2]>=t.rect[0]-bodySize*.6)));
    if(near){near.spans.push(...row.spans);rows.splice(rows.indexOf(row),1);}
  }
  return rows.sort((a,b)=>a.baseline-b.baseline);
}

function rowRuns(row,bodySize,pageWidth){
  const result=[];let group=[];
  const flush=()=>{if(group.length)result.push(group);group=[];};
  for(const span of [...row.spans].sort((a,b)=>a.rect[0]-b.rect[0])){
    const right=group.length?Math.max(...group.map(s=>s.rect[2])):0;
    if(group.length && span.rect[0]-right>Math.max(bodySize*1.1,pageWidth*.018))flush();
    group.push(span);
  }
  flush();return result;
}

function makeLine(spans,pageNumber){
  spans.sort((a,b)=>a.rect[0]-b.rect[0] || b.fontSize-a.fontSize);
  const bbox=union(spans.map(s=>s.bbox)),rect=union(spans.map(s=>s.rect));
  const fontSize=weightedMode(spans.map(s=>[s.fontSize,Math.max(1,s.text.length)]));
  return {id:`p${pageNumber}-l${Math.min(...spans.map(s=>s.itemIndex))}`,pageNumber,
    text:joinSpans(spans),rawText:spans.map(s=>s.rawText).join(''),spanIds:spans.map(s=>s.id),
    itemIndices:spans.map(s=>s.itemIndex),indices:spans.map(s=>s.itemIndex),bbox,rect,
    x:bbox[0],y:bbox[1],width:width(bbox),height:height(bbox),fontSize,
    baseline:median(spans.filter(s=>s.fontSize>=fontSize*.9).map(s=>s.baseline)),
    fontNames:[...new Set(spans.map(s=>s.fontName))],bold:spans.filter(s=>s.bold).reduce((n,s)=>n+s.text.length,0)>spans.reduce((n,s)=>n+s.text.length,0)*.65,
    angle:median(spans.map(s=>s.angle)),kind:'body',column:0,zone:0};
}

function detectColumns(runs,pageWidth,pageHeight,bodySize,mode){
  if(mode==='single')return {count:1,gutter:null,confidence:'manual'};
  const fallback=mode==='double'?{count:2,gutter:pageWidth/2,confidence:'manual'}:{count:1,gutter:null,confidence:'limited-evidence'};
  const candidates=runs.filter(l=>l.fontSize<=bodySize*1.9 && l.rect[1]>pageHeight*.055 && l.rect[3]<pageHeight*.94);
  if(candidates.length<6)return fallback;
  let best=null;
  for(let x=pageWidth*.28;x<=pageWidth*.72;x+=Math.max(2,pageWidth/160)){
    const left=candidates.filter(l=>l.rect[2]<=x-bodySize*.35);
    const right=candidates.filter(l=>l.rect[0]>=x+bodySize*.35);
    const wideLeft=left.filter(l=>width(l.rect)>pageWidth*.21),wideRight=right.filter(l=>width(l.rect)>pageWidth*.21);
    if(wideLeft.length<3 || wideRight.length<3)continue;
    const pairs=wideLeft.filter(l=>wideRight.some(r=>Math.abs(r.baseline-l.baseline)<=bodySize*1.4)).length;
    if(pairs<3)continue;
    const leftEdge=quantile(left.map(l=>l.rect[2]),.9),rightEdge=quantile(right.map(l=>l.rect[0]),.1);
    const gap=rightEdge-leftEdge;
    if(gap<bodySize*.7)continue;
    // Full-width abstract/title lines are evidence of another zone, not a veto.
    const crossing=candidates.length-left.length-right.length;
    const score=pairs*4+Math.min(wideLeft.length,wideRight.length)*2-Math.abs(left.length-right.length)*.4-crossing*.3+Math.min(gap/bodySize,5);
    if(!best || score>best.score)best={score,gutter:(leftEdge+rightEdge)/2,pairs};
  }
  return best?{count:2,gutter:best.gutter,confidence:mode==='double'?'manual':'supported',pairedLines:best.pairs}:fallback;
}

function assignKinds(lines,defaultSize,pageWidth,pageHeight){
  const sizes=new Map();
  for(const column of new Set(lines.map(l=>l.column))){
    const candidates=lines.filter(l=>l.column===column && l.rect[1]>pageHeight*.07 && l.rect[3]<pageHeight*.9);
    sizes.set(column,candidates.length?weightedMode(candidates.map(l=>[l.fontSize,l.text.length])):defaultSize);
  }
  for(const line of [...lines].sort((a,b)=>a.rect[1]-b.rect[1] || a.rect[0]-b.rect[0])){
    const bodySize=sizes.get(line.column) || defaultSize;line.typicalFontSize=bodySize;
    const text=line.text,short=text.length<115,top=line.rect[1],bottom=line.rect[3];
    if(Math.abs(line.angle)>12 && Math.abs(Math.abs(line.angle)-180)>12){line.kind='rotated';continue;}
    if(/^[-–—]?\s*(?:\d{1,5}|[ivxlcdm]{1,8})\s*[-–—]?$/i.test(text) && (top<pageHeight*.045 || bottom>pageHeight*.94)){line.kind='page_number';continue;}
    if(top<pageHeight*.055 && line.fontSize<bodySize*.94 && short){line.kind='header';continue;}
    if(bottom>pageHeight*.94 && short && /copyright|©|downloaded|www\.|https?:|all rights reserved|doi:/i.test(text)){line.kind='footer';continue;}
    if(/^(?:figure|fig\.?|table|scheme)\s*\d+[.:\s]/i.test(text)){line.kind='caption';continue;}
    if(section.test(text)){line.kind='heading';continue;}
    if(line.fontSize>=bodySize*1.42 && top<pageHeight*.36 && short){line.kind='title';continue;}
    if(line.fontSize>bodySize*1.13 && short){line.kind=top<pageHeight*.25?'subtitle':'heading';continue;}
    if(line.fontSize<bodySize*.86 && top>pageHeight*.78){line.kind='footnote';continue;}
    const math=(text.match(/[=∑∫√≈≤≥±×²³αβγδλμσ]/g)||[]).length;
    if(text.length<100 && math>=1 && (math/Math.max(text.replace(/\s/g,'').length,1)>.13 || /^[\w\s()+−-]+\s*=/.test(text))){line.kind='formula';continue;}
    if(listStart.test(text))line.kind='list_item';
    else if(line.bold && text.length<85 && !/[.!?]$/.test(text))line.kind='heading';
  }
  const visual=[...lines].sort((a,b)=>a.baseline-b.baseline || a.rect[0]-b.rect[0]);
  for(let n=1;n<visual.length;n++){
    const line=visual[n],previous=visual[n-1];
    if(previous.kind==='caption' && line.kind==='body' && Math.abs(line.fontSize-previous.fontSize)<previous.fontSize*.08 &&
       line.baseline-previous.baseline<previous.fontSize*1.65 && Math.abs(line.rect[0]-previous.rect[0])<previous.fontSize*.4)line.kind='caption';
  }
}

function orderLines(lines,columns,regions,bodySize,pageWidth,pageHeight){
  if(columns.count===1)return [...lines].sort((a,b)=>a.baseline-b.baseline || a.rect[0]-b.rect[0]);
  const gutter=columns.gutter;
  for(const l of lines)l.column=l.rect[0]<gutter-bodySize*.4 && l.rect[2]>gutter+bodySize*.4?'span':((l.rect[0]+l.rect[2])/2<gutter?0:1);
  for(const line of lines.filter(l=>l.kind==='title' && l.column!=='span')){
    const parallel=lines.some(other=>other!==line && other.column!==line.column && other.column!=='span' &&
      Math.min(other.rect[3],line.rect[3])-Math.max(other.rect[1],line.rect[1])>Math.min(other.fontSize,line.fontSize)*.25);
    if(!parallel)line.column='span';
  }
  const visual=[...lines].sort((a,b)=>a.baseline-b.baseline || a.rect[0]-b.rect[0]);
  for(let n=1;n<visual.length;n++){
    const line=visual[n],previous=visual[n-1];
    const parallel=visual.some(other=>other!==line && other.column!==line.column && other.column!=='span' && Math.abs(other.baseline-line.baseline)<bodySize*.45);
    if(!parallel && previous.column==='span' && ['body','caption','title','subtitle'].includes(previous.kind) && line.kind===previous.kind &&
       Math.abs(line.fontSize-previous.fontSize)<bodySize*.15 && line.baseline-previous.baseline<previous.fontSize*1.65 &&
       Math.abs(line.rect[0]-previous.rect[0])<bodySize*.5)line.column='span';
  }
  const spanning=lines.filter(l=>l.column==='span').sort((a,b)=>a.baseline-b.baseline);
  const images=regions.filter(r=>r.kind==='image' && width(r.rect)>pageWidth*.65 && height(r.rect)<pageHeight*.7);
  const separators=[...spanning.map(line=>({top:line.rect[1],bottom:line.rect[3],line})),...images.map(region=>({top:region.rect[1],bottom:region.rect[3],region}))].sort((a,b)=>a.top-b.top);
  const ordered=[],seen=new Set();let zone=0;
  const addBand=limit=>{
    const band=lines.filter(l=>l.column!=='span' && !seen.has(l.id) && l.baseline<limit).sort((a,b)=>a.column-b.column || a.baseline-b.baseline || a.rect[0]-b.rect[0]);
    for(const l of band){l.zone=zone;ordered.push(l);seen.add(l.id);}
  };
  for(const separator of separators){
    addBand(separator.top+bodySize*.1);
    if(separator.line && !seen.has(separator.line.id)){separator.line.zone=zone;ordered.push(separator.line);seen.add(separator.line.id);}
    zone++;
  }
  addBand(Infinity);
  return ordered;
}

function flowMetrics(lines,bodySize){
  const ordinary=lines.filter(l=>!special.has(l.kind) && !decorative.has(l.kind));
  const source=ordinary.length?ordinary:lines;
  const left=weightedMode(source.map(l=>[l.rect[0],1]),Math.max(1,bodySize*.3));
  const right=quantile(source.map(l=>l.rect[2]),.85);
  const distances=[];
  for(let n=1;n<source.length;n++){
    const gap=source[n].baseline-source[n-1].baseline;
    if(gap>bodySize*.65 && gap<bodySize*(lines[0]?.role==='article'?4.5:2.3))distances.push([gap,1]);
  }
  const leading=distances.length?weightedMode(distances,Math.max(.8,bodySize*.12)):bodySize*1.3;
  return {left,right,width:Math.max(right-left,bodySize*8),leading};
}

function paragraphBoundary(previous,line,group,metrics,bodySize){
  const kind=group[0].kind,gap=line.baseline-previous.baseline;
  if(line.role!==previous.role)return 'content-role';
  if(line.editorialNumber)return 'numbered-paragraph';
  if(line.column!==previous.column || line.zone!==previous.zone && line.column!=='span')return 'column-or-zone';
  if(gap< -bodySize*.2)return 'reading-direction';
  if(decorative.has(kind) || decorative.has(line.kind))return 'decoration';
  const hanging=['list_item','reference','footnote'].includes(kind);
  const wrapsHanging=hanging && ['body',kind].includes(line.kind) && !listStart.test(line.text) && !referenceStart.test(line.text) && line.rect[0]>group[0].rect[0]+bodySize*.25;
  if(line.kind!==previous.kind && !wrapsHanging && !(hanging && line.kind==='body' && line.rect[0]>=group[0].rect[0]+bodySize*.25))return 'block-type';
  if(special.has(kind) || special.has(line.kind)){
    if(['title','subtitle','heading','caption'].includes(kind) && line.kind===kind && Math.abs(previous.fontSize-line.fontSize)<bodySize*.12 && gap<Math.max(previous.fontSize,line.fontSize)*1.65)return null;
    return 'semantic-block';
  }
  if(gap>metrics.leading*1.34+bodySize*.12)return 'paragraph-spacing';
  if(Math.abs(previous.fontSize-line.fontSize)>bodySize*.2)return 'font-size';
  if(line.kind==='list_item' || kind==='reference' && referenceStart.test(line.text))return 'new-item';
  const indented=line.rect[0]-metrics.left>Math.max(3,bodySize*.48);
  const dropCapWrap=group[0].dropCap && line.rect[1]<group[0].rect[3]+bodySize*.2;
  if(!dropCapWrap && !hanging && indented && line.rect[0]-previous.rect[0]>Math.max(3,bodySize*.48))return 'first-line-indent';
  const wrappedHyphen=/[-‐\u00ad]$/.test(previous.text);
  const priorShort=width(previous.rect)<metrics.width*.76;
  const currentAligned=Math.abs(line.rect[0]-metrics.left)<bodySize*.48;
  if(line.role!=='article' && !hanging && !wrappedHyphen && priorShort && currentAligned && group.length>=1)return 'short-ending-line';
  return null;
}

function paragraphsFromLines(ordered,bodySize,pageNumber){
  const words=collectWordEvidence(ordered.map(line=>line.text));
  const flows=new Map();
  const flowKey=line=>line.column+':'+(line.column==='span'?'shared':line.zone)+':'+(line.role || 'generic');
  for(const line of ordered){const key=flowKey(line);if(!flows.has(key))flows.set(key,[]);flows.get(key).push(line);}
  const metrics=new Map([...flows].map(([key,value])=>[key,flowMetrics(value,value[0]?.role==='article'?value[0].typicalFontSize:bodySize)]));
  const paragraphs=[];let group=[],reason='page-start';
  function flush(){
    if(!group.length)return;
    const repairs=[];let text='';
    for(const line of group){const joined=joinLineFragments(text,line.text,{words});text=joined.text;if(joined.repair)repairs.push({...joined.repair,lineId:line.id});}
    const bbox=union(group.map(l=>l.bbox)),rect=union(group.map(l=>l.rect));
    const clean=group[0].role==='article'?cleanArticleText(text):{text};
    paragraphs.push({id:`p${pageNumber}-para-${group[0].id.split('-l')[1]}`,pageNumber,kind:group[0].kind,...clean,
      rawText:group.map(l=>l.rawText).join('\n'),lineIds:group.map(l=>l.id),spanIds:group.flatMap(l=>l.spanIds),
      lines:[...group],itemIndices:group.flatMap(l=>l.itemIndices),bbox,rect,
      column:group[0].column,zone:group[0].zone,fontSize:group[0].fontSize,
      top:bbox[3],left:bbox[0],readingOrder:paragraphs.length,
      ...(group[0].role?{role:group[0].role,translatable:group[0].role==='article',editorialNumber:group[0].editorialNumber || null}:{}),
      isDecoration:decorative.has(group[0].kind) || group[0].role==='watermark',boundaryReason:reason,repairs});group=[];
  }
  for(const line of ordered){
    const key=flowKey(line);
    const boundary=group.length?paragraphBoundary(group.at(-1),line,group,metrics.get(key),line.role==='article'?line.typicalFontSize:bodySize):null;
    if(boundary){flush();reason=boundary;}
    group.push(line);
  }
  flush();return paragraphs;
}

/** @returns {object} Page: spans -> lines -> paragraphs -> blocks, with lossless source links. */
export function analyzePdfPage({items=[],styles={},width:pageWidth,height:pageHeight=pageWidth*1.4,pageNumber=1,mode='auto',transform,regions=[],source='pdf-text'}){
  if(!(pageWidth>0) || !(pageHeight>0))throw new RangeError('PDF page dimensions must be positive.');
  const matrix=transform || [1,0,0,-1,0,pageHeight];
  const spans=makeSpans(items,styles,matrix,pageNumber,source);
  const bodySize=weightedMode(spans.filter(s=>s.text).map(s=>[s.fontSize,Math.max(1,s.text.length)]));
  let rows=groupRows(spans,bodySize);const runs=rows.flatMap(r=>rowRuns(r,bodySize,pageWidth).map(s=>makeLine(s,pageNumber)));
  let columns=detectColumns(runs,pageWidth,pageHeight,bodySize,mode);
  // Semantic zoning uses the same independent evidence in every mode. A manual
  // column hint describes ordinary prose, not permission to mix article/notes.
  const classification=studyLayout(spans,regions,pageWidth,pageHeight,mode==='auto'?columns:detectColumns(runs,pageWidth,pageHeight,bodySize,'auto'));
  if(classification){
    prepareStudySpans(spans,classification,pageHeight);
    if(classification.kind==='annotated-article')columns={count:2,gutter:classification.gutter,confidence:classification.confidence};
    rows=[...new Set(spans.map(s=>s.role))].flatMap(role=>groupRows(spans.filter(s=>s.role===role),role==='article'?classification.bodySize:bodySize));
  }
  // Rejoin justified intra-line gaps after finding the gutter; never cross its seam.
  const lines=[];
  for(const row of rows){
    const pieces=rowRuns(row,bodySize,pageWidth).map(s=>({spans:s,line:makeLine(s,pageNumber)}));
    let groups=[];
    if(classification)groups=[row.spans];
    else if(columns.count===1)groups=[row.spans];
    else{
      const byColumn=new Map();
      for(const piece of pieces){
        const r=piece.line.rect,g=columns.gutter;
        const column=r[0]<g-bodySize*.4 && r[2]>g+bodySize*.4?'span':((r[0]+r[2])/2<g?0:1);
        if(!byColumn.has(column))byColumn.set(column,[]);byColumn.get(column).push(...piece.spans);
      }
      groups=[...byColumn.values()];
    }
    for(const group of groups)if(group.length){const line=makeLine(group,pageNumber);if(classification)line.role=group.find(s=>s.text)?.role;lines.push(line);}
  }
  // Whitespace spans remain traceable and attached to their nearest physical line.
  for(const span of spans.filter(s=>!s.text)){
    const distance=line=>Math.max(line.rect[0]-span.rect[2],span.rect[0]-line.rect[2],0);
    const nearest=lines.filter(l=>Math.abs(l.baseline-span.baseline)<bodySize*.4 && (!classification || l.role===span.role))
      .sort((a,b)=>distance(a)-distance(b))[0];
    if(nearest){nearest.itemIndices.push(span.itemIndex);nearest.spanIds.push(span.id);}
  }
  const spanMap=new Map(spans.map(span=>[span.id,span]));
  for(const line of lines){
    const originals=line.spanIds.map(id=>spanMap.get(id)).sort((a,b)=>a.rect[0]-b.rect[0] || a.itemIndex-b.itemIndex);
    line.itemIndices=originals.map(span=>span.itemIndex);line.indices=line.itemIndices;line.spanIds=originals.map(span=>span.id);
    line.rawText=originals.map(span=>span.rawText).join('');line.text=joinSpans(originals);
  }
  if(columns.count===2)for(const line of lines){const r=line.rect,g=columns.gutter;line.column=r[0]<g-bodySize*.4 && r[2]>g+bodySize*.4?'span':((r[0]+r[2])/2<g?0:1);}
  assignKinds(lines,bodySize,pageWidth,pageHeight);
  if(classification)for(const line of lines)studyLineRole(line,line.spanIds.map(id=>spanMap.get(id)),classification,pageHeight);
  const ordered=orderLines(lines,columns,regions,bodySize,pageWidth,pageHeight);
  let inReferences=false;
  for(const line of ordered){
    if(line.kind==='heading')inReferences=/references|bibliography/i.test(line.text);
    else if(inReferences && !decorative.has(line.kind) && !['formula','caption','rotated'].includes(line.kind)){
      if(line.kind!=='footnote' || referenceStart.test(line.text) || !/^(?:\d+|[*†‡])\s+/.test(line.text))line.kind='reference';
    }
  }
  ordered.forEach((l,n)=>l.readingOrder=n);
  const paragraphs=paragraphsFromLines(ordered,bodySize,pageNumber);
  const blocks=paragraphs.map(p=>({id:p.id+'-block',pageNumber,kind:p.kind,paragraphIds:[p.id],bbox:p.bbox,rect:p.rect,readingOrder:p.readingOrder}));
  for(const [index,region] of regions.filter(r=>r.kind!=='rule').entries()){
    const regionColumn=columns.count===1 || region.rect[0]<columns.gutter && region.rect[2]>columns.gutter?'span':((region.rect[0]+region.rect[2])/2<columns.gutter?0:1);
    let position=blocks.findIndex(block=>block.paragraphIds.length && block.rect[1]>=region.rect[3]-bodySize*.2 &&
      (regionColumn==='span' || paragraphs.find(p=>p.id===block.paragraphIds[0])?.column===regionColumn));
    if(position<0 && regionColumn===0)position=blocks.findIndex(block=>paragraphs.find(p=>p.id===block.paragraphIds[0])?.column===1);
    const value={...region,id:region.id || `p${pageNumber}-region-${index}`,pageNumber,paragraphIds:[]};
    if(classification?.kind==='annotated-article' && region.kind==='image'){
      const columnWidth=classification.gutter-classification.bodyLeft;
      if(width(region.rect)<columnWidth*.25 && region.rect[0]>classification.gutter-columnWidth*.25 && region.rect[3]<pageHeight*.14)value.role='metadata';
    }
    if(position<0)blocks.push(value);else blocks.splice(position,0,value);
  }
  blocks.forEach((block,n)=>{block.readingOrder=n;const p=paragraphs.find(p=>p.id===block.paragraphIds[0]);if(p)p.readingOrder=n;});
  const characterCount=paragraphs.filter(p=>!p.isDecoration).reduce((n,p)=>n+p.text.length,0);
  const largeImage=regions.some(r=>r.kind==='image' && width(r.rect)*height(r.rect)>pageWidth*pageHeight*.5);
  const textLayer=characterCount===0?'empty':(characterCount<40 && largeImage?'sparse':'usable');
  const warnings=[];
  if(mode!=='auto' && classification?.kind==='annotated-article')warnings.push({code:'semantic-column-boundary',message:'检测到明确的正文/词汇注释分区，已优先保留分区；手动单双栏仍适用于普通文献。'});
  const uncertain=paragraphs.flatMap(p=>p.repairs).filter(r=>r.kind==='ambiguous-line-hyphen').length;
  if(uncertain)warnings.push({code:'ambiguous-hyphen',count:uncertain,message:uncertain+' 处行尾连字符存在歧义，已保留。可在阅读结构的 repairs 中核对。'});
  if(textLayer!=='usable')warnings.push({code:'ocr-needed',message:'本页缺少足够的可用文字，请使用本页文字识别。'});
  if(lines.some(l=>l.kind==='rotated'))warnings.push({code:'rotated-text',message:'本页包含旋转文字，已保留其位置，阅读顺序可能需要手动核对。'});
  return {id:`page-${pageNumber}`,schemaVersion:STRUCTURE_VERSION,pageNumber,width:pageWidth,height:pageHeight,
    coordinateSpace:'pdf-user-space',visualTransform:[...matrix],source,textLayer,needsOcr:textLayer!=='usable',
    bodyFontSize:classification?.bodySize || bodySize,columns:columns.count,gutter:columns.gutter,columnEvidence:columns,classification,
    spans,lines:ordered,paragraphs,blocks,warnings};
}

/** Extract actual image bounds without copying image pixels or changing the PDF canvas. */
export function imageRegionsFromOperators(operatorList,ops,visualTransform){
  let matrix=[1,0,0,1,0,0];const stack=[],regions=[];
  for(let index=0;index<operatorList.fnArray.length;index++){
    const op=operatorList.fnArray[index],args=operatorList.argsArray[index] || [];
    if(op===ops.save)stack.push([...matrix]);
    else if(op===ops.restore)matrix=stack.pop() || [1,0,0,1,0,0];
    else if(op===ops.transform)matrix=multiply(matrix,args);
    else if(op===ops.paintFormXObjectBegin){stack.push([...matrix]);if(args[0])matrix=multiply(matrix,args[0]);}
    else if(op===ops.paintFormXObjectEnd)matrix=stack.pop() || matrix;
    else if(op===ops.paintImageXObject || op===ops.paintInlineImageXObject || op===ops.paintImageMaskXObject){
      const quad=[[0,0],[0,1],[1,0],[1,1]].map(p=>point(matrix,...p));
      regions.push({kind:'image',bbox:rectFromPoints(quad),rect:rectFromPoints(quad.map(p=>point(visualTransform,...p))),source:'pdf-operators',operatorIndex:index});
    }
  }
  return regions;
}

/** Thin painted rules are layout evidence, never fabricated text or table cells. */
export function layoutRegionsFromOperators(operatorList,ops,visualTransform){
  const regions=imageRegionsFromOperators(operatorList,ops,visualTransform);let matrix=[1,0,0,1,0,0];const stack=[];
  for(let i=0;i<operatorList.fnArray.length;i++){
    const op=operatorList.fnArray[i],args=operatorList.argsArray[i] || [];
    if(op===ops.save)stack.push([...matrix]);
    else if(op===ops.restore)matrix=stack.pop() || [1,0,0,1,0,0];
    else if(op===ops.transform)matrix=multiply(matrix,args);
    else if(op===ops.paintFormXObjectBegin){stack.push([...matrix]);if(args[0])matrix=multiply(matrix,args[0]);}
    else if(op===ops.paintFormXObjectEnd)matrix=stack.pop() || matrix;
    else if(op===ops.constructPath && args[2]?.length===4){
      const b=args[2];if(![...b].every(Number.isFinite))continue;
      const quad=[[b[0],b[1]],[b[0],b[3]],[b[2],b[1]],[b[2],b[3]]].map(p=>point(matrix,...p));
      const rect=rectFromPoints(quad.map(p=>point(visualTransform,...p)));
      if(width(rect)<=2.2 && height(rect)>=6 || height(rect)<=1.2 && width(rect)>=25)
        regions.push({kind:'rule',rect,bbox:rectFromPoints(quad),orientation:width(rect)<height(rect)?'vertical':'horizontal',source:'pdf-operators',operatorIndex:i});
    }
  }
  return regions;
}

function marginKey(p,page){
  const margin=p.rect[3]<page.height*.09?'top':p.rect[1]>page.height*.91?'bottom':null;
  if(!margin || p.lines.length!==1 || p.text.length>140 || !['body','header','footer'].includes(p.kind))return null;
  return margin+':'+p.text.toLowerCase().replace(/\d+/g,'#').replace(/\s+/g,' ').trim();
}

/** Sparse Document model: only supplied pages are parsed, safe for large documents. */
export function buildDocumentStructure({id='',name='',totalPages=0,pages=[]}){
  const ordered=[...pages].sort((a,b)=>a.pageNumber-b.pageNumber),margins=new Map();
  const words=collectWordEvidence(ordered.flatMap(page=>page.lines.map(line=>line.text)));
  for(const page of ordered)for(const p of page.paragraphs){const key=marginKey(p,page);if(key){if(!margins.has(key))margins.set(key,new Set());margins.get(key).add(page.pageNumber);}}
  const resultPages=ordered.map(page=>{const paragraphs=page.paragraphs.map(p=>{
    const key=marginKey(p,page);
    return key && margins.get(key).size>=2?{...p,kind:key.startsWith('top')?'header':'footer',isDecoration:true}:({...p});
  });
    const kinds=new Map(paragraphs.flatMap(p=>p.lineIds.map(id=>[id,p.kind])));
    const lines=page.lines.map(line=>({...line,kind:kinds.get(line.id) || line.kind})),lineMap=new Map(lines.map(line=>[line.id,line]));
    return {...page,lines,paragraphs:paragraphs.map(p=>({...p,lines:p.lineIds.map(id=>lineMap.get(id))})),
      blocks:page.blocks.map(b=>({...b,kind:paragraphs.find(p=>p.id===b.paragraphIds[0])?.kind || b.kind}))};
  });
  const logical=[];let previousArticle=null;
  for(const page of resultPages){
    const readable=page.paragraphs.filter(p=>!p.isDecoration);
    for(const p of readable){
      const annotated=p.role==='article';
      const prior=annotated?previousArticle:logical.at(-1),part=prior?.parts.at(-1),priorPage=resultPages.find(x=>x.pageNumber===part?.pageNumber);
      const first=annotated?p===readable.find(p=>p.role==='article'):p===readable[0];
      const canContinue=first && prior && prior.role===p.role && part.pageNumber+1===page.pageNumber && p.kind==='body' && prior.kind==='body' &&
        part.rect[3]>priorPage.height*(annotated?.52:.72) && p.rect[1]<page.height*.25 && !p.editorialNumber &&
        Math.abs(p.fontSize-prior.fontSize)<p.fontSize*.15 &&
        (!/[.!?。！？][”'"’)]?$/.test(prior.text) && /^[a-z]/.test(p.text) || /[-‐\u00ad]$/.test(prior.text)) &&
        Math.abs(p.lines[0].rect[0]-Math.min(...p.lines.map(l=>l.rect[0])))<p.fontSize*.4;
      const sourcePart={pageNumber:page.pageNumber,paragraphId:p.id,bbox:p.bbox,rect:p.rect,lineIds:p.lineIds};
      if(canContinue){
        const joined=joinLineFragments(prior.text,p.text,{words});prior.text=joined.text;prior.parts.push(sourcePart);
        prior.rawText+='\n\f\n'+p.rawText;p.continuationOf=prior.id;prior.continuesAcrossPages=true;
        if(joined.repair)prior.repairs.push({...joined.repair,pageNumber:page.pageNumber});
      }else logical.push({id:p.id,kind:p.kind,text:p.text,rawText:p.rawText,fontSize:p.fontSize,parts:[sourcePart],repairs:[...p.repairs],
        ...(p.role?{role:p.role,translatable:p.translatable}:{}),editorialNotes:p.editorialNotes || []});
      if(annotated)previousArticle=canContinue?prior:logical.at(-1);
    }
  }
  return {id,name,schemaVersion:STRUCTURE_VERSION,totalPages:totalPages || ordered.length,
    parsedPageNumbers:resultPages.map(p=>p.pageNumber),complete:resultPages.length===(totalPages || ordered.length),pages:resultPages,paragraphs:logical};
}
