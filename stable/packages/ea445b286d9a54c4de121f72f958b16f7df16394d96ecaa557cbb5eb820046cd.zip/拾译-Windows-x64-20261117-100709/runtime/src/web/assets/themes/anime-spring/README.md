# 春日花海 · 正式内置主题素材

background.png：用户在 2026-11-02 提供的独立插画，原样复制，校验和及尺寸见 manifest.json。
稳定 URL：/assets/themes/anime-spring/background.png。
参考界面图仅保存在 design/anime-theme-reference.png，未进入背景资源或正式打包范围。
现有 拾译.spec 递归收集 src/web，本资源将进入 runtime/src/web/assets/themes/anime-spring。
用户自行导入图片继续存放于用户数据目录 appearance/，不改写此内置资源。
ready 表示本地素材可用，不代表整体 UI 已获最终发布批准。
