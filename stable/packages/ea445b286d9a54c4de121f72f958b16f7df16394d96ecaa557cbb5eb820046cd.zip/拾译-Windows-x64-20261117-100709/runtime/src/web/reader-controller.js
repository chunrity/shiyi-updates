import {CompanionPanel} from './companion-panel.js';
/** Coordinates presentation, preferences and source navigation through explicit hooks. */
import {createReaderModel,modelFromManifest,createNavigationGate} from './reader-model.js';
import {BilingualReader} from './reader-view.js';
import {PdfFigureCache} from './reader-figures.js';

const $=selector=>document.querySelector(selector);
const escape=value=>String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export class ReaderController{
  constructor(hooks){
    this.hooks=hooks;this.docId='';this.mode='split';this.model={paragraphs:[],blocks:[],outline:[]};
    this.gate=createNavigationGate();this.restoreEpoch=0;this.preferenceEpoch=0;this.restored='';this.lookup=false;this.outline=[];this.selection=null;
    this.figures=new PdfFigureCache(page=>hooks.pdf().getPage(page));
    this.view=new BilingualReader($('#reader-surface'),{
      progress:anchor=>this.saveProgress(anchor),settings:values=>this.settings(values),
      locate:(id,options)=>{this.navigationIntent();this.activeId=id;this.hooks.active?.(id,options);},
      original:(id,page)=>this.locate(id,{page,original:true}),retry:id=>hooks.translate([id],true).catch(error=>hooks.toast(error.message,true)),
      copy:(id,format)=>this.copy(id,format),note:id=>this.note(id),figure:region=>hooks.pdf()?this.figures.get(region):null
    });
    this.companion=new CompanionPanel({workspace:$('.reading-workspace'),panel:$('.translation-panel'),handle:$('#companion-resizer'),recommend:$('#companion-recommend'),settings:()=>this.hooks.settings(),save:width=>this.settings({companionWidth:width}),error:()=>this.hooks.toast('阅读伴侣宽度未保存，请重试。',true)});
    document.addEventListener('click',event=>this.handleClick(event));
    document.addEventListener('keydown',event=>{
      if(event.key==='Escape'){$('#reader-selection-menu').classList.add('hidden');$('#reader-outline').classList.add('hidden');}
      if(event.altKey && !event.ctrlKey && ['1','2','3','4'].includes(event.key) && !event.target.closest('input,textarea')){
        event.preventDefault();this.setMode(['split','stacked','pdf','chinese'][Number(event.key)-1]).catch(error=>hooks.toast(error.message,true));
      }
    });
    $('#reader-mode').addEventListener('change',event=>this.setMode(event.target.value).catch(error=>hooks.toast(error.message,true)));
    $('#reader-sync').addEventListener('change',event=>this.settings({syncScroll:event.target.checked}).catch(error=>hooks.toast(error.message,true)));
    $('#reader-auto-locate').addEventListener('change',event=>this.settings({readerAutoLocate:event.target.checked}).catch(error=>hooks.toast(error.message,true)));
    for(const [id,key] of [['reader-en-size','readerEnglishSize'],['reader-zh-size','readerChineseSize'],['reader-width','readerWidth'],['reader-line-height','readerLineHeight'],['reader-font','readerFont']]){
      $('#'+id).addEventListener('change',event=>{
        const value=key==='readerFont'?event.target.value:Number(event.target.value);
        if(key!=='readerFont' && !Number.isFinite(value))return;
        const anchor=this.view.anchors()[this.view.visiblePane()];
        this.settings({[key]:value}).then(()=>requestAnimationFrame(()=>this.view.restore(anchor))).catch(error=>hooks.toast(error.message,true));
      });
    }
    document.addEventListener('pointerdown',event=>{
      if(!event.target.closest('#reader-selection-menu') && !event.target.closest('.reader-source-text,.textLayer'))$('#reader-selection-menu').classList.add('hidden');
      if(!event.target.closest('#reader-outline,[data-reader-action="outline"]'))$('#reader-outline').classList.add('hidden');
    });
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')this.flushProgress({keepalive:true});});
    window.addEventListener('pagehide',()=>this.flushProgress({keepalive:true}));
  }
  options(){const settings=this.hooks.settings();const value={source:settings.source || 'en',target:settings.target || 'zh-CN',provider:settings.provider || 'auto'};if(value.provider==='custom')value.model=settings.model || '';return value;}
  update(){
    const doc=this.hooks.document(),settings=this.hooks.settings(),structure=this.hooks.structure();
    this.companion.update();
    const changed=this.docId!==doc.id;
    if(changed){this.flushProgress();this.docId=doc.id;this.gate.cancel();this.restoreEpoch++;this.restored=this.restored===doc.id?doc.id:'';this.activeId='';this.figures.clear();this.outline=[];this.outlinePdf=null;this.selection=null;this.showLookup(false);$('#reader-selection-menu').classList.add('hidden');}
    if(this.hooks.pdf() && this.outlinePdf!==this.hooks.pdf()){this.outlinePdf=this.hooks.pdf();this.loadOutline(doc);}
    const source=structure || this.hooks.manifest(),rows=this.hooks.translations();
    const values=rows instanceof Map?[...rows.values()]:Array.isArray(rows)?rows:rows?.items || [];
    const options=this.options(),variant=JSON.stringify(options),prior=this.modelInput;
    const reusable=prior && prior.documentId===doc.id && prior.source===source && prior.page===doc.page && prior.variant===variant &&
      prior.values.length===values.length && values.every((value,index)=>value===prior.values[index]);
    const model=reusable?this.model:(structure?createReaderModel(structure,rows,{pageNumber:doc.page,options}):
      modelFromManifest(source,rows,{options}));
    this.modelInput={documentId:doc.id,source,page:doc.page,variant,values:values.slice()};
    const pageChanged=this.page!==doc.page;this.page=doc.page;this.model=model;this.mode=settings.readerMode || 'split';
    if(pageChanged){clearTimeout(this.progressTimer);this.pendingProgress=null;}
    document.body.dataset.readerMode=this.mode;
    document.body.classList.toggle('reader-hide-translation',settings.readerShowTranslation===false);
    $('#reader-mode').value=this.mode;$('#reader-mode option[value="pdf"]').textContent=doc.kind==='pdf'?'PDF 原版':'原文版式';$('#reader-sync').checked=settings.syncScroll!==false;$('#reader-auto-locate').checked=settings.readerAutoLocate!==false;
    for(const [id,key,fallback] of [['reader-en-size','readerEnglishSize',18],['reader-zh-size','readerChineseSize',18],['reader-width','readerWidth',760],['reader-line-height','readerLineHeight',1.9],['reader-font','readerFont','serif']])if(document.activeElement!==$('#'+id))$('#'+id).value=settings[key] ?? fallback;
    $('#reader-translation-toggle').textContent=settings.readerShowTranslation===false?'显示译文':'隐藏译文';$('#reader-translation-toggle').setAttribute('aria-pressed',String(settings.readerShowTranslation!==false));
    this.view.setData(model,settings,{pageNumber:doc.page,totalPages:doc.total,documentId:doc.id,job:this.hooks.job(),reset:changed,originalPdf:doc.kind==='pdf'});
    const progress=this.hooks.job()?.progress,running=this.hooks.job()?.status==='active';
    const completed=model.paragraphs.filter(p=>p.status==='succeeded').length;
    $('#reader-job-status').textContent=running?`翻译 ${progress.succeeded}/${progress.total}`:model.materialMode?'学习材料 · 原页展示':`已译 ${completed}/${model.paragraphs.length}`;
    $('#reader-cancel-job').classList.toggle('hidden',!running);$('.reader-translate').disabled=running || !model.paragraphs.length;
    $('.reader-translate').textContent=doc.kind==='pdf'?'翻译本页':'翻译当前内容';
    if(this.activeId){this.view.highlight(this.activeId);if(this.mode==='pdf' && (!reusable || pageChanged))this.hooks.highlight?.(this.activeId);}
    if(!$('#reader-outline').classList.contains('hidden'))this.renderOutline();
    if(model.paragraphs.length && doc.imported && this.restored!==doc.id)this.restoreProgress(doc);
  }
  async settings(values){
    const previous={};for(const key of Object.keys(values))previous[key]=this.hooks.settings()[key];
    Object.assign(this.hooks.settings(),values);this.update();
    try{await this.hooks.preference(values);}
    catch(error){for(const key of Object.keys(values))if(this.hooks.settings()[key]===values[key])this.hooks.settings()[key]=previous[key];this.update();throw error;}
  }
  async setMode(mode){
    if(!['split','stacked','pdf','chinese'].includes(mode))return;
    this.restored=this.hooks.document().id; // A choice made before PDF parsing finishes overrides saved progress too.
    ++this.preferenceEpoch;
    const companionVisible=$('.translation-panel').getClientRects().length>0;
    if(companionVisible)this.showLookup(true);
    const anchor=this.view.anchors()[this.view.visiblePane()] || {id:this.activeId,fraction:0};
    await this.settings({readerMode:mode});
    if(this.mode!==mode)return;
    if(mode==='pdf')this.hooks.tab(true);
    await this.hooks.mode?.(mode);
    if(this.mode!==mode)return;
    if(anchor?.id){this.activeId=anchor.id;if(mode==='pdf')await this.locate(anchor.id,{original:true,save:false});else this.view.restore(anchor);}
    this.saveProgress({id:anchor?.id || this.model.paragraphs[0]?.id,fraction:anchor?.fraction || 0,pane:mode==='pdf'?'pdf':this.view.visiblePane()});
    await this.flushProgress();
  }
  async restoreProgress(doc){
    this.restored=doc.id;const epoch=this.restoreEpoch,preferenceEpoch=this.preferenceEpoch;
    const valid=()=>epoch===this.restoreEpoch && doc.id===this.docId && preferenceEpoch===this.preferenceEpoch;
    try{
      const saved=await this.hooks.api('reader-progress?doc='+encodeURIComponent(doc.id));
      if(!valid() || !saved.available)return;
      if(saved.mode==='pdf')this.hooks.tab(true);
      if(saved.mode && saved.mode!==this.mode){await this.settings({readerMode:saved.mode});if(!valid())return;await this.hooks.mode?.(saved.mode);}
      if(!valid())return;
      if(saved.page!==this.hooks.document().page)await this.hooks.page(saved.page,valid);
      if(!valid())return;
      const paragraph=this.model.paragraphs.find(p=>p.id===saved.paragraph_id);
      if(!paragraph || (saved.source_hash && paragraph.sourceHash && saved.source_hash!==paragraph.sourceHash))return;
      this.activeId=paragraph.id;
      requestAnimationFrame(()=>{if(!valid())return;if(this.mode==='pdf')this.hooks.highlight?.(paragraph.id,true);else this.view.restore({id:paragraph.id,fraction:saved.fraction});});
    }catch{/* Reading remains available when local progress cannot be loaded. */}
  }
  saveProgress(anchor){
    const doc=this.hooks.document();if(!doc.imported || !anchor?.id)return;
    const paragraph=this.model.paragraphs.find(p=>p.id===anchor.id);if(!paragraph)return;
    this.activeId=anchor.id;
    this.pendingProgress={document_id:doc.id,page:doc.page,paragraph_id:anchor.id,source_hash:paragraph.sourceHash || '',
      mode:this.mode,pane:['source','translation','combined','pdf'].includes(anchor.pane)?anchor.pane:'combined',fraction:Math.max(0,Math.min(1,anchor.fraction || 0))};
    clearTimeout(this.progressTimer);this.progressTimer=setTimeout(()=>this.flushProgress(),500);
  }
  flushProgress(options={}){
    clearTimeout(this.progressTimer);const value=this.pendingProgress;this.pendingProgress=null;
    if(value)return this.hooks.api('reader-progress',value,options).catch(()=>{});
  }
  paragraph(id){return this.model.paragraphs.find(p=>p.id===id);}
  navigationIntent(){this.restored=this.hooks.document().id;this.gate.cancel();++this.preferenceEpoch;}
  fromPhysical(id){return this.model.paragraphs.find(p=>p.parts.some(part=>part.paragraphId===id && part.pageNumber===this.hooks.document().page));}
  async locate(id,{page=null,original=false,save=true}={}){
    this.restored=this.hooks.document().id;
    ++this.preferenceEpoch;
    const ticket=this.gate.begin(),docId=this.docId;let paragraph=this.paragraph(id);
    const valid=()=>this.gate.isCurrent(ticket) && docId===this.docId;
    const desired=page || paragraph?.pageNumbers.find(n=>n===this.hooks.document().page) || paragraph?.pageNumbers[0] || this.hooks.document().page;
    if(original && this.mode!=='pdf'){
      await this.settings({readerMode:'pdf'});if(!valid())return;
      this.hooks.tab(true);await this.hooks.mode?.('pdf');
    }
    if(!valid())return;
    if(desired!==this.hooks.document().page)await this.hooks.page(desired,valid);
    if(!valid())return;
    paragraph=this.paragraph(id) || paragraph;this.activeId=id;
    if(this.mode==='pdf' && id){
      const found=await this.hooks.pdfLocate(paragraph,desired,valid);
      if(!valid())return;
      if(found===false)this.hooks.toast('此段没有可靠坐标，已打开对应页，可在右侧核对原文。');
    }else if(id)this.view.restore({id,fraction:0});
    if(save && valid() && id)this.saveProgress({id,fraction:0,pane:this.mode==='pdf'?'pdf':this.view.visiblePane()});
  }
  async loadOutline(doc){
    const pdf=this.hooks.pdf();if(!pdf)return;
    try{const entries=await pdf.getOutline();if(doc.id!==this.docId || pdf!==this.hooks.pdf())return;
      const result=[];const walk=(nodes,level=1)=>{for(const node of nodes || []){if(result.length>=200)return;result.push({text:node.title,level,dest:node.dest,source:'pdf'});if(level<6)walk(node.items,level+1);}};
      walk(entries);this.outline=result;
    }catch{}
  }
  renderOutline(){
    const entries=this.outline.length?this.outline:this.model.outline;
    $('#reader-outline').innerHTML=`<h3>文章目录</h3><p>${this.outline.length?'PDF 原生书签':'附近已解析页的章节；未解析的页面不会猜测目录。'}</p>${entries.length?entries.map((entry,index)=>`<button data-reader-outline="${index}" style="padding-left:${Math.min(entry.level || 1,5)*7}px">${escape(entry.text)}<span>${entry.pageNumber?'第 '+entry.pageNumber+' 页':'↗'}</span></button>`).join(''):'<p>本页暂无章节标题。可使用上方页码跳转。</p>'}`;
  }
  async outlineLocate(index){
    const entry=(this.outline.length?this.outline:this.model.outline)[index];if(!entry)return;
    $('#reader-outline').classList.add('hidden');
    if(entry.id){await this.locate(entry.id,{page:entry.pageNumber});return;}
    const pdf=this.hooks.pdf(),ticket=this.gate.begin(),docId=this.docId;
    const valid=()=>this.gate.isCurrent(ticket) && docId===this.docId;
    try{const dest=typeof entry.dest==='string'?await pdf.getDestination(entry.dest):entry.dest;if(!valid() || !dest)return;
      const page=typeof dest[0]==='number'?dest[0]+1:(await pdf.getPageIndex(dest[0]))+1;
      if(!valid())return;await this.hooks.page(page,valid);
    }catch{this.hooks.toast('此书签无法定位，可使用页码跳转。');}
  }
  async copy(id,format,selected=''){
    const paragraph=this.paragraph(id);if(!paragraph && !(format==='source' && selected))return;
    const value=format==='source'?(selected || paragraph.text):format==='translation'?paragraph.translation:paragraph.text+'\n\n'+paragraph.translation;
    if(!value.trim()){this.hooks.toast('此段还没有译文');return;}
    try{await navigator.clipboard.writeText(value);this.hooks.toast('已复制'+(format==='bilingual'?'中英对照':format==='translation'?'中文':'英文'));}
    catch{this.hooks.toast('剪贴板暂时不可用，可选中文字后按 Ctrl+C。',true);}
  }
  handleSelection(){
    this.selection=null;$('#reader-selection-menu').classList.add('hidden');
    const selected=window.getSelection();if(!selected || selected.isCollapsed)return;
    const snapshot=this.hooks.readSelection?.(selected);
    if(this.hooks.readSelection && !snapshot)return;
    const anchor=selected.anchorNode?.nodeType===Node.ELEMENT_NODE?selected.anchorNode:selected.anchorNode?.parentElement;
    if(!anchor || !anchor.closest('#reader-surface,#paper-scroll'))return;
    if(anchor.closest('[data-reader-language="translation"]'))return;
    const text=snapshot?.text ?? selected.toString().trim();if(!text)return;
    const paragraph=anchor.closest('[data-reader-id]')?this.paragraph(anchor.closest('[data-reader-id]').dataset.readerId):this.fromPhysical(anchor.closest('[data-passage]')?.dataset.passage);
    const rect=selected.getRangeAt(0).getBoundingClientRect(),menu=$('#reader-selection-menu');
    this.selection={id:paragraph?.id || null,text,documentId:this.docId};
    this.view.closeContext?.();menu.classList.remove('hidden');menu.style.left=Math.max(12,Math.min(rect.left,window.innerWidth-menu.offsetWidth-12))+'px';menu.style.top=Math.max(8,Math.min(rect.bottom+8,window.innerHeight-menu.offsetHeight-12))+'px';
    for(const button of menu.querySelectorAll('[data-reader-selection="chinese"],[data-reader-selection="bilingual"]'))button.disabled=!paragraph?.translation;
    for(const button of menu.querySelectorAll('[data-reader-selection="locate"],[data-reader-selection="note"]'))button.disabled=!paragraph;
    return this.selection;
  }
  showLookup(show=true){this.lookup=show;document.body.classList.toggle('reader-lookup-open',show);$('[data-reader-action="lookup"]').setAttribute('aria-expanded',String(show));this.companion?.update();}
  note(id,quote=''){
    const paragraph=this.paragraph(id);if(!paragraph)return;
    if(!this.hooks.document().imported){this.hooks.toast('先把文章加入书库，即可保存阅读笔记。');return;}
    this.noteContext={document_id:this.docId,paragraph_id:id,page:this.hooks.document().page,source_hash:paragraph.sourceHash || '',quote:(quote || paragraph.text).slice(0,12000)};
    $('#reader-note-quote').textContent=this.noteContext.quote;$('#reader-note-text').value='';$('#reader-note-dialog').showModal();
  }
  async notes(){
    if(!this.hooks.document().imported){this.hooks.toast('先打开书库文献，即可查看笔记。');return;}
    const doc=this.docId,result=await this.hooks.api('reader-notes?doc='+encodeURIComponent(doc));if(doc!==this.docId)return;
    this.noteList=result.notes;
    $('#reader-notes-list').innerHTML=result.notes.length?result.notes.map(note=>`<article class="reader-note-card"><blockquote>${escape(note.quote)}</blockquote><p>${escape(note.note)}</p><button data-reader-note-locate="${escape(note.id)}">定位原文</button><button data-reader-note-delete="${escape(note.id)}">删除笔记</button></article>`).join(''):'<div class="reader-empty"><p>选中英文，或在段落下方点击「笔记」，记录你的理解。</p></div>';
    if(!$('#reader-notes-dialog').open)$('#reader-notes-dialog').showModal();
  }
  async handleClick(event){
    const button=event.target.closest('[data-reader-action],[data-reader-selection],[data-reader-outline],[data-reader-note-locate],[data-reader-note-delete]');if(!button)return;
    try{
      if(button.dataset.readerSelection){
        const selection=this.selection;if(!selection || selection.documentId!==this.docId)return;
        const paragraph=this.paragraph(selection.id),action=button.dataset.readerSelection;
        $('#reader-selection-menu').classList.add('hidden');
        if(action==='english')await this.copy(selection.id,'source',selection.text);
        if(action==='chinese')await this.copy(selection.id,'translation');
        if(action==='bilingual')await this.copy(selection.id,'bilingual');
        if(action==='locate'){
          if(this.mode==='pdf'){this.hooks.tab(true);this.showLookup(true);await this.locate(selection.id,{original:true});}
          else this.view.select(selection.id,{force:true});
        }
        if(action==='note')this.note(selection.id,selection.text);
        if(action==='translate' || action==='dictionary'){this.showLookup();this.hooks.source(selection.text,paragraph?.text || '');if(!this.hooks.settings().autoTranslate)this.hooks.instant();}
        return;
      }
      if(button.dataset.readerOutline!==undefined){await this.outlineLocate(Number(button.dataset.readerOutline));return;}
      if(button.dataset.readerNoteLocate){
        const note=this.noteList.find(n=>n.id===button.dataset.readerNoteLocate);$('#reader-notes-dialog').close();if(note)await this.locate(note.paragraph_id,{page:note.page || 1,original:true});return;
      }
      if(button.dataset.readerNoteDelete){await this.hooks.api('reader-notes/delete',{document_id:this.docId,id:button.dataset.readerNoteDelete});await this.notes();return;}
      const action=button.dataset.readerAction;
      if(action==='outline'){const open=$('#reader-outline').classList.contains('hidden');$('#reader-outline').classList.toggle('hidden',!open);button.setAttribute('aria-expanded',String(open));if(open)this.renderOutline();}
      if(action==='translate')await this.hooks.translate();
      if(action==='cancel')await this.hooks.cancel();
      if(action==='translation-toggle')await this.settings({readerShowTranslation:this.hooks.settings().readerShowTranslation===false});
      if(action==='lookup')this.showLookup(!this.lookup);
      if(action==='lookup-close'){this.showLookup(false);if(this.mode==='pdf')await this.settings({readerShowTranslation:false});}
      if(action==='theme')await this.hooks.preference({theme:this.hooks.settings().theme==='dark'?'light':'dark'});
      if(action==='notes')await this.notes();
      if(action==='close-note')$('#reader-note-dialog').close();if(action==='close-notes')$('#reader-notes-dialog').close();
      if(action==='save-note'){await this.hooks.api('reader-notes',{...this.noteContext,note:$('#reader-note-text').value});$('#reader-note-dialog').close();this.hooks.toast('阅读笔记已保存在本机');}
    }catch(error){this.hooks.toast(error.message,true);}
  }
}
