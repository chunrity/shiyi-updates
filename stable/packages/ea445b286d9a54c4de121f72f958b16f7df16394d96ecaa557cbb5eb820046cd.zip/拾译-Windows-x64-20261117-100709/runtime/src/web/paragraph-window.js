import {buildDocumentStructure} from './pdf-structure.js';

/** Resolve all pages of paragraphs touching the requested page, plus one guard
 * page at either end. Text/layout loading is independent of visible PDF canvases.
 * A failed required page rejects the request: never silently submit a fragment.
 */
export async function resolveParagraphWindow({id,name='',totalPages,pageNumber,loadPage,valid=()=>true}){
  const pages=new Map();
  const check=()=>{if(!valid())throw new DOMException('阅读位置已变化','AbortError');};
  const load=async number=>{check();const page=await loadPage(number);check();if(!page || page.pageNumber!==number)throw new Error('相邻页解析失败，请重试');pages.set(number,page);};
  let left=Math.max(1,pageNumber-1),right=Math.min(totalPages,pageNumber+1);
  await Promise.all(Array.from({length:right-left+1},(_,i)=>load(left+i)));
  for(;;){
    check();
    const structure=buildDocumentStructure({id,name,totalPages,pages:[...pages.values()]});
    const relevant=structure.paragraphs.filter(p=>p.translatable!==false && p.parts.some(part=>part.pageNumber===pageNumber));
    const before=left>1 && relevant.some(p=>p.parts[0].pageNumber===left);
    const after=right<totalPages && relevant.some(p=>p.parts.at(-1).pageNumber===right);
    if(!before && !after)return structure;
    const next=[];if(before)next.push(--left);if(after)next.push(++right);
    await Promise.all(next.map(load));
  }
}

/** Retry a physical fragment that acquired its canonical ID during resolution. */
export function resolvedTargetIds(manifest,previous,ids){
  if(!ids)return manifest.target_ids;
  return [...new Set(ids.map(id=>{
    if(manifest.target_ids.includes(id))return id;
    const old=previous.paragraphs.find(p=>p.paragraph_id===id);
    const found=manifest.paragraphs.find(p=>manifest.target_ids.includes(p.paragraph_id) && p.source_parts.some(part=>part.paragraph_id===id || old?.source_parts.some(o=>o.page_number===part.page_number && o.paragraph_id===part.paragraph_id)));
    if(!found)throw new Error('段落位置已变化，请重新选择该段重试');
    return found.paragraph_id;
  }))];
}
