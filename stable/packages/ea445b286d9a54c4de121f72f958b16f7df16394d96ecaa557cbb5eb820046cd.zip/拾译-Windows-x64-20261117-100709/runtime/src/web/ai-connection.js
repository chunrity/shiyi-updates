/** User-triggered connection diagnostics. Editing/saving is never success. */
export function attachConnectionTest(doc,api){
  let revision=0,busy=false,saved=null,lastTest=null;
  const fields={provider:'setting-provider',apiBase:'setting-api-base',apiKey:'setting-api-key',model:'setting-model',aiTimeoutSeconds:'setting-ai-timeout',aiFastMode:'setting-ai-fast'};
  const status=doc.querySelector('#ai-connection-status'),button=doc.querySelector('#ai-connection-test');
  const draft=()=>Object.fromEntries(Object.entries(fields).map(([k,id])=>{const e=doc.getElementById(id);return [k,k==='aiFastMode'?e.checked:k==='aiTimeoutSeconds'?Number(e.value):e.value];}));
  // Private in-memory comparisons only. Credential values never enter the DOM,
  // attributes, diagnostics, storage or test-result labels.
  const identity=config=>JSON.stringify(config);
  const labels={success:'成功',authentication_failed:'认证失败',permission_or_quota:'权限或额度异常',network_error:'网络异常',service_error:'服务异常'};
  const descriptions={auto:'优先尝试微软翻译，连接失败时使用 MyMemory；单词可使用词典释义。',bing:'使用微软公共翻译服务，无需配置 API Key。',memory:'使用 MyMemory 公共翻译服务，受公共访问及额度限制。',google:'使用 Google 翻译，需要当前网络能够访问对应服务。',custom:'使用下方保存的兼容 AI / 本地模型配置；词典和 PDF 原文释义仍可作为兜底。'};
  const host=status.closest('.ai-connection-row')||status;
  host.insertAdjacentHTML('afterend','<div class="ai-config-meta"><p id="ai-config-state" role="status"></p><p id="ai-last-test-state"></p></div>');
  const meta=()=>{
    const current=draft(),same=saved!==null&&identity(current)===saved;
    doc.querySelector('#ai-config-state').textContent=same?'当前输入：已保存配置':'当前输入：尚未保存';
    doc.querySelector('#ai-config-state').dataset.saved=String(same);
    const previous=doc.querySelector('#ai-last-test-state');
    previous.textContent=lastTest?'最近测试：'+(labels[lastTest.status]||'未完成')+(lastTest.identity===identity(current)?' · 对应当前输入':' · 对应修改前配置')+(lastTest.at?' · '+new Date(lastTest.at*1000).toLocaleString():''):'最近测试：此配置尚未测试';
    previous.dataset.matches=String(!!lastTest&&lastTest.identity===identity(current));
    const note=doc.querySelector('#setting-provider-description')||doc.getElementById('setting-provider').closest('label')?.querySelector('small');
    if(note)note.textContent=descriptions[current.provider]||'选择所需翻译服务。';
  };
  const paint=r=>{status.textContent=r.message+(r.success_at?' · 上次成功：'+new Date(r.success_at*1000).toLocaleString():'');status.dataset.status=r.status;};
  for(const id of Object.values(fields))doc.getElementById(id).addEventListener('input',()=>{revision++;paint({status:'untested',message:'当前输入已改变，需要重新测试'});meta();});
  doc.querySelector('#settings-dialog')?.addEventListener('settings-saved',()=>{saved=identity(draft());meta();});
  button.addEventListener('click',async()=>{
    if(busy)return;busy=true;button.disabled=true;const turn=++revision,config=draft();paint({status:'testing',message:'测试当前输入，正在等待模型真实响应…'});
    try{const r=await api('ai-connection-test',config,{signal:AbortSignal.timeout((Math.min(600,Math.max(15,config.aiTimeoutSeconds || 180))+10)*1000)});lastTest={identity:identity(config),status:r.status,at:Date.now()/1000};if(turn===revision)paint(r);meta();}
    catch{lastTest={identity:identity(config),status:'network_error',at:Date.now()/1000};if(turn===revision)paint({status:'network_error',message:'连接测试未完成：网络异常或等待超时'});meta();}
    finally{busy=false;button.disabled=false;}
  });
  return {async load(){const turn=++revision,config=draft();saved=identity(config);lastTest=null;meta();paint({status:'untested',message:'当前配置尚未测试'});try{const r=await api('ai-connection-status',config);if(turn===revision){if(r.status!=='untested')lastTest={identity:identity(config),status:r.status,at:r.status==='success'?r.success_at:null};paint(r);meta();}}catch{if(turn===revision)paint({status:'untested',message:'无法读取测试记录；尚未确认连接'});}}};
}
