/** One real PDF canvas and text layer. Layout readiness never waits for painting. */
export class PdfSurface{
  constructor({canvas,container,wrapper,TextLayer}){
    Object.assign(this,{canvas,container,wrapper,TextLayer});this.current=null;this.generation=0;
  }
  clear(){
    ++this.generation;this.current?.task?.cancel();this.current?.layer?.cancel();this.current=null;
    this.container.replaceChildren();this.canvas.width=0;this.canvas.height=0;
    this.wrapper.removeAttribute('data-painting');
  }
  present({page,content,scale,ratio=1,revision=null}){
    const previous=this.current;
    if(previous && !previous.error && previous.page===page && previous.scale===scale && previous.ratio===ratio && previous.revision===revision)return previous.ready;
    const generation=++this.generation;
    previous?.task?.cancel();
    const reuseLayer=previous?.page===page && previous.content===content && previous.layerReady && !revision && !previous.revision;
    if(!reuseLayer)previous?.layer?.cancel();
    const viewport=page.getViewport({scale});
    const state={page,content,scale,ratio,revision,viewport,layerReady:false,complete:false};this.current=state;
    Object.assign(this.wrapper.style,{width:viewport.width+'px',height:viewport.height+'px'});
    this.wrapper.style.setProperty('--scale-factor',scale);
    // TextLayer consumes CSS scale independently of canvas pixels (DPR).
    // Set it on the layer too: the legacy stylesheet supplied a local value of 1.
    this.container.style?.setProperty('--scale-factor',scale);
    this.container.style?.setProperty('--total-scale-factor',scale);
    this.canvas.width=Math.floor(viewport.width*ratio);this.canvas.height=Math.floor(viewport.height*ratio);
    Object.assign(this.canvas.style,{width:viewport.width+'px',height:viewport.height+'px'});
    this.wrapper.dataset.painting='true';
    state.task=page.render({canvasContext:this.canvas.getContext('2d',{alpha:false}),viewport,
      transform:ratio===1?null:[ratio,0,0,ratio,0,0],background:'white'});
    // Attach both handlers immediately: cancelled, obsolete paints cannot leak rejections.
    state.painted=state.task.promise.then(()=>{
      state.complete=true;if(this.current===state)this.wrapper.dataset.painting='false';return true;
    },error=>{
      state.error=error;if(this.current===state)this.wrapper.dataset.painting='false';return false;
    });
    state.ready=(async()=>{
      if(reuseLayer){state.layer=previous.layer;state.layer.update({viewport});}
      else{
        this.container.replaceChildren();this.container.classList.remove('ocr-layer');
        state.layer=new this.TextLayer({textContentSource:content,container:this.container,viewport});
        await state.layer.render();
      }
      if(generation!==this.generation){const error=new Error('PDF page changed');error.name='AbortException';throw error;}
      state.layerReady=true;state.spans=[];let index=0;
      for(let i=0;i<content.items.length;i++)if('str' in content.items[i])state.spans[i]=state.layer.textDivs[index++];
      return state;
    })().catch(error=>{state.task.cancel();state.layer?.cancel();if(this.current===state)this.current=null;throw error;});
    return state.ready;
  }
}
