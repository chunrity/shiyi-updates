import {pdfTextGeometry,pdfRangeText} from './pdf-selection-geometry.js';
/** Native PDF selection helpers. Never substitute a paragraph for a user range. */
export function pdfFragmentSeparator(left,right){
  if(!left || !right || !left.str || !right.str || /\s$/.test(left.str) || /^\s/.test(right.str))return '';
  const a=left.transform,b=right.transform;
  if(!a || !b)return '';
  const height=Math.max(1,Math.hypot(a[2],a[3]),Math.hypot(b[2],b[3]));
  const angle=Math.atan2(a[1],a[0]),dx=b[4]-a[4],dy=b[5]-a[5];
  const gap=dx*Math.cos(angle)+dy*Math.sin(angle)-left.width;
  return gap>height*.08?' ':'';
}

export function wordBounds(text,offset){
  // Internal apostrophes/hyphens are part of English words, not delimiters.
  const pattern=/[\p{L}\p{N}]+(?:['’\-‐‑][\p{L}\p{N}]+)*/gu;
  for(const match of text.matchAll(pattern)){
    const start=match.index,end=start+match[0].length;
    if(offset>=start && offset<end)return {start,end,text:match[0]};
  }
  return null;
}

export function readReaderSelection(selection){
  if(!selection || selection.isCollapsed || selection.rangeCount!==1)return null;
  const range=selection.getRangeAt(0);
  const element=node=>node?.nodeType===1?node:node?.parentElement;
  const start=element(range.startContainer),end=element(range.endContainer);
  const root=start?.closest('#pdf-text,.reader-source,.reader-combined,.article-body');
  if(!root || !root.contains(range.endContainer) || start.closest('[data-reader-language="translation"]') || end?.closest('[data-reader-language="translation"]'))return null;
  const text=root.id==='pdf-text' && root.ownerDocument?.createTreeWalker?pdfRangeText(range,root):selection.toString().trim();
  return text?{text,range,root}:null;
}

export function selectPdfWord(event,container){
  const doc=container.ownerDocument,selection=doc.defaultView.getSelection();
  // Point hit testing honours the transformed, zoomed text layer.
  const boxes=pdfSelectionBoxes(container);
  const geometric=pdfCaretFromGeometry(container,boxes,event.clientX,event.clientY,{character:true,strict:true});
  if(boxes.length && !geometric)return false;
  const caret=geometric?{offsetNode:geometric.node,offset:geometric.offset}:doc.caretPositionFromPoint?.(event.clientX,event.clientY);
  const fallback=caret?null:doc.caretRangeFromPoint?.(event.clientX,event.clientY);
  const node=caret?.offsetNode || fallback?.startContainer;
  const offset=caret?.offset ?? fallback?.startOffset;
  const span=node?.parentElement?.closest('[data-selection-line]');
  if(node?.nodeType!==3 || !span || !container.contains(span))return false;
  const line=span.dataset.selectionLine;
  const spans=[...container.querySelectorAll('[data-selection-line]')].filter(s=>s.dataset.selectionLine===line);
  const pieces=[];let text='',hit=-1,previous=null;
  for(const item of spans){
    // Read the actual separator inserted between adjacent PDF fragments.
    if(previous){let sibling=previous.nextSibling;while(sibling && sibling!==item){if(sibling.nodeType===3)text+=sibling.textContent;sibling=sibling.nextSibling;}}
    const leaf=item.firstChild;if(!leaf || leaf.nodeType!==3)continue;
    pieces.push({node:leaf,start:text.length,end:text.length+leaf.length});
    if(leaf===node)hit=text.length+offset;
    text+=leaf.textContent;previous=item;
  }
  const bounds=wordBounds(text,hit);if(!bounds)return false;
  const first=pieces.find(p=>bounds.start>=p.start && bounds.start<p.end);
  const last=pieces.find(p=>bounds.end>p.start && bounds.end<=p.end);
  if(!first || !last)return false;
  const range=doc.createRange();range.setStart(first.node,bounds.start-first.start);range.setEnd(last.node,bounds.end-last.start);
  selection.removeAllRanges();selection.addRange(range);return true;
}

/** Geometry only lives for one gesture. PDF spans remain native selectable text. */
export class PdfSelectionGesture{
  constructor(container){this.container=container;this.active=null;this.frame=0;}
  start(event){
    this.cancel();if(event.button!==0 || event.detail>1 || !this.container.contains(event.target))return;
    const boxes=pdfSelectionBoxes(this.container);
    const anchor=pdfCaretFromGeometry(this.container,boxes,event.clientX,event.clientY);
    if(anchor)this.active={boxes,anchor,x:event.clientX,y:event.clientY,pointer:event.pointerId};
  }
  move(event){
    if(!this.active || event.pointerId!==this.active.pointer || !(event.buttons&1))return;
    this.point={x:event.clientX,y:event.clientY};
    if(!this.frame)this.frame=requestAnimationFrame(()=>{this.frame=0;this.apply(this.point);});
  }
  apply(point){
    const state=this.active;if(!state || !point || Math.hypot(point.x-state.x,point.y-state.y)<3)return;
    if(!this.container.contains(state.anchor.node)){this.cancel();return;}
    const focus=pdfCaretFromGeometry(this.container,state.boxes,point.x,point.y);if(!focus)return;
    const selection=this.container.ownerDocument.defaultView.getSelection();
    if(selection.anchorNode===state.anchor.node && selection.anchorOffset===state.anchor.offset && selection.focusNode===focus.node && selection.focusOffset===focus.offset)return;
    selection.setBaseAndExtent(state.anchor.node,state.anchor.offset,focus.node,focus.offset);
  }
  end(event){if(this.active && event.pointerId===this.active.pointer)this.apply({x:event.clientX,y:event.clientY});this.cancel();}
  cancel(){if(this.frame)cancelAnimationFrame(this.frame);this.frame=0;this.active=null;this.point=null;}
}

export function pdfSelectionBoxes(container){
  if(!container.querySelectorAll || !container.getBoundingClientRect)return [];
  const origin=container.getBoundingClientRect();
  return [...container.querySelectorAll('span')].filter(s=>s.firstChild?.nodeType===3 && s.textContent.trim()).map(span=>{
    const b=span.getBoundingClientRect(),geometry=pdfTextGeometry.get(span.firstChild);
    // CSS font height scales with the viewport, independently of screen DPR.
    const scale=geometry?.fontHeight?b.height/geometry.fontHeight:0;
    return {node:span.firstChild,left:b.left-origin.left,right:geometry && scale?b.left-origin.left+geometry.width*scale:b.right-origin.left,
      top:b.top-origin.top,bottom:b.bottom-origin.top,boundaries:geometry?.boundaries};
  });
}

export function pdfCaretFromGeometry(container,boxes,clientX,clientY,{character=false,strict=false}={}){
  if(!boxes.length)return null;
  const origin=container.getBoundingClientRect(),x=clientX-origin.left,y=clientY-origin.top;
  let best=null,score=Infinity;
  for(const b of boxes){
    const dy=Math.max(b.top-y,0,y-b.bottom),dx=Math.max(b.left-x,0,x-b.right);
    if(strict && (dx>0 || dy>0))continue;
    // An endpoint just outside a short line must not jump to the container's
    // final DOM child (often an unrelated footnote or vocabulary column).
    const distance=dy*dy*4+dx*dx+Math.abs((b.top+b.bottom)/2-y)*.01;
    if(distance<score){best=b;score=distance;}
  }
  if(!best)return null;
  const node=best.node;
  if(best.boundaries){
    const fraction=(x-best.left)/(best.right-best.left);let offset=0;
    while(offset<node.length && fraction>=(character?best.boundaries[offset+1]:(best.boundaries[offset]+best.boundaries[offset+1])/2))offset++;
    return {node,offset};
  }
  const range=container.ownerDocument.createRange();let low=0,high=node.length;
  // Character geometry is measured only in the hit span, in CSS viewport units.
  while(low<high){const mid=(low+high)>>1;range.setStart(node,mid);range.setEnd(node,mid+1);const r=range.getBoundingClientRect();if(clientX<(character?r.right:(r.left+r.right)/2))high=mid;else low=mid+1;}
  return {node,offset:low};
}

/** One active request, tied to the selection epoch rather than response order. */
export class LatestSelectionRequest{
  constructor(){this.epoch=0;this.active=null;this.results=new Map();}
  get pending(){return !!this.active;}
  clearCache(){this.results.clear();}
  cached(key){
    const entry=this.results.get(key);if(!entry)return null;
    if(Date.now()-entry.time>10*60*1000){this.results.delete(key);return null;}
    this.results.delete(key);this.results.set(key,entry);return {...entry.result,cached:true};
  }
  remember(key,result){
    this.results.delete(key);this.results.set(key,{time:Date.now(),result});
    while(this.results.size>64)this.results.delete(this.results.keys().next().value);
  }
  invalidate(){++this.epoch;this.active?.controller.abort();this.active=null;}
  begin(key){
    if(this.active?.key===key)return null;
    this.invalidate();const controller=new AbortController();
    return this.active={key,epoch:this.epoch,controller,signal:controller.signal};
  }
  isCurrent(request){return this.active===request && request.epoch===this.epoch && !request.signal.aborted;}
  finish(request){if(this.active===request)this.active=null;}
}
