/** Presentation adapter. Delegates to existing UI handlers; never calls an API. */
import {softwareUpdateMarkup} from './update-center.js';

export function submitHomeText(doc){
  const input=doc.querySelector('#home-source-text'),source=doc.querySelector('#source-text');
  if(!input.value.trim()){input.focus();return false;}
  doc.dispatchEvent(new CustomEvent('home-translate',{detail:input.value}));
  return true;
}
export function selectSettingsTab(root,id,focus=false){
  const tabs=[...root.querySelectorAll('[data-settings-tab]')];
  const selected=tabs.find(tab=>tab.dataset.settingsTab===id);if(!selected)return false;
  for(const tab of tabs){const active=tab===selected;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;}
  for(const panel of root.querySelectorAll('[data-settings-panel]'))panel.hidden=panel.dataset.settingsPanel!==id;
  const changed=root.dataset?.settingsActive!==id;
  if(changed){const content=root.querySelector?.('.settings-content');if(content)content.scrollTop=0;}
  if(root.dataset)root.dataset.settingsActive=id;
  if(changed)root.dispatchEvent?.(new CustomEvent('settings-tab-change'));
  if(focus)selected.focus();return true;
}
const ordinaryGroups={
  general:['setting-auto','setting-clipboard'],
  models:['setting-provider','setting-api-base','setting-api-key','setting-model','setting-ai-timeout','setting-ai-batch','setting-ai-fast'],
  floating:['setting-noactivate','setting-pinned','setting-restore-clipboard']
};
export function changedSettingsGroups(before,after){
  return Object.entries(ordinaryGroups).filter(([,ids])=>ids.some(id=>before[id]!==after[id])).map(([id])=>id);
}
function enhanceSettings(doc){
  const dialog=doc.querySelector('#settings-dialog'),body=dialog.querySelector('.dialog-body');
  const [mixed,floating,privacy]=[...body.children];
  const panel=(id,title)=>{const section=doc.createElement('section');section.className='setting-section';section.dataset.settingsPanel=id;section.id='settings-panel-'+id;section.setAttribute('role','tabpanel');section.setAttribute('aria-labelledby','settings-tab-'+id);const h=doc.createElement('h3');h.textContent=title;section.append(h);return section;};
  const general=panel('general','通用'),models=panel('models','翻译与模型'),reading=panel('reading','阅读体验'),about=panel('about','关于拾译'),appearance=panel('appearance','外观与主题');
  general.append(doc.querySelector('#setting-auto').closest('label'),doc.querySelector('#setting-clipboard').closest('label'));
  models.append(doc.querySelector('#setting-provider').closest('label'),doc.querySelector('#custom-api'));
  floating.dataset.settingsPanel='floating';floating.id='settings-panel-floating';floating.setAttribute('role','tabpanel');floating.setAttribute('aria-labelledby','settings-tab-floating');floating.querySelector('h3').textContent='悬浮窗与快捷键';
  privacy.dataset.settingsPanel='privacy';privacy.id='settings-panel-privacy';privacy.setAttribute('role','tabpanel');privacy.setAttribute('aria-labelledby','settings-tab-privacy');privacy.querySelector('h3').textContent='隐私与数据';
  const intro=(section,text)=>section.querySelector('h3').insertAdjacentHTML('afterend',`<p class="settings-intro">${text}</p>`);
  // Panels are assembled off-DOM; retain access to the existing form nodes.
  const find=selector=>general.querySelector(selector)||models.querySelector(selector)||doc.querySelector(selector);
  const group=(section,title,nodes,mode='')=>{const box=doc.createElement('div');box.className='settings-group';const h=doc.createElement('h4');h.textContent=title;if(mode){const badge=doc.createElement('span');badge.className='save-badge';badge.textContent=mode;h.append(badge);}box.append(h,...nodes);section.append(box);return box;};
  intro(general,'少一点操作，按照自己的节奏阅读。');
  group(general,'翻译触发方式',[find('#setting-auto').closest('label'),find('#setting-clipboard').closest('label')],'点击保存');
  general.insertAdjacentHTML('beforeend','<div class="settings-links"><button class="settings-link" data-settings-jump="appearance">外观、主题与背景 <span aria-hidden="true">→</span></button></div>');
  intro(models,'选择服务并配置连接。测试与保存是两个独立操作。');
  const providerRow=find('#setting-provider').closest('label');providerRow.querySelector('small').id='setting-provider-description';
  group(models,'翻译服务',[providerRow],'点击保存');
  const custom=find('#custom-api');models.append(custom);
  const field=id=>find('#'+id).closest('label');
  const connectionNodes=[find('.ai-connection-row')],connectionMeta=find('.ai-config-meta');if(connectionMeta)connectionNodes.push(connectionMeta);
  const connection=group(custom,'AI 连接',connectionNodes);
  connection.insertAdjacentHTML('beforeend','<p class="setting-note ai-test-note">测试使用当前输入，不会保存配置；修改地址、密钥或模型后需要重新测试。测试会发送一次真实请求，可能产生少量费用。</p>');
  group(custom,'接口与认证',[field('setting-api-base'),field('setting-api-key'),field('setting-model')]);
  const timing=doc.createElement('div');timing.className='settings-fields';timing.append(field('setting-ai-timeout'),field('setting-ai-batch'));
  const timeout=group(custom,'请求与等待',[timing]);
  timeout.insertAdjacentHTML('beforeend','<p class="setting-note">模型较慢时建议等待 180–300 秒、每次 1 段。超时段落最多自动重试一次，已完成结果保留。</p>');
  const fast=field('setting-ai-fast');custom.querySelectorAll(':scope>p').forEach(p=>p.remove());
  custom.insertAdjacentHTML('beforeend','<details class="settings-advanced" id="model-advanced"><summary>高级翻译选项</summary><div class="settings-advanced-body"></div></details>');
  custom.querySelector('.settings-advanced-body').append(fast);
  custom.querySelector('.settings-advanced-body').insertAdjacentHTML('beforeend','<p class="setting-note">兼容 Chat Completions API。密钥保存在当前用户数据目录中，未加密；请勿分享个人数据库。保存配置不会自动发起连接测试。</p>');
  intro(floating,'跨软件查词与截图沿用现有快捷键，浮窗行为可按阅读习惯调整。');
  const keyNodes=[...floating.children].filter(e=>e.matches('.hotkey-row,.hotkey-status,.hotkey-buttons,.setting-note'));
  group(floating,'快捷键',keyNodes,'自动保存');
  group(floating,'悬浮窗行为',[...floating.querySelectorAll(':scope>label')],'点击保存');
  reading.insertAdjacentHTML('beforeend','<p class="settings-intro">排版与阅读偏好在阅读器中调整并自动保存，不需要再次点击下方保存。</p>');
  group(reading,'长期阅读偏好',[],'自动保存').insertAdjacentHTML('beforeend','<p class="setting-note">英文字号、中文字号、行距、宽度、字体与点击自动定位，继续使用当前阅读器的排版设置。</p><div class="settings-links"><button class="settings-link" data-interface="reading-settings">打开阅读排版设置 <span aria-hidden="true">↗</span></button></div>');
  group(reading,'阅读时的工具',[]).insertAdjacentHTML('beforeend','<p class="setting-note">左右对照、上下对照、PDF 原版、中文沉浸共用原文和译文。同步滚动、译文显示、笔记等入口仍在阅读工具中。</p><div class="settings-links"><button class="settings-link" data-interface="reading-tools">打开全部阅读工具 <span aria-hidden="true">↗</span></button></div>');
  privacy.querySelector('.setting-note').textContent='原始文献的书库副本、阅读进度、生词、翻译记录和个人配置保存在当前用户数据目录。正式版默认使用 Windows LocalAppData 下的 Shiyi；候选测试使用独立目录。原始导入文件仍保留在你选择的位置。';
  privacy.insertAdjacentHTML('beforeend','<div class="data-location"><strong>当前用户数据目录</strong><code id="runtime-data-directory">正在读取实际路径…</code></div>');
  group(privacy,'联网与本地处理',[]).insertAdjacentHTML('beforeend','<p class="setting-note">翻译时，目标文本及有限的相邻段落、标题和术语会发送给所选服务。截图识别在本机完成。API Key 未加密保存在个人数据库中，请妥善保管。设置界面不会自动发送 AI 测试请求。</p>');
  const projectButton=privacy.querySelector('[data-action=open-folder]');projectButton.remove();
  group(privacy,'程序退出',[dialog.querySelector('[data-action=quit]')]).insertAdjacentHTML('beforeend','<p class="setting-note">右上角 X 同样会彻底退出。此入口作为备用退出方式保留，会关闭本地服务和全局快捷键。</p>');
  about.insertAdjacentHTML('beforeend','<div class="about-wordmark">拾译</div><p class="about-copy">让语言之间的距离，短一点。</p>'+softwareUpdateMarkup+'<details class="settings-advanced" id="settings-runtime-details"><summary>构建与运行信息</summary><div class="settings-advanced-body"><dl id="runtime-version-info" class="runtime-details">读取当前运行版本…</dl></div></details><div class="settings-links"><a class="settings-link" href="/classic/index.html">使用经典界面 <span aria-hidden="true">↗</span></a><button class="settings-link" data-action="open-folder">打开项目与本地使用说明 <span aria-hidden="true">↗</span></button></div>');
  const nav=doc.createElement('nav');nav.className='settings-nav';nav.setAttribute('role','tablist');nav.setAttribute('aria-label','偏好设置分类');nav.setAttribute('aria-orientation','vertical');
  for(const [id,title,icon] of [['general','通用','settings'],['appearance','外观与主题','moon'],['models','翻译与模型','spark'],['reading','阅读体验','book'],['floating','悬浮窗','scan'],['privacy','隐私与数据','file'],['about','关于','grid']]){
    const tab=doc.createElement('button');tab.type='button';tab.dataset.settingsTab=id;tab.id='settings-tab-'+id;tab.setAttribute('role','tab');tab.setAttribute('aria-controls','settings-panel-'+id);tab.innerHTML=`<svg aria-hidden="true"><use href="#i-${icon}"/></svg><span>${title}</span>`;nav.append(tab);
  }
  const content=doc.createElement('div');content.className='settings-content';content.append(general,appearance,models,reading,floating,privacy,about);body.replaceChildren(nav,content);body.classList.add('settings-shell');selectSettingsTab(dialog,'general');
  content.tabIndex=0;content.setAttribute('aria-label','偏好设置内容');
  const layout=()=>{dialog.style.setProperty('--appearance-zoom',Number(doc.defaultView.getComputedStyle(doc.body).zoom)||1);nav.setAttribute('aria-orientation',doc.defaultView.getComputedStyle(nav).flexDirection==='row'?'horizontal':'vertical');};
  if(doc.defaultView.ResizeObserver)new doc.defaultView.ResizeObserver(layout).observe(dialog);
  doc.defaultView.addEventListener('resize',layout);
  nav.addEventListener('click',event=>{const tab=event.target.closest('[data-settings-tab]');if(tab)selectSettingsTab(dialog,tab.dataset.settingsTab);});
  nav.addEventListener('keydown',event=>{
    if(!['ArrowDown','ArrowUp','ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
    const tabs=[...nav.querySelectorAll('[role=tab]')],at=tabs.indexOf(doc.activeElement);if(at<0)return;event.preventDefault();
    const index=event.key==='Home'?0:event.key==='End'?tabs.length-1:(at+(event.key==='ArrowDown'||event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
    selectSettingsTab(dialog,tabs[index].dataset.settingsTab,true);
  });
  dialog.addEventListener('click',event=>{
    const jump=event.target.closest('[data-settings-jump]');if(jump){selectSettingsTab(dialog,jump.dataset.settingsJump,true);return;}
    const button=event.target.closest('[data-interface]');if(!button)return;
    event.preventDefault();event.stopPropagation();
    dialog.close();doc.querySelector('.navigation [data-view="reader"]').click();
    doc.querySelector('#reader-more').open=true;
    if(button.dataset.interface==='reading-settings')doc.querySelector('.reader-type-settings').open=true;
    doc.querySelector('#reader-more>summary').focus();
  });
  const footer=dialog.querySelector('.dialog-footer'),save=footer.querySelector('[data-action=save-settings]');
  footer.insertAdjacentHTML('afterbegin','<div class="settings-save-copy"><p id="settings-save-status" role="status" aria-live="polite">全部已保存</p><button id="settings-save-help" type="button" title="普通设置点击保存后生效；外观和快捷键自动保存。取消未保存仅放弃普通设置草稿。" aria-label="保存规则：普通设置需点击保存，外观与快捷键自动保存；取消仅放弃普通设置草稿。">?</button></div><div class="settings-footer-actions"><button class="secondary" data-action="close-settings">关闭</button></div>');
  footer.querySelector('.settings-footer-actions').append(save);
  const manual=Object.values(ordinaryGroups).flat(),names={general:'通用',appearance:'外观与主题',models:'翻译与模型',floating:'悬浮窗'};
  const draft=()=>Object.fromEntries(manual.map(id=>{const e=doc.getElementById(id);return [id,e.type==='checkbox'?e.checked:e.value];}));
  let initial=draft(),saving=false,failed=false,submitted=null;
  const auto=new Map();
  const status=doc.querySelector('#settings-save-status'),close=footer.querySelector('[data-action=close-settings]');
  const update=()=>{
    const dirty=changedSettingsGroups(initial,draft());
    if(!dirty.length)failed=false;
    for(const tab of nav.querySelectorAll('[data-settings-tab]')){
      const id=tab.dataset.settingsTab,changed=dirty.includes(id),automatic=auto.get(id);
      tab.dataset.dirty=String(changed);tab.dataset.autoState=automatic||'';
      tab.setAttribute('aria-label',tab.querySelector('span').textContent+(changed?'，有未保存修改':automatic==='error'?'，自动保存失败':''));
    }
    close.textContent=dirty.length?'取消未保存':'关闭';
    const writing=[...auto].filter(([,value])=>value==='saving').map(([id])=>names[id]);
    const errors=[...auto].filter(([,value])=>value==='error').map(([id])=>names[id]);
    if(saving){status.dataset.state='saving';status.textContent='正在保存普通设置…';}
    else if(failed){status.dataset.state='error';status.textContent='保存失败'+(dirty.length?'：'+dirty.map(id=>names[id]).join('、'):'')+' · 可重试';}
    else if(errors.length){status.dataset.state='error';status.textContent='操作未完成：'+errors.join('、')+' · 详见该页';}
    else if(writing.length){status.dataset.state='saving';status.textContent='正在保存：'+writing.join('、');}
    else if(dirty.length){status.dataset.state='dirty';status.textContent='未保存：'+dirty.map(id=>names[id]).join('、');}
    else{status.dataset.state='clean';status.textContent='全部已保存';}
    status.title=status.textContent;
  };
  for(const id of manual)for(const name of ['input','change'])doc.getElementById(id).addEventListener(name,update);
  dialog.addEventListener('toggle',()=>{if(dialog.open){initial=draft();failed=false;saving=dialog.dataset.saving==='true';save.disabled=saving;update();layout();}});
  dialog.addEventListener('settings-saving',()=>{submitted=draft();failed=false;saving=true;save.disabled=true;update();});
  dialog.addEventListener('settings-save-failed',()=>{failed=true;saving=false;save.disabled=false;update();});
  dialog.addEventListener('settings-saved',()=>{failed=false;saving=false;save.disabled=false;initial=submitted||draft();update();});
  dialog.addEventListener('settings-save-settled',()=>{saving=false;save.disabled=false;update();});
  doc.addEventListener('settings-auto-status',event=>{const {section,state}=event.detail||{};if(!['appearance','floating'].includes(section)||!['saving','saved','error'].includes(state))return;auto.set(section,state);update();});
}
export function initInterface(doc=document){
  const form=doc.querySelector('#home-translation-form');
  if(!form || form.dataset.enhanced)return;form.dataset.enhanced='true';
  form.addEventListener('submit',event=>{event.preventDefault();submitHomeText(doc);});
  doc.querySelector('#home-source-text').addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();event.stopPropagation();form.requestSubmit();}});
  const input=doc.querySelector('#home-source-text');
  // Presentation only. The same input/submit handlers retain ownership of translation.
  const fit=()=>{
    if(!input.clientWidth)return;
    const style=doc.defaultView.getComputedStyle(input),min=parseFloat(style.minHeight)||84,max=parseFloat(style.maxHeight)||280;
    input.style.height='auto';input.style.height=Math.min(max,Math.max(min,input.scrollHeight))+'px';
    input.style.overflowY=input.scrollHeight>max?'auto':'hidden';
  };
  input.addEventListener('input',fit);fit();
  if(doc.defaultView.ResizeObserver){let width=-1;new doc.defaultView.ResizeObserver(entries=>{const next=entries[0].contentRect.width;if(next!==width){width=next;fit();}}).observe(input);}
  enhanceSettings(doc);
}
if(typeof document!=='undefined')initInterface();
