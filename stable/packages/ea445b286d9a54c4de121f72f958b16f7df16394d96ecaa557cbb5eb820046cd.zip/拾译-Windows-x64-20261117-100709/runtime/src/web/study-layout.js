/** Conservative annotation-edition zoning. Generic research papers use the existing parser. */
const han=value=>(value.match(/\p{Script=Han}/gu) || []).length;
const latin=value=>(value.match(/[A-Za-z]/g) || []).length;
const mode=values=>{
  const bins=new Map();for(const [n,w] of values){const key=Math.round(n*2)/2;bins.set(key,(bins.get(key)||0)+w);}
  return [...bins].sort((a,b)=>b[1]-a[1])[0]?.[0] || 11;
};
const ordinary=s=>Math.abs(s.angle)<12 && s.text;

export function studyLayout(spans,regions,width,height,columns){
  const upright=spans.filter(ordinary),text=upright.map(s=>s.text).join(' ');
  const study=/(?:思维导图|句子大意|黑色主句|本句承接|本句引出)/.test(text) && han(text)>Math.max(20,latin(text)*.22);
  // Study pages are preserved as a real PDF page, not linearized into fake prose/graphs.
  if(study)return {kind:'study-material',confidence:'explicit-label',tags:[/思维导图/.test(text)?'mind-map':null,/句子大意|主句|长难句/.test(text)?'sentence-analysis':null].filter(Boolean)};
  const vertical=regions.filter(r=>r.kind==='rule' && r.orientation==='vertical' && r.rect[0]>width*.35 && r.rect[2]<width*.7);
  const groups=new Map();for(const r of vertical){const key=Math.round((r.rect[0]+r.rect[2])/2);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);}
  const supported=[...groups].map(([x,values])=>({x,values,total:values.reduce((n,r)=>n+r.rect[3]-r.rect[1],0)})).sort((a,b)=>b.total-a.total)[0];
  const edge=mode(upright.filter(s=>s.fontSize<=10 && s.rect[0]>width*.42 && s.rect[0]<width*.65).map(s=>[s.rect[0],1]));
  const gutter=supported?.total>height*.025?supported.x:(columns.gutter || (edge>width*.42?edge-4:null));
  if(!gutter)return null;
  const right=upright.filter(s=>(s.rect[0]+s.rect[2])/2>gutter && s.rect[1]>height*.05 && s.rect[3]<height*.95);
  const left=upright.filter(s=>(s.rect[0]+s.rect[2])/2<gutter && s.rect[1]>height*.05 && s.rect[3]<height*.95);
  const noteText=right.map(s=>s.text).join(' '),noteSize=mode(right.map(s=>[s.fontSize,s.text.length]));
  const candidates=left.filter(s=>latin(s.text)>han(s.text)*3 && latin(s.text)>2 && s.fontSize>noteSize*1.17 && s.fontSize<noteSize*3);
  const bodySize=mode(candidates.map(s=>[s.fontSize,s.text.length]));
  const vocabulary=(noteText.match(/\bSYN\b|\b(?:adj|adv|prep)\.|\b[nv]\.\s/gi)||[]).length;
  if(han(noteText)<8 || latin(noteText)<35 || vocabulary<1 || bodySize<noteSize*1.17 || !candidates.length)return null;
  const bodyLeft=Math.min(...candidates.map(s=>s.rect[0]));
  const learning=left.filter(s=>/全文逻辑梳理|写作练习/.test(s.text));
  const learningTop=learning.length?Math.min(...learning.map(s=>s.rect[1])):Infinity;
  const rules=regions.filter(r=>r.kind==='rule' && r.orientation==='horizontal' && r.rect[1]>height*.45 && r.rect[1]<height*.94 &&
    Math.abs(r.rect[0]-bodyLeft)<bodySize && r.rect[2]-r.rect[0]<(gutter-bodyLeft)*.6 && r.rect[2]-r.rect[0]>bodySize*4);
  const foot=rules.filter(r=>left.some(s=>s.rect[1]>=r.rect[1] && s.rect[1]<r.rect[1]+bodySize*2 && s.fontSize<bodySize*.8 && /[*†‡]|\p{Script=Han}/u.test(s.text)));
  return {kind:'annotated-article',confidence:supported?'painted-rule-and-language':'font-and-language',gutter,bodySize,noteSize,bodyLeft,
    footnoteTop:foot.length?Math.min(...foot.map(r=>r.rect[1])):null,learningTop:Number.isFinite(learningTop)?learningTop:null,
    separators:supported?.values.map(r=>r.rect) || []};
}

export function prepareStudySpans(spans,layout,height){
  if(!layout)return;
  for(const s of spans){
    let role='article';
    if(Math.abs(s.angle)>12)role='watermark';
    else if(layout.kind==='study-material')role='learning';
    else if(s.rect[3]<height*.06)role='header';
    else if(s.rect[1]>height*.95)role='footer';
    else if((s.rect[0]+s.rect[2])/2>layout.gutter)role='vocabulary';
    else if(layout.learningTop!==null && s.rect[1]>=layout.learningTop-2)role='learning';
    else if(layout.footnoteTop!==null && s.rect[1]>=layout.footnoteTop-1)role='footnote';
    else if(s.fontSize<layout.bodySize*.88){
      const inline=/^[\d*†‡]{1,2}$/.test(s.text) && spans.some(t=>t!==s && t.fontSize>=layout.bodySize*.95 && t.fontSize<layout.bodySize*1.3 && Math.abs(t.baseline-s.baseline)<layout.bodySize*.8 && Math.abs(t.rect[0]-s.rect[2])<layout.bodySize);
      const caps=/^[A-Z\s]+$/.test(s.text) && latin(s.text)>5 && spans.some(t=>/^[A-Z]$/.test(t.text) && t.fontSize>layout.bodySize*2.5 && s.rect[1]>=t.rect[1]-layout.bodySize && s.rect[1]<t.rect[3]);
      role=inline || caps?'article':han(s.text)>3?'existing_translation':s.rect[1]<height*.12?'metadata':'existing_translation';
    }
    else if(han(s.text)>3 && latin(s.text)===0 && s.fontSize>layout.bodySize*1.1 && s.rect[1]<height*.22)role='existing_translation';
    else if(s.fontSize<layout.bodySize*.88 && s.rect[1]<height*.12 && latin(s.text)>3)role='metadata';
    s.role=role;
  }
  if(layout.kind!=='annotated-article')return;
  // Drop caps span several visual lines. Attach the initial to the first line,
  // while retaining the original transform, box, size and original baseline.
  for(const cap of spans.filter(s=>s.role==='article' && /^[A-Z]$/.test(s.text) && s.fontSize>layout.bodySize*2.5)){
    const next=spans.filter(s=>s!==cap && s.role==='article' && s.fontSize<layout.bodySize*1.2 && latin(s.text)>1 &&
      s.rect[0]>=cap.rect[2]-layout.bodySize*.6 && s.rect[1]>=cap.rect[1]-layout.bodySize && s.rect[1]<cap.rect[3]-layout.bodySize*.4)
      .sort((a,b)=>a.rect[1]-b.rect[1])[0];
    if(next){cap.originalBaseline=cap.baseline;cap.baseline=next.baseline;cap.dropCap=true;}
  }
}

export function studyLineRole(line,spans,layout,height){
  line.role=spans.find(s=>s.text)?.role || 'article';
  if(line.role==='header'){line.kind='header';return;}
  if(line.role==='footer'){line.kind='footer';return;}
  if(line.role==='watermark'){line.kind='rotated';return;}
  if(line.role==='footnote'){line.kind='footnote';return;}
  if(line.role!=='article'){line.kind='body';return;}
  line.typicalFontSize=layout.bodySize;
  if(spans.some(s=>s.dropCap)){line.fontSize=layout.bodySize;line.dropCap=true;}
  const first=spans.find(s=>s.text);
  if(first && /^\d{1,2}$/.test(first.text) && first.fontSize<layout.bodySize*.72 && first.rect[0]<layout.bodyLeft)line.editorialNumber=Number(first.text);
  if(line.fontSize<layout.bodySize*.96 && line.fontSize>=layout.bodySize*.88 && line.rect[1]<height*.22)line.kind='subtitle';
  else if(line.rect[1]>height*.3 || line.fontSize<=layout.bodySize*1.04)line.kind='body';
  else if(line.fontSize>=layout.bodySize*1.12 && line.rect[1]<height*.16)line.kind='title';
  else line.kind='subtitle';
}

export function cleanArticleText(text){
  const notes=[];
  const value=text.replace(/[（(](?:本\s*句|详\s*见)[\s\S]{0,65}?[)）]|[\[【](?:本\s*段|翻译练习)[\s\S]{0,65}?[\]】]/g,match=>{notes.push(match);return '';});
  return {text:value.replace(/\s+([,.;:!?])/g,'$1').replace(/\s+/g,' ').trim(),editorialNotes:notes};
}
