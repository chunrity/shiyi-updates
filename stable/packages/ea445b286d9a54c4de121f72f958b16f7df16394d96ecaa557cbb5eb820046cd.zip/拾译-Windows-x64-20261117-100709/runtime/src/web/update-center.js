export const softwareUpdateMarkup = `
  <section class="software-update" aria-labelledby="software-update-heading">
    <header class="update-header">
      <h4 id="software-update-heading">软件更新</h4>
      <span id="software-update-badge" class="update-badge" data-state="loading" role="status">正在读取状态</span>
    </header>
    <dl class="update-identity">
      <div><dt>当前版本</dt><dd id="settings-software-version">—</dd></div>
      <div><dt>构建编号</dt><dd id="software-update-build">—</dd></div>
      <div><dt>更新器版本</dt><dd id="software-update-engine">—</dd></div>
    </dl>
    <p id="software-update-detail" class="update-detail" aria-live="polite">正在读取本机更新状态。</p>
    <div id="software-update-offer" class="update-offer" hidden>
      <div class="update-offer-heading"><strong id="software-update-release"></strong><span id="software-update-meta"></span></div>
      <p id="software-update-notes"></p>
    </div>
    <div id="software-update-transfer" class="update-transfer" hidden>
      <progress id="software-update-progress" aria-label="安装包下载进度"></progress>
      <span id="software-update-bytes"></span>
    </div>
    <div class="update-actions">
      <button type="button" class="secondary" id="software-update-check" disabled>检查更新</button>
      <button type="button" class="primary" id="software-update-action" hidden></button>
    </div>
    <label class="update-automatic">
      <span><strong>自动检查更新</strong><small>随桌面启动在后台检查，不会自动安装。此开关即时保存。</small></span>
      <input type="checkbox" class="switch" id="software-update-auto" disabled>
    </label>
  </section>`;

const labels = {
  idle: ['尚未检查', '可以手动检查是否有新的稳定版本。'],
  unconfigured: ['更新服务尚未配置', '连接正式更新源后，此处将显示可用版本。'],
  current: ['已是最新版本', '当前运行版本与更新源的稳定版本一致。'],
  'already-installed': ['已是最新版本', '这次更新已经安装。'],
  installed: ['更新已安装', '正在使用刚安装的版本。'],
  available: ['发现新版本', '可先下载完整安装包，安装时间由你决定。'],
  checking: ['正在检查', '正在连接更新源并验证版本清单。'],
  downloading: ['正在下载', '可以继续阅读，或暂停后再继续下载。'],
  'cancel-requested': ['正在暂停', '正在保留已下载部分。'],
  cancelled: ['下载已暂停', '可以从保留的部分继续下载。'],
  interrupted: ['任务已中断', '可以重试，有可用的下载部分时会尝试续传。'],
  downloaded: ['等待安装', '安装包已校验。确认后会保存阅读进度并重启拾译。'],
  installing: ['正在准备安装', '更新助手正在确认安装包和当前运行实例。'],
  busy: ['更新任务忙碌', '请稍后再试。'],
  'network-failed': ['当前网络不可用', '未能连接更新源或下载中断。可以继续阅读，稍后重试。'],
  'verification-failed': ['更新验证失败', '版本签名或安装包完整性校验未通过。请重试。'],
  incompatible: ['更新不兼容', '版本、平台或数据兼容条件未满足。'],
  'insufficient-space': ['磁盘空间不足', '可用空间不足以下载并解包。'],
  'local-failed': ['更新失败', '本地更新组件或暂存文件暂不可用，请重试。'],
  'install-failed': ['安装未完成', '安装准备或候选启动检查未通过。可继续使用当前版本。'],
  'restart-failed': ['需要手动启动', '安装流程已结束。请通过桌面拾译入口重新打开。'],
  'download-required': ['请重新下载', '暂存包已不可用，需重新下载并验证。'],
  'cleanup-deferred': ['更新暂存仍在使用', '请稍后重试，现有版本仍可使用。'],
  'helper-required': ['需要新版更新组件', '请使用带有新版更新组件的拾译安装包。'],
};
const active = new Set(['checking', 'downloading', 'cancel-requested', 'installing']);
const paused = new Set(['interrupted', 'cancelled', 'network-failed', 'download-required', 'install-failed', 'verification-failed', 'local-failed']);
const releaseDate = new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });

function bytes(value) {
  if (value >= 1048576) return (value / 1048576).toFixed(2) + ' MiB';
  if (value >= 1024) return (value / 1024).toFixed(1) + ' KiB';
  return value + ' B';
}

export function attachUpdateCenter(dialog, { api, confirm, saveReading }) {
  if (!dialog) return { refresh() {} };
  const field = name => dialog.querySelector('#software-update-' + name);
  const visible = () => dialog.open && dialog.dataset.settingsActive === 'about' && field('badge');
  let state, timer, reading = false, working = false, refreshAgain = false, epoch = 0, feedback = '';

  function render() {
    if (!visible() || !state) return;
    const { status, offer, can_install: install, can_cancel: cancel, downloaded_bytes: count } = state;
    const [title, detail] = labels[status] || labels.idle;
    const badge = field('badge');
    if (badge.textContent !== title) badge.textContent = title;
    badge.dataset.state = status;
    if (field('detail').textContent !== (feedback || detail)) field('detail').textContent = feedback || detail;
    if (state.current_version) dialog.querySelector('#settings-software-version').textContent = state.current_version;
    field('build').textContent = state.current_build || '—';
    field('engine').textContent = state.updater_version || '—';
    field('offer').hidden = !offer;
    if (offer) {
      field('release').textContent = '版本 ' + offer.version;
      field('meta').textContent = releaseDate.format(offer.published_at_unix * 1000) + ' · ' + bytes(offer.total_bytes);
      field('notes').textContent = offer.release_notes || '本版本没有附加更新说明。';
    }
    const showTransfer = offer && (status === 'downloading' || status === 'cancel-requested' || (count > 0 && paused.has(status)));
    field('transfer').hidden = !showTransfer;
    if (showTransfer) {
      const progress = field('progress');
      progress.max = offer.total_bytes;
      progress.value = count;
      field('bytes').textContent = bytes(count) + ' / ' + bytes(offer.total_bytes) + ' · ' + Math.floor(100 * count / offer.total_bytes) + '%';
    }
    const action = field('action');
    let choice;
    if (cancel) choice = ['cancel', '暂停下载'];
    else if (!active.has(status) && install) choice = ['install', '重启并安装'];
    else if (!active.has(status) && offer && (status === 'available' || paused.has(status))) {
      choice = ['download', count > 0 ? '继续下载' : (status === 'available' ? '下载安装包' : '重新下载')];
    }
    action.hidden = !choice;
    if (choice) {
      action.dataset.operation = choice[0];
      action.textContent = choice[1];
      action.className = cancel ? 'secondary' : 'primary';
    }
    action.disabled = working;
    field('check').disabled = working || active.has(status) || !state.configured;
    field('auto').disabled = working || !state.available;
    field('auto').checked = state.auto_check;
  }

  function schedule() {
    clearTimeout(timer);
    if (visible() && state && active.has(state.status)) timer = setTimeout(refresh, 1100);
  }

  async function refresh() {
    clearTimeout(timer);
    if (!visible()) return;
    if (reading || working) { refreshAgain = true; return; }
    reading = true;
    const generation = epoch;
    try {
      const result = await api('software-update');
      if (generation === epoch) { state = result; render(); }
    } catch {
      if (generation === epoch) {
        state = { ...state, status: 'local-failed', configured: state?.configured ?? true, offer: null };
        render();
      }
    } finally {
      reading = false;
      if (refreshAgain && !working) { refreshAgain = false; if (visible()) refresh(); }
      else schedule();
    }
  }

  async function act(operation, value) {
    if (working || !visible()) return;
    working = true;
    ++epoch;
    clearTimeout(timer);
    feedback = '';
    render();
    try {
      if (operation === 'install') {
        if (!await confirm('重启并安装 ' + state.offer.version + '？',
          '将保存阅读进度并关闭当前窗口。安装完成后会重新打开拾译，进行中的翻译会结束。', '重启并安装')) return;
        await saveReading();
      }
      state = await api('software-update', { action: operation, ...value });
    } catch (error) {
      feedback = error.message || '操作未完成，请重试。';
    } finally {
      working = false;
      render();
      if (refreshAgain) { refreshAgain = false; refresh(); }
      else schedule();
    }
  }

  dialog.addEventListener('click', event => {
    if (event.target === field('check')) act('check');
    if (event.target === field('action') && state) {
      const operation = event.target.dataset.operation;
      act(operation, operation === 'install' ? { build_id: state.offer.build_id, confirmed: true } : undefined);
    }
  });
  dialog.addEventListener('change', event => {
    if (event.target === field('auto')) act('auto-check', { enabled: event.target.checked });
  });
  dialog.addEventListener('settings-tab-change', refresh);
  dialog.addEventListener('close', () => { ++epoch; clearTimeout(timer); feedback = ''; });
  return { refresh };
}
