/** Read-only adapter over existing PDF structure. No PDF extraction or AI logic here. */
const word=/^[a-z]+(?:['’‐‑-][a-z]+)*$/i;
const normalize=s=>String(s || '').replace(/\s+/g,' ').trim();
const headPattern=/^[A-Za-z]+(?:['’‐‑-][A-Za-z]+)*(?: [A-Za-z]+(?:['’‐‑-][A-Za-z]+)*){0,4}(?: \((?:in|of|to|for|with) sth\))?$/;
const irregular={came:'come',rose:'rise',risen:'rise',bought:'buy',took:'take',taken:'take',built:'build',went:'go',gone:'go',was:'be',were:'be',has:'have',had:'have',made:'make',fell:'fall',fallen:'fall',said:'say',grew:'grow',grown:'grow'};
export function wordForms(value){
  const text=value.toLowerCase(),out=new Set([text]);if(irregular[text])out.add(irregular[text]);
  if(text.endsWith('ies'))out.add(text.slice(0,-3)+'y');
  if(text.endsWith('s') && !text.endsWith('ss'))out.add(text.slice(0,-1));
  if(text.endsWith('es'))out.add(text.slice(0,-2));
  for(const suffix of ['ing','ed'])if(text.length>suffix.length+2 && text.endsWith(suffix)){
    const stem=text.slice(0,-suffix.length);out.add(stem);out.add(stem+'e');
    if(/([b-df-hj-np-tv-z])\1$/.test(stem))out.add(stem.slice(0,-1));
    if(suffix==='ed' && stem.endsWith('i'))out.add(stem.slice(0,-1)+'y');
  }
  return out;
}
export function sentenceForWord(target,context,hint=''){
  const text=normalize(context);if(!word.test(target) || !text)return '';
  const pattern=new RegExp('(?<![A-Za-z])'+target.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?![A-Za-z])','gi');
  let hits=[...text.matchAll(pattern)].map(m=>m.index);if(!hits.length)return '';
  const prefix=normalize(hint).slice(-100).toLowerCase();
  if(hits.length>1 && prefix.length>target.length){const filtered=hits.filter(i=>text.slice(Math.max(0,i+target.length-prefix.length),i+target.length).toLowerCase()===prefix);if(filtered.length)hits=filtered;}
  if(hits.length!==1)return ''; // Do not guess which occurrence has been selected.
  const index=hits[0];
  const segments=typeof Intl.Segmenter==='function'?[...new Intl.Segmenter('en',{granularity:'sentence'}).segment(text)]:[{segment:text,index:0}];
  const part=segments.find(s=>index>=s.index && index<s.index+s.segment.length);
  return part && part.segment.length<=1800?part.segment.trim():'';
}
export function selectionHint(selection,text){
  if(!selection?.rangeCount)return '';
  const range=selection.getRangeAt(0),node=range.startContainer;
  if(node.nodeType!==3)return '';
  return node.textContent.slice(0,range.startOffset)+text;
}
export function buildPdfGlossary(structure){
  const entries=[];
  for(const page of structure?.pages || []){
    if(page.classification?.kind!=='annotated-article')continue;
    const map=new Map(page.spans.map(s=>[s.itemIndex,s]));
    const notes=page.spans.filter(s=>s.role==='vocabulary' && s.text);
    if(!notes.length)continue;
    const left=Math.min(...notes.map(s=>s.rect[0]));
    const fonts=new Set(page.paragraphs.filter(p=>p.role==='vocabulary').flatMap(p=>{
      const first=map.get(p.itemIndices[0]);if(!first || !headPattern.test(first.text) || first.rect[0]>=left+12)return [];
      const tail=p.text.slice(first.text.length).trim();
      return /^(?:\/[^/]+\/\s*)?(?:\[[^\]]*\]\s*)?(?:adj|adv|prep|pron|conj|n|v)\./.test(tail)?[first.fontName]:[];
    }));
    const spans=page.lines.filter(l=>l.role==='vocabulary').sort((a,b)=>a.rect[1]-b.rect[1]).flatMap(l=>l.itemIndices.map(i=>map.get(i)).filter(Boolean));
    let current=null;
    const flush=()=>{
      if(!current)return;
      const raw=normalize(current.parts.join(' ')),tail=raw.slice(current.head.length).trim();
      const chinese=tail.search(/\p{Script=Han}/u),syn=tail.search(/\bSYN\b/);
      // An example translation after SYN is not the entry's definition.
      if(chinese<0 || (syn>=0 && syn<chinese))return;
      const lead=tail.slice(0,chinese).replace(/\/[^/]+\//g,'').replace(/\[[^\]]*\]/g,'').trim();
      if(/^(?:Now|He |She |They |We |I |The brand|For example)/.test(lead))return;
      let meaning=(tail.slice(0,chinese).trimEnd().endsWith('(')?'(':'')+tail.slice(chinese).split(/\bSYN\b|\s+(?=[A-Za-z][A-Za-z-]*\b)/)[0].trim().replace(/[\s(（,;:]+$/,'');
      meaning=meaning.replace(/(?<=\p{Script=Han})\s+(?=\p{Script=Han})/gu,'').replace(/\s+([,;，。；])/g,'$1').replace(/([（(])\s+/g,'$1');
      if(meaning.length<2 || meaning.length>240)return;
      const pos=tail.match(/\b(adj|adv|prep|pron|conj|n|v)\./)?.[0] || '';
      entries.push({head:current.head,lemma:current.head.replace(/\s*\([^)]*\)/g,'').toLowerCase(),meaning,pos,raw,page:page.pageNumber,id:current.id});
    };
    for(const span of spans){
      const text=normalize(span.text);if(!text)continue;
      const heading=fonts.has(span.fontName) && span.rect[0]<left+12 && headPattern.test(text) && text!=='SYN';
      if(heading){flush();current={head:text,parts:[],id:span.id};}
      current?.parts.push(text);
    }
    flush();
  }
  return entries;
}
export function matchPdfGlossary(entries,target,sentence,page){
  if(!word.test(target) || !sentence)return null;
  const forms=wordForms(target),lower=sentence.toLowerCase();
  const hits=entries.filter(e=>e.page===page).flatMap(entry=>{
    const parts=entry.lemma.split(' ');
    if(!parts.some(part=>forms.has(part)))return [];
    const tokens=lower.match(/[a-z]+(?:['’‐‑-][a-z]+)*/g) || [];
    const occurs=tokens.some((token,i)=>i+parts.length<=tokens.length && tokens.slice(i,i+parts.length).includes(target.toLowerCase()) && parts.every((part,j)=>wordForms(tokens[i+j]).has(part)));
    if(!occurs)return [];
    return [{entry,score:(parts.length===1?100:parts.length*10)+(entry.lemma===target.toLowerCase()?1:0)}];
  }).sort((a,b)=>b.score-a.score);
  if(!hits.length)return null;
  const best=hits.filter(h=>h.score===hits[0].score);
  if(new Set(best.map(h=>h.entry.meaning)).size!==1)return null;
  return best[0].entry;
}
const indices=new WeakMap();
export function localLookup({text,context,hint='',structure,page,source='en',target='zh-CN'}){
  if(!word.test(text) || !['en','auto'].includes(source) || target!=='zh-CN')return null;
  const sentence=sentenceForWord(text,context,hint);if(!sentence)return null;
  if(structure && !indices.has(structure))indices.set(structure,buildPdfGlossary(structure));
  const match=matchPdfGlossary(indices.get(structure) || [],text,sentence,page);
  const direct=match && (!match.lemma.includes(' ') || ((/^v\./.test(match.pos) || /^[a-z-]+ (?:up|down|out|off|on|in|away|back|over|through)$/.test(match.lemma)) && wordForms(text).has(match.lemma.split(' ')[0])));
  return {sentence,supplement:match && !direct?match.raw:'',result:direct?{source:text,text:match.meaning,headword:match.head,pos:match.pos,isWord:true,lookupKind:'pdf',engine:'PDF 原文释义 · 第 '+match.page+' 页',sentence,contextNote:match.lemma.includes(' ')?'此处按短语 '+match.head+' 理解。':'',originalNote:match.raw,noteId:match.id}:null};
}
