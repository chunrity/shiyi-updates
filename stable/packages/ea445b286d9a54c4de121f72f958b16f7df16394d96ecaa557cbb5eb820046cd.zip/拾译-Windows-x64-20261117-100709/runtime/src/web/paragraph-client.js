/** Translation task client. No DOM, PDF.js, layout, or page rendering dependencies. */
export class ParagraphClient{
  constructor(api,{changed=()=>{},error=()=>{},storage=globalThis.localStorage,delay=700}={}){
    this.api=api;this.changed=changed;this.error=error;this.storage=storage;this.delay=delay;
    this.jobs=new Map();this.polls=new Map();this.lastJobs=new Map();this.restores=new Map();
  }
  jobKey(doc){return 'shiyi:paragraph-job:'+doc;}
  async submit(manifest,options,{ids=manifest.target_ids,force=false}={}){
    const response=await this.api('translation-jobs',{...manifest,target_ids:ids,options,force});
    this.accept(response);this.watch(response.job_id);return response;
  }
  accept(job){
    const existing=this.jobs.get(job.job_id);
    if(existing){const items=new Map(existing.items?.map(item=>[item.paragraph_id,item]) || []);for(const item of job.items || [])items.set(item.paragraph_id,item);job={...job,items:[...items.values()].sort((a,b)=>a.reading_order-b.reading_order)};}
    this.jobs.set(job.job_id,job);
    const previous=this.jobs.get(this.lastJobs.get(job.document_id));
    if(!previous || job.created>=previous.created){
      this.lastJobs.set(job.document_id,job.job_id);
      try{this.storage?.setItem(this.jobKey(job.document_id),job.job_id);}catch{}
    }
    this.changed(job);
  }
  async restore(doc){
    let id=this.lastJobs.get(doc);try{id ||= this.storage?.getItem(this.jobKey(doc));}catch{}
    if(!id)return null;
    const existing=this.jobs.get(id);if(existing){this.watch(id);return existing;}
    if(this.restores.has(id))return this.restores.get(id);
    const pending=(async()=>{
      try{const job=await this.api('translation-jobs/'+encodeURIComponent(id));this.accept(job);this.watch(id);return job;}
      catch{try{this.storage?.removeItem(this.jobKey(doc));}catch{}return null;}
      finally{this.restores.delete(id);}
    })();this.restores.set(id,pending);return pending;
  }
  watch(id){
    if(this.polls.has(id) || this.jobs.get(id)?.status!=='active')return;
    const timer=setTimeout(async()=>{
      this.polls.delete(id);
      try{const response=await this.api('translation-jobs/'+encodeURIComponent(id)+'?since='+(this.jobs.get(id)?.revision || 0));this.accept(response);this.watch(id);}
      catch(error){this.error(error);if(this.jobs.get(id)?.status==='active')this.watch(id);}
    },this.delay);
    this.polls.set(id,timer);
  }
  async cancel(doc){
    const id=this.lastJobs.get(doc);if(!id)return;
    const job=await this.api('translation-jobs/cancel',{job_id:id});this.accept(job);return job;
  }
  async results(doc,pageNumber=null,options={}){
    const query=new URLSearchParams({doc,limit:'200'});if(pageNumber!==null)query.set('page',pageNumber);
    for(const [key,value] of Object.entries(options))query.set(key,value);
    const items=[];let response;
    do{query.set('offset',items.length);response=await this.api('paragraph-translations?'+query);items.push(...response.items);}
    while(response.items.length===200);
    return {...response,items};
  }
  close(){for(const timer of this.polls.values())clearTimeout(timer);this.polls.clear();}
}
