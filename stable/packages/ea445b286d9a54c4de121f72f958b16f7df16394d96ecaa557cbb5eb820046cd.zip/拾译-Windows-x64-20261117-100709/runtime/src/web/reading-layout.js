// Compatibility adapter for the existing reader and its OCR text layer.
import {analyzePdfPage} from './pdf-structure.js';
export {joinLines} from './text-reflow.js';
export {analyzePdfPage,buildDocumentStructure,imageRegionsFromOperators,layoutRegionsFromOperators,STRUCTURE_VERSION} from './pdf-structure.js';

export function groupPdfItems(items,pageWidth,mode='auto',options={}){
  const page=analyzePdfPage({...options,items,width:pageWidth,mode,
    source:options.source || (items.some(i=>i.ocr)?'ocr':'pdf-text')});
  return {paragraphs:page.paragraphs.filter(p=>!p.isDecoration && p.translatable!==false),allParagraphs:page.paragraphs,
    columns:page.columns,gutter:page.gutter,page};
}

export function ocrItems(result,pageWidth,pageHeight,options={}){
  if(!(result.width>0) || !(result.height>0))return [];
  const sx=pageWidth/result.width,sy=pageHeight/result.height;
  const m=options.transform || [1,0,0,-1,0,pageHeight],det=m[0]*m[3]-m[1]*m[2];
  if(!det)return [];
  const inverse=[m[3]/det,-m[1]/det,-m[2]/det,m[0]/det,(m[2]*m[5]-m[3]*m[4])/det,(m[1]*m[4]-m[0]*m[5])/det];
  return (result.lines || []).flatMap(line=>{
    const words=line.words || [];if(!words.length)return [];
    const heights=words.map(w=>w.height).sort((a,b)=>a-b),fontSize=heights[Math.floor(heights.length/2)]*sy;
    const bottom=Math.max(...words.map(w=>w.y+w.height));
    return words.map((word,i)=>{
      const x=word.x*sx,y=bottom*sy-fontSize*.2;
      return {str:word.text+(i<words.length-1?' ':''),
        transform:[inverse[0]*fontSize,inverse[1]*fontSize,-inverse[2]*fontSize,-inverse[3]*fontSize,
          inverse[0]*x+inverse[2]*y+inverse[4],inverse[1]*x+inverse[3]*y+inverse[5]],
        width:word.width*sx,height:fontSize,hasEOL:i===words.length-1,ocr:word};
    });
  });
}
