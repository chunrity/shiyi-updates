/** Conservative arbitration for saved page OCR. No persistence or text mutation.
 * A verified native annotated article retains fonts/semantic zones which OCR may
 * lose. Sparse, scanned, damaged and unclassified native pages keep OCR behavior.
 */
export function preferNativeArticle(page,ocr){
  if(!ocr || page?.source!=='pdf-text' || page.textLayer!=='usable' ||
    page.classification?.kind!=='annotated-article')return false;
  const text=page.paragraphs.filter(p=>p.role==='article' && p.translatable!==false).map(p=>p.text).join(' ');
  if((text.match(/[A-Za-z]/g)||[]).length<80)return false;
  // Do not overrule OCR when the native layer contains undecodable glyphs.
  if(/[\uFFFD\u0000-\u0008\u000E-\u001F\uE000-\uF8FF]/u.test(text))return false;
  if(!(ocr.width>0 && ocr.height>0))return false;
  // A mixed image/text page may have only a native title. Keep OCR when it
  // contains substantial body text outside the native lines (not their union).
  const lines=page.lines.filter(line=>line.role==='article');
  const zone=page.classification;let total=0,covered=0;
  for(const word of (ocr.lines || []).flatMap(line=>line.words || [])){
    const letters=(String(word.text || '').match(/[A-Za-z]/g)||[]).length;
    if(letters<3)continue;
    const x=(word.x+word.width/2)*page.width/ocr.width,y=(word.y+word.height/2)*page.height/ocr.height;
    if(!Number.isFinite(x+y) || x>=zone.gutter || y<page.height*.05 ||
      y>(zone.footnoteTop ?? page.height*.95))continue;
    total+=letters;
    if(lines.some(line=>{const r=line.rect,pad=Math.max(2,page.bodyFontSize/3);
      return x>=r[0]-pad && x<=r[2]+pad && y>=r[1]-pad && y<=r[3]+pad;
    }))covered+=letters;
  }
  return total>=40 && covered/total>=.9;
}
