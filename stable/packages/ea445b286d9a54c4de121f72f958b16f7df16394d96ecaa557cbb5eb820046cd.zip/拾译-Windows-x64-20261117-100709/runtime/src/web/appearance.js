/** Appearance only. No reader, canvas, translation or navigation operations. */
export const defaults={accent:'#7c6cb0',background:'#f6f3fa',surface:'#ffffff',text:'#242432',cardOpacity:86,imageOpacity:100,maskOpacity:50,blur:0,homeOnly:false,image:''};
export const layoutDefaults={backgroundFit:'contain',backgroundPosition:'center',backgroundSmartFill:false};
export const backgroundMode=settings=>settings.backgroundSmartFill===true?'smart':(['contain','cover'].includes(settings.backgroundFit)?settings.backgroundFit:layoutDefaults.backgroundFit);
const layoutKey={imageFit:'backgroundFit',imagePosition:'backgroundPosition'};
const owned=['--bg','--surface','--ink','--muted','--brand','--accent','--accent-hover','--action-bg','--action-ink','--soft','--hover','--selection','--line','--border-strong','--sidebar','--theme-card','--theme-image-opacity','--theme-mask-opacity','--theme-blur','--theme-background-fit','--theme-background-position'];
let asset='',objectURL='',generation=0,softURL='',smartPromise=null;
const token=()=>document.querySelector('meta[name="app-token"]')?.content;
const status=(text,result)=>{const e=document.querySelector('#appearance-status');if(e)e.textContent=text;
 const state=result||(/失败|不可用|移除|请选择|过大|超过|不支持/.test(text)?'error':/正在|待保存/.test(text)?'saving':text==='已保存'?'saved':null);
 if(state)document.dispatchEvent(new CustomEvent('settings-auto-status',{detail:{section:'appearance',state}}));
};
function readable(hex){const rgb=hex.slice(1).match(/../g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722>.179?'#16191f':'#ffffff';}
function resetSmart(){
 document.body.removeAttribute('data-smart-ready');
 const layer=document.querySelector('.theme-smart-background');
 if(layer){layer.replaceChildren();layer.style.removeProperty('background-image');layer.removeAttribute('data-image');}
 if(softURL){URL.revokeObjectURL(softURL);softURL='';}smartPromise=null;
}
async function prepareSmart(serial){
 if(softURL || !objectURL)return;
 if(smartPromise)return smartPromise;
 const originalURL=objectURL;
 smartPromise=(async()=>{
  try{
   // Decode this source once, then retain the same <img> through mode/size changes.
   const picture=new Image();picture.alt='';picture.draggable=false;picture.decoding='async';picture.src=originalURL;
   await picture.decode();if(serial!==generation)return;
   const ratio=Math.min(1,384/Math.max(picture.naturalWidth,picture.naturalHeight));
   const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(picture.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(picture.naturalHeight*ratio));
   const context=canvas.getContext('2d');context.filter='blur(12px) saturate(0.72) contrast(0.88)';
   // Overscan at the original aspect ratio keeps the softened canvas edges filled.
   const scale=Math.max((canvas.width+72)/picture.naturalWidth,(canvas.height+72)/picture.naturalHeight);
   const width=picture.naturalWidth*scale,height=picture.naturalHeight*scale;
   context.drawImage(picture,(canvas.width-width)/2,(canvas.height-height)/2,width,height);
   const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
   if(serial!==generation)return;if(!blob)throw Error('Background preparation failed');
   let layer=document.querySelector('.theme-smart-background');
   if(!layer){layer=document.createElement('div');layer.className='theme-smart-background';layer.setAttribute('aria-hidden','true');layer.inert=true;document.querySelector('.app-shell').prepend(layer);}
   softURL=URL.createObjectURL(blob);layer.style.backgroundImage=`url("${softURL}")`;
   picture.style.setProperty('--theme-image-aspect',picture.naturalWidth/picture.naturalHeight);
   layer.replaceChildren(picture);layer.dataset.image=asset;document.body.dataset.smartReady='true';
  }catch{
   if(serial===generation){smartPromise=null;status('智能填充暂不可用，已保留完整显示。可重新选择智能填充重试。');}
  }
 })();return smartPromise;
}
async function background(ident,smart){
 if(asset===ident){if(smart)await prepareSmart(generation);return;}asset=ident;const serial=++generation;resetSmart();
 if(objectURL){URL.revokeObjectURL(objectURL);objectURL='';}document.body.style.removeProperty('--theme-image');
 if(!ident)return;
 try{
  const r=await fetch('/api/theme-image/'+ident,{headers:{'X-App-Token':token()}});
  if(!r.ok)throw Error('背景图片不可用，已使用默认背景。可重新选择图片。');
  const blob=await r.blob();if(serial!==generation)return;
  objectURL=URL.createObjectURL(blob);document.body.style.setProperty('--theme-image',`url("${objectURL}")`);
  if(document.body.dataset.theme==='custom'&&document.body.dataset.backgroundFit==='smart')await prepareSmart(serial);
 }catch(e){if(serial===generation)status(e.message);}
}

// One local manifest/image load per session. A missing asset never blocks startup.
let builtinPromise,builtinMessage='正在检查内置插画…';
function builtinNote(){const e=document.querySelector('#appearance-builtin-status');if(e){e.hidden=document.body.dataset.theme!=='anime';e.textContent=builtinMessage;}}
function builtinArt(){
 if(!builtinPromise)builtinPromise=(async()=>{
  try{
   const response=await fetch('/assets/themes/anime-spring/manifest.json');
   if(!response.ok)throw Error('manifest unavailable');const info=await response.json();
   if(info.ready!==true || info.file!=='background.png')throw Error('artwork pending');
   const url='/assets/themes/anime-spring/background.png';const img=new Image();
   await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});
   builtinMessage='内置插画已就绪；选择本地图片可替换。';return url;
  }catch{builtinMessage='正式背景插画尚待提供与确认；当前仅展示配色。可选择自己的本地图片。';return '';}
 })();
 builtinPromise.then(url=>{if(document.body.dataset.theme==='anime'&&url)document.body.style.setProperty('--theme-preset-image',`url("${url}")`);builtinNote();});
 builtinNote();
}

export function applyAppearance(settings){
 const preset=['light','dark','anime','custom'].includes(settings.theme)?settings.theme:'light';
 const c={...defaults,...settings.appearance},b=document.body;
 b.classList.toggle('dark',preset==='dark');b.dataset.theme=preset;b.dataset.backgroundScope=c.homeOnly?'home':'all';
 for(const key of owned)b.style.removeProperty(key);
 if(preset==='anime')builtinArt();else b.style.removeProperty('--theme-preset-image');
 builtinNote();
 if(preset==='custom'){
  const values={'--bg':c.background,'--surface':c.surface,'--ink':c.text,'--muted':`color-mix(in srgb, ${c.text} 76%, ${c.surface})`,'--brand':c.accent,'--accent':c.accent,'--accent-hover':c.accent,'--action-bg':c.accent,'--action-ink':readable(c.accent),'--soft':`color-mix(in srgb, ${c.accent} 12%, ${c.surface})`,'--hover':`color-mix(in srgb, ${c.accent} 8%, ${c.surface})`,'--selection':`color-mix(in srgb, ${c.accent} 24%, ${c.surface})`,'--line':`color-mix(in srgb, ${c.text} 16%, ${c.surface})`,'--border-strong':`color-mix(in srgb, ${c.text} 30%, ${c.surface})`,'--sidebar':c.surface};
  for(const [key,value] of Object.entries(values))b.style.setProperty(key,value);
 }
 b.style.setProperty('--theme-card',`color-mix(in srgb, var(--surface) ${c.cardOpacity}%, transparent)`);
 b.style.setProperty('--theme-image-opacity',c.imageOpacity/100);b.style.setProperty('--theme-mask-opacity',c.maskOpacity/100);b.style.setProperty('--theme-blur',c.blur+'px');
 const fit=backgroundMode(settings);b.dataset.backgroundFit=fit;
 const position=['left','center','right'].includes(settings.backgroundPosition)?settings.backgroundPosition:layoutDefaults.backgroundPosition;
 b.style.setProperty('--theme-background-fit',fit==='smart'?'contain':fit);b.style.setProperty('--theme-background-position',fit==='cover'?position+' center':'center');
 background(c.image,preset==='custom'&&fit==='smart'); // One resource load; softened copy is prepared only on demand.
}
export function setupAppearance({get,save}){
 let mounted=false;
 const mount=()=>{
  const panel=document.querySelector('[data-settings-panel="appearance"]');if(!panel || mounted)return false;mounted=true;
  panel.insertAdjacentHTML('beforeend',`<p class="settings-intro">外观独立自动保存。背景仅作为氛围层，PDF 原页保持原样。</p><div class="settings-group"><h4>主题选择<span class="save-badge">自动保存</span></h4>
   <label class="form-label">主题<select id="appearance-preset"><option value="light">默认浅色</option><option value="dark">默认深色</option><option value="anime">动漫插画 · 春日花海</option><option value="custom">完全自定义</option></select></label>
   <p id="appearance-builtin-status" class="setting-note" role="status"></p></div>
   <figure class="theme-preview" id="appearance-preview" aria-label="当前主题的界面缩略预览"><div class="appearance-preview-scene" aria-hidden="true"><div class="appearance-preview-image"></div><div class="appearance-preview-smart"><img alt="" draggable="false"></div><div class="appearance-preview-mask"></div><div class="appearance-preview-top">拾译 <span>首页</span></div><div class="appearance-preview-content"><strong>让阅读，自然发生。</strong><div class="appearance-preview-card"><b>查询 / 翻译</b><i></i><span>查询 / 翻译</span></div><small>继续阅读</small><div class="appearance-preview-books"><i></i><i></i><i></i></div></div></div></figure>
   <p id="appearance-preview-note" class="setting-note"></p><div id="appearance-options"><div class="settings-group"><h4>背景图片与适配</h4>
   <div class="appearance-background-row"><label class="secondary appearance-upload" for="appearance-image">更换背景<input id="appearance-image" type="file" accept="image/png,image/jpeg,image/webp" aria-label="更换背景图片"></label><span id="appearance-image-source" class="setting-note" role="status"></span></div><p class="setting-note">PNG / JPEG / WebP，最多 8 MB。导入后缩小至最长边 1600 px，独立保存；移动原图片不受影响。</p>
   <div class="appearance-fit-controls"><label class="form-label">背景适配方式<select data-appearance="imageFit"><option value="contain">完整显示（Contain）</option><option value="cover">铺满窗口（Cover）</option><option value="smart">智能填充（Smart Fill）</option></select></label>
   <p class="setting-note">完整显示保留整图；铺满窗口允许裁边；智能填充自动柔化底图、保持原图清晰。新导入竖图可试用，不自动替换已有选择。</p>
   <label class="form-label appearance-position">背景位置<select data-appearance="imagePosition"><option value="left">左侧</option><option value="center">居中</option><option value="right">右侧</option></select></label></div>
   <button class="secondary" id="appearance-remove" type="button">使用默认背景</button></div><details class="settings-advanced" id="appearance-advanced"><summary>高级视觉调节</summary><div class="settings-advanced-body"><div class="appearance-colors">${[['accent','主色'],['background','背景色'],['surface','卡片色'],['text','文字色']].map(([id,label])=>`<label class="form-label">${label}<input type="color" data-appearance="${id}"></label>`).join('')}</div>
   ${[['cardOpacity','卡片不透明度',75,100],['imageOpacity','背景图片不透明度',0,100],['maskOpacity','背景蒙版不透明度',0,100],['blur','背景模糊（px）',0,8]].map(([id,label,min,max])=>`<label class="appearance-range">${label}<output data-output="${id}"></output><input type="range" data-appearance="${id}" min="${min}" max="${max}" step="1"></label>`).join('')}
   <label class="setting-row">仅首页使用背景图<input class="switch" type="checkbox" data-appearance="homeOnly"></label>
   </div></details></div>
   <div class="appearance-footer"><button class="secondary" id="appearance-reset" type="button">恢复默认外观</button><span id="appearance-status" role="status" aria-live="polite">自动保存</span></div>`);
  const readDraft=()=>({theme:get().theme||'light',appearance:{...defaults,...get().appearance},backgroundFit:get().backgroundFit||layoutDefaults.backgroundFit,backgroundPosition:get().backgroundPosition||layoutDefaults.backgroundPosition,backgroundSmartFill:get().backgroundSmartFill===true});
  let draft=readDraft(),timer,queue=Promise.resolve(),revision=0,pending=0;
  const preview=panel.querySelector('#appearance-preview'),scene=preview.querySelector('.appearance-preview-scene');
  const picture=scene.querySelector('.appearance-preview-image'),smart=scene.querySelector('.appearance-preview-smart'),foreground=smart.querySelector('img'),mask=scene.querySelector('.appearance-preview-mask');
  const source=panel.querySelector('#appearance-image-source'),note=panel.querySelector('#appearance-preview-note');
  const copy=(node,style,properties)=>{for(const key of properties)node.style[key]=style[key];};
  // The thumbnail mirrors the already rendered background. It neither fetches
  // nor softens another image, and never reads or modifies PDF/text-layer DOM.
  function paintPreview(){
   const app=document.querySelector('.app-shell');if(!app)return;
   const width=Math.max(1,app.clientWidth),height=Math.max(1,app.clientHeight),aspect=width/height;
   preview.style.setProperty('--preview-aspect',aspect);scene.style.width=width+'px';scene.style.height=height+'px';
   if(preview.clientWidth)scene.style.transform=`scale(${preview.clientWidth/width})`;
   scene.style.backgroundColor=getComputedStyle(document.body).getPropertyValue('--bg');
   const before=getComputedStyle(app,'::before'),after=getComputedStyle(app,'::after');
   copy(picture,before,['backgroundImage','backgroundSize','backgroundPosition','backgroundRepeat','opacity','filter']);
   copy(mask,after,['backgroundColor','opacity']);
   const themed=['anime','custom'].includes(draft.theme),visible=themed&&before.content!=='none'&&before.display!=='none';
   picture.hidden=!visible;mask.hidden=!themed||after.content==='none'||after.display==='none';
   const layer=document.querySelector('.theme-smart-background'),original=layer?.querySelector('img');
   const ready=draft.theme==='custom'&&backgroundMode(draft)==='smart'&&document.body.dataset.smartReady==='true'&&original&&layer.dataset.image===draft.appearance.image&&getComputedStyle(layer).display!=='none';
   smart.hidden=!ready;
   if(ready){
    const layerStyle=getComputedStyle(layer),imageStyle=getComputedStyle(original);
    copy(smart,layerStyle,['backgroundImage','backgroundSize','backgroundPosition','backgroundRepeat','opacity']);
    if(foreground.getAttribute('src')!==original.getAttribute('src'))foreground.src=original.src;
    copy(foreground,imageStyle,['width','height','objectFit','maskImage','maskComposite']);
    picture.hidden=true;
   }else{smart.style.removeProperty('background-image');foreground.removeAttribute('src');}
   const available=Boolean(objectURL&&draft.appearance.image===asset);
   const built=themed&&draft.theme==='anime'&&before.backgroundImage!=='none';
   source.textContent=draft.appearance.image?(available?'用户导入背景 · 已保存在本机':'用户导入背景暂不可用 · 使用默认背景'):draft.theme==='anime'?(built?'内置插画 · 春日花海':'内置插画正在加载或暂不可用'):'未导入背景 · 主题默认配色';
   preview.dataset.theme=draft.theme;preview.dataset.fit=draft.theme==='anime'?'cover':draft.theme==='custom'?backgroundMode(draft):'none';preview.dataset.smartReady=String(Boolean(ready));
   const mode=draft.theme==='custom'?({contain:'完整显示；比例不同时留白属正常效果',cover:'铺满窗口；保留当前背景位置',smart:ready?'智能填充；复用已柔化底图':draft.appearance.image?'智能填充准备中；暂保留完整显示':'智能填充；请选择本地图片'}[backgroundMode(draft)]):draft.theme==='anime'?'动漫插画 · 铺满窗口':draft.theme==='dark'?'默认深色':'默认浅色';
   note.textContent=`按当前窗口比例预览 · ${mode}${draft.appearance.homeOnly?' · 背景仅首页显示':''}`;
  }
  let previewFrame=0;
  const schedulePreview=()=>{if(previewFrame)return;previewFrame=requestAnimationFrame(()=>{previewFrame=0;if(document.querySelector('#settings-dialog').open&&!panel.hidden)paintPreview();});};
  if(window.ResizeObserver){new ResizeObserver(schedulePreview).observe(preview);new ResizeObserver(schedulePreview).observe(document.querySelector('.app-shell'));}
  new MutationObserver(schedulePreview).observe(document.body,{attributes:true,attributeFilter:['style','data-theme','data-smart-ready','data-current-view']});
  new MutationObserver(schedulePreview).observe(panel,{attributes:true,attributeFilter:['hidden']});
  function paint(){
   document.querySelector('#settings-dialog').style.setProperty('--appearance-zoom',Number(getComputedStyle(document.body).zoom)||1);
   panel.querySelector('#appearance-preset').value=draft.theme;
   panel.querySelector('#appearance-options').hidden=!['anime','custom'].includes(draft.theme);
   panel.querySelector('.appearance-colors').hidden=draft.theme!=='custom';
   panel.querySelector('.appearance-fit-controls').hidden=draft.theme!=='custom';
   panel.querySelector('.appearance-position').hidden=backgroundMode(draft)!=='cover';
   const blur=panel.querySelector('[data-appearance=blur]');blur.disabled=draft.theme==='custom'&&backgroundMode(draft)==='smart';
   blur.closest('.appearance-range').title=blur.disabled?'智能填充自动柔化底图，原图保持清晰；手动模糊用于完整显示或铺满窗口。':'';
   panel.querySelectorAll('[data-appearance]').forEach(e=>{const key=e.dataset.appearance,v=key==='imageFit'?backgroundMode(draft):layoutKey[key]?draft[layoutKey[key]]:draft.appearance[key];if(e.type==='checkbox')e.checked=v;else e.value=v;});
   panel.querySelectorAll('[data-output]').forEach(e=>e.textContent=draft.appearance[e.dataset.output]);
   applyAppearance(draft);
   paintPreview();
  }
  function commit(){
   clearTimeout(timer);timer=null;const version=++revision;status('正在保存…');const snapshot=structuredClone(draft);pending++;
   // Serialize writes, including reset/upload: older saves cannot win a race.
   queue=queue.catch(()=>{}).then(()=>save(snapshot)).then(()=>{if(version===revision){applyAppearance(draft);status('已保存');}},()=>{if(version===revision)status('保存失败，请再次调整或重新选择主题重试');}).finally(()=>{pending--;});
  }
  panel.addEventListener('input',e=>{const key=e.target.dataset.appearance;if(!key)return;if(key==='imageFit'){draft.backgroundSmartFill=e.target.value==='smart';if(!draft.backgroundSmartFill)draft.backgroundFit=e.target.value;}else if(layoutKey[key])draft[layoutKey[key]]=e.target.value;else draft.appearance[key]=e.target.type==='checkbox'?e.target.checked:e.target.type==='color'?e.target.value:Number(e.target.value);paint();clearTimeout(timer);status('待保存…');timer=setTimeout(commit,250);});
  panel.addEventListener('change',e=>{if(e.target.dataset.appearance)commit();});
  panel.querySelector('#appearance-preset').addEventListener('change',e=>{draft.theme=e.target.value;paint();commit();});
  panel.querySelector('#appearance-remove').onclick=()=>{draft.appearance.image='';paint();commit();};
  panel.querySelector('#appearance-reset').onclick=()=>{draft={theme:'light',appearance:{...defaults},...layoutDefaults};paint();commit();};
  panel.querySelector('#appearance-image').onchange=async e=>{
   const file=e.target.files[0];if(!file)return;const requestRevision=revision;
   e.target.disabled=true;status('正在处理背景…');let bitmap;
   try{
    if(file.size>8*1024*1024 || !['image/png','image/jpeg','image/webp'].includes(file.type))throw Error('请选择 8 MB 以内的 PNG、JPEG 或 WebP 图片');
    bitmap=await createImageBitmap(file);if(bitmap.width*bitmap.height>24000000)throw Error('图片像素过大，请先缩小到 2400 万像素以内');
    const ratio=Math.min(1,1600/Math.max(bitmap.width,bitmap.height)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*ratio));canvas.height=Math.max(1,Math.round(bitmap.height*ratio));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();bitmap=null;
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('图片转换失败');
    const r=await fetch('/api/theme-image',{method:'POST',headers:{'X-App-Token':token()},body:blob});const result=await r.json();if(!r.ok)throw Error(result.error||'图片保存失败');
    if(requestRevision!==revision)return;draft.appearance.image=result.image;paint();commit();
   }catch(error){status(error.message,'error');}finally{bitmap?.close();e.target.disabled=false;e.target.value='';}
  };
  // Legacy light/dark controls and refreshed settings keep the editor in sync.
  document.querySelector('#settings-dialog').addEventListener('toggle',()=>{if(!document.querySelector('#settings-dialog').open)return;if(!pending&&!timer)draft=readDraft();paint();});
  paint();return true;
 };
 if(!mount()){const observer=new MutationObserver(()=>{if(mount())observer.disconnect();});observer.observe(document.body,{childList:true,subtree:true});}
}
