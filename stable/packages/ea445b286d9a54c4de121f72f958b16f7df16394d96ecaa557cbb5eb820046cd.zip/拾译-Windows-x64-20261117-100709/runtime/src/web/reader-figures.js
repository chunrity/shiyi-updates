/** Exact PDF region previews: bounded pixels/cache and two render tasks at a time. */
export class PdfFigureCache{
  constructor(getPage){this.getPage=getPage;this.cache=new Map();this.queue=[];this.running=0;this.generation=0;this.tasks=new Set();this.bytes=0;}
  clear(){
    ++this.generation;for(const task of this.tasks)task.cancel();this.tasks.clear();
    for(const entry of this.cache.values())if(entry.canvas){entry.canvas.width=0;entry.canvas.height=0;}
    this.cache.clear();this.bytes=0;
    for(const item of this.queue)item.reject(new Error('Document changed'));this.queue=[];
  }
  get(region){
    const key=JSON.stringify([this.generation,region.pageNumber,region.fullPage,region.rect || region.bbox]);
    if(this.cache.has(key)){const entry=this.cache.get(key);this.cache.delete(key);this.cache.set(key,entry);return entry.promise;}
    let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});
    const entry={promise,canvas:null};this.cache.set(key,entry);
    this.queue.push({region,key,entry,resolve,reject,generation:this.generation});this.pump();return promise;
  }
  pump(){
    while(this.running<2 && this.queue.length){const item=this.queue.shift();this.running++;
      this.render(item).then(item.resolve,item.reject).finally(()=>{this.running--;this.pump();});}
  }
  async render(item){
    let task;
    try{
      const page=await this.getPage(item.region.pageNumber);if(item.generation!==this.generation)throw new Error('Document changed');
      const viewport=page.getViewport({scale:1});let rect=item.region.rect;
      if(!rect && item.region.bbox)rect=viewport.convertToViewportRectangle(item.region.bbox);
      if(item.region.fullPage)rect=[0,0,viewport.width,viewport.height];
      if(!Array.isArray(rect) || rect.length!==4 || !rect.every(Number.isFinite))throw new Error('No reliable image position');
      let [x0,y0,x1,y1]=[Math.min(rect[0],rect[2]),Math.min(rect[1],rect[3]),Math.max(rect[0],rect[2]),Math.max(rect[1],rect[3])];
      x0=Math.max(0,x0);y0=Math.max(0,y0);x1=Math.min(viewport.width,x1);y1=Math.min(viewport.height,y1);
      if(x1-x0<1 || y1-y0<1)throw new Error('Empty PDF region');
      const scale=Math.min(2,900/(x1-x0),1250/(y1-y0));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.ceil((x1-x0)*scale));canvas.height=Math.max(1,Math.ceil((y1-y0)*scale));
      task=page.render({canvasContext:canvas.getContext('2d'),viewport,transform:[scale,0,0,scale,-x0*scale,-y0*scale],background:'white'});
      this.tasks.add(task);await task.promise;
      if(item.generation!==this.generation)throw new Error('Document changed');
      item.entry.canvas=canvas;this.bytes+=canvas.width*canvas.height*4;this.trim(item.key);return canvas;
    }catch(error){if(this.cache.get(item.key)===item.entry)this.cache.delete(item.key);throw error;}
    finally{if(task)this.tasks.delete(task);}
  }
  trim(keep){
    for(const [key,entry] of this.cache){
      if(this.bytes<=12*1024*1024 && this.cache.size<=12)break;
      if(key===keep || !entry.canvas)continue;
      this.bytes-=entry.canvas.width*entry.canvas.height*4;entry.canvas.width=0;entry.canvas.height=0;this.cache.delete(key);
    }
  }
}
