/** Read-only semantic adapter over parsed paragraphs. Does not alter PDF spans or selections. */
export const CONTEXT_STRATEGY='context-quality-3';
const safeKinds=new Set(['title','subtitle','heading','body','list_item']);
const english=text=>typeof text==='string' && /[A-Za-z]/.test(text) && !/\p{Script=Han}/u.test(text);
const normalized=text=>String(text || '').replace(/\s+/g,' ').trim();
const seen=new WeakSet(),documents=new Map();
export function rememberTranslationContext(structure){
  if(!structure?.id || (seen.has(structure) && documents.has(structure.id)))return;
  seen.add(structure);
  let entries=documents.get(structure.id);if(!entries){entries=new Map();documents.set(structure.id,entries);}
  for(const p of structure.paragraphs || []){
    if(p.translatable===false || !safeKinds.has(p.kind) || !english(p.text))continue;
    // Only source evidence is indexed. Full-name verification occurs in the shared backend.
    const snippets=[...p.text.matchAll(/[^.!?;:()\n]{2,180}\([A-Za-z][A-Za-z0-9./-]{1,14}\)/g)].map(m=>m[0]);
    if(snippets.length)entries.set(p.id,{paragraph_id:p.id,text:snippets.join(' ').slice(0,2000)});else entries.delete(p.id);
  }
  while(entries.size>64)entries.delete(entries.keys().next().value);
  while(documents.size>4)documents.delete(documents.keys().next().value);
}
function crop(text,target,limit){
  if(text.length<=limit)return text;
  const index=text.indexOf(target);if(index<0)return '';
  return text.slice(Math.max(0,index-700),Math.max(0,index-700)+limit);
}
export function selectionTranslationContext({text,context='',structure=null,paragraphId=null,page=1}){
  if(!text || !english(text))return null;
  rememberTranslationContext(structure);
  if(!structure)return english(context) && normalized(context).includes(normalized(text))?{paragraph:crop(context,text,18000)}:null;
  const paragraphs=(structure.paragraphs || []).filter(p=>p.translatable!==false && safeKinds.has(p.kind) && english(p.text));
  let p=paragraphs.find(p=>p.id===paragraphId && normalized(p.text).includes(normalized(text)));
  if(!p){const hits=paragraphs.filter(p=>p.parts?.some(part=>part.pageNumber===page) && normalized(p.text)===normalized(context) && normalized(p.text).includes(normalized(text)));if(hits.length===1)p=hits[0];}
  if(!p)return null; // Explicit vocabulary/note selections remain valid targets without article context.
  const index=paragraphs.indexOf(p),adjacent=(other)=>other && Math.min(...other.parts.map(part=>part.pageNumber))<=Math.max(...p.parts.map(part=>part.pageNumber))+1 && Math.max(...other.parts.map(part=>part.pageNumber))>=Math.min(...p.parts.map(part=>part.pageNumber))-1;
  const previous=paragraphs[index-1],next=paragraphs[index+1];
  return {document_id:structure.id,paragraph_id:p.id,title:paragraphs.find(p=>p.kind==='title')?.text.slice(0,500) || '',
    section:paragraphs.slice(0,index+1).filter(p=>p.kind==='heading').at(-1)?.text.slice(0,500) || '',paragraph:crop(p.text,text,18000),
    previous:adjacent(previous)?previous.text.slice(-900):'',next:adjacent(next)?next.text.slice(0,900):'',evidence:[...(documents.get(structure.id)?.values() || [])]};
}
