/** PDF parsing -> translation boundary. Reads the phase-1 model without mutating it. */
export const TRANSLATION_CONTRACT_VERSION=1;

export function translationManifest(structure,{pageNumber=null,name='',domain=''}={}){
  const physical=new Map(structure.pages.flatMap(page=>page.paragraphs.map(p=>[page.pageNumber+':'+p.id,p])));
  let section='';
  const paragraphs=structure.paragraphs.filter(p=>p.translatable!==false).map(p=>{
    const first=p.parts[0],source=physical.get(first.pageNumber+':'+first.paragraphId);
    if(p.kind==='heading')section=p.text;
    return {paragraph_id:p.id,text:p.text,kind:p.kind,section,
      reading_order:first.pageNumber*1000000+(source?.readingOrder || 0),
      source_parts:p.parts.map(part=>({page_number:part.pageNumber,paragraph_id:part.paragraphId,
        bbox:part.bbox,rect:part.rect,line_ids:[...part.lineIds]}))};
  });
  return {contract_version:TRANSLATION_CONTRACT_VERSION,
    document:{document_id:structure.id,title:paragraphs.find(p=>p.kind==='title')?.text || '',
      domain,parser_version:structure.schemaVersion},paragraphs,
    target_ids:paragraphs.filter(p=>pageNumber===null || p.source_parts.some(part=>part.page_number===pageNumber)).map(p=>p.paragraph_id)};
}

export function textManifest({id,name,passages}){
  return {contract_version:1,document:{document_id:id,title:name,domain:'',parser_version:'text-1'},
    paragraphs:passages.map((p,index)=>({paragraph_id:p.id,text:p.text,kind:p.kind || 'body',section:'',reading_order:index,
      source_parts:[{page_number:1,paragraph_id:p.id,line_ids:[]}]})),target_ids:passages.map(p=>p.id)};
}

/** A result from a different source revision must never be attached to the current PDF. */
export function matchesSource(result,paragraph){
  return result.paragraph_id===paragraph.paragraph_id && result.source_text===paragraph.text &&
    JSON.stringify(result.source_parts)===JSON.stringify(paragraph.source_parts);
}
