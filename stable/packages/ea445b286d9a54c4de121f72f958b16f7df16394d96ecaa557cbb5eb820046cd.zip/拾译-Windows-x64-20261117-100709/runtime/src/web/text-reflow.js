// Text rules shared by layout reconstruction and selected-text cleanup.
const compoundHeads=new Set(('self well life long short high low non cross pre post anti evidence state cost time large small single double multi data model image text cell t b gene protein drug disease patient user water climate cancer risk dose open real full part follow two three first second third human computer machine deep zero few').split(' '));
const compoundTails=new Set(('based related driven dependent independent associated mediated induced controlled resistant negative positive specific scale blind term level order source').split(' '));
// A small, auditable vocabulary; unknown words are never silently dehyphenated.
// Page/document evidence extends it with complete spellings actually present in the PDF.
const completeWords=new Set(('technology technological transformation international development introduction discussion statistical probability implementation understanding paragraph scientific science research evidence sequence treatment vaccine protein translation clinical molecular discovery analysis assessment algorithm document information experimental experiment structure intervention significant methodological publication architecture classification engineering prediction optimization demonstration opportunity application medicine cancer biology computational computing evaluation reconstruction recognition geometrical mathematical abbreviation footnote reference participant participants comparison psychology measurement corresponding continuation neurological artificial intelligence generate generates generated generation existing public approach tumors patient patients results immunotherapy immunology genomics photosynthesis biotechnology nanotechnology therapeutic immunization personalized individual response benefit').split(' '));
for(const word of 'country countries invest investing investor investors outlets awkward today defunding closing suggesting indian american obtained antagonising manufacturing diversification market marketplace company companies considerable particularly potential international independent information education'.split(' '))completeWords.add(word);
const ligatures={'ﬀ':'ff','ﬁ':'fi','ﬂ':'fl','ﬃ':'ffi','ﬄ':'ffl','ﬅ':'st','ﬆ':'st'};
const cjk=/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u;

export function normalizeText(value){
  return String(value ?? '').replace(/[ﬀ-ﬆ]/g,c=>ligatures[c] || c)
    .replace(/[\u200b\ufeff\x00]/g,'').replace(/\s+/gu,' ').trim().replace(/\u00ad(?!$)/g,'');
}

export function collectWordEvidence(texts){
  const words=new Set();
  for(const text of texts)for(const word of normalizeText(text).match(/[\p{L}]+(?:[-‐][\p{L}]+)*/gu) || [])words.add(word.toLowerCase().replaceAll('‐','-'));
  return words;
}

export function joinLineFragments(previous,next,options={}){
  previous=String(previous || '').trimEnd();next=String(next || '').trimStart();
  if(!previous)return {text:next,repair:null};
  if(!next)return {text:previous,repair:null};
  if(previous.endsWith('\u00ad'))return {text:previous.slice(0,-1)+next,repair:{kind:'soft-hyphen',original:'\u00ad'}};
  const tail=previous.match(/([\p{L}\p{N}]+)([-‐])$/u),head=next.match(/^([\p{L}\p{N}]+)/u);
  if(tail && head){
    const left=tail[1],right=head[1];
    if(/^[a-z]/.test(right) || /^(?:[A-Z]|\d)$/.test(left) || /^\d/.test(right)){
      const evidence=options.words,compound=(left+'-'+right).toLowerCase(),whole=(left+right).toLowerCase();
      const knownCompound=evidence?.has(compound);
      const keep=knownCompound || compoundHeads.has(left.toLowerCase()) || compoundTails.has(right.toLowerCase()) ||
        /^[A-Z\d]{1,4}$/.test(left) || /^\d/.test(right) || /[\p{L}]-[\p{L}]+[-‐]$/u.test(previous);
      const knownWord=evidence?.has(whole) || completeWords.has(whole);
      const remove=!keep && knownWord;
      return {text:(remove?previous.slice(0,-1):previous)+next,
        repair:{kind:keep?'preserved-compound':remove?'line-wrap-hyphen':'ambiguous-line-hyphen',left,right,original:tail[2]}};
    }
  }
  const a=previous.at(-1),b=next[0];
  // CJK wrapping has no inter-word space; keep mathematical and Latin tokens intact.
  const space=cjk.test(a) && cjk.test(b)?' ':(/[（(\[“]$/.test(previous) || /^[，。！？；：、,.;:!?）)\]”]/.test(next)?'':' ');
  return {text:previous+(cjk.test(a) && cjk.test(b)?'':space)+next,repair:null};
}

export function joinLines(previous,next){return joinLineFragments(previous,next).text;}

export function joinSpans(spans){
  let text='',prior=null;
  for(const span of spans){
    const value=String(span.rawText ?? span.text ?? '').replace(/[\u200b\ufeff\x00]/g,'').replace(/[ﬀ-ﬆ]/g,c=>ligatures[c] || c);
    if(!value)continue;
    let separator='';
    if(prior && text && !/\s$/.test(text) && !/^\s/.test(value)){
      const gap=span.rect[0]-prior.rect[2],font=Math.min(span.fontSize,prior.fontSize);
      const tightlySet=gap<=Math.max(.3,font*.13);
      const punctuation=/^[,.;:!?，。！？；：、)\]）]/.test(value) || /[(\[（]$/.test(text);
      const bothCjk=cjk.test(text.at(-1)) && cjk.test(value[0]);
      if(!prior.dropCap && !tightlySet && !punctuation && !bothCjk)separator=' ';
    }
    text+=separator+value;prior=span;
  }
  return normalizeText(text);
}

/** Derived selection text only; never changes PDF spans, Range or coordinates. */
export function cleanupSelectedText(value,{evidence=[]}={}){
  const text=String(value ?? ''),words=collectWordEvidence(evidence);
  words.add('good'); // Selection-only vocabulary; layout reconstruction is unchanged.
  return text.replace(/([\p{L}\p{N}]+)([-‐\u00ad])[ \t]*\r?\n[ \t]*([\p{L}\p{N}]+)/gu,(match,left,hyphen,right,offset)=>{
    const prefix=text.slice(Math.max(0,offset-80),offset);
    const joined=joinLineFragments(prefix+left+hyphen,right,{words});
    if(!['line-wrap-hyphen','soft-hyphen','preserved-compound'].includes(joined.repair?.kind))return match;
    return joined.text.slice(prefix.length);
  });
}
