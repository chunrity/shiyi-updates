import {applyAppearance,setupAppearance} from './appearance.js';
import {CONTEXT_STRATEGY,rememberTranslationContext,selectionTranslationContext} from './translation-context.js';
import {attachConnectionTest} from './ai-connection.js';
import {attachUpdateCenter} from './update-center.js';
import {cleanupSelectedText} from './text-reflow.js';
import {pdfGlyphMetrics,registerPdfGeometry,pdfSelectionLines} from './pdf-selection-geometry.js';
import {PdfSurface} from './pdf-surface.js';
import {localLookup,selectionHint} from './context-lookup.js';
import {pdfFragmentSeparator,selectPdfWord,readReaderSelection,LatestSelectionRequest,PdfSelectionGesture} from './text-selection.js';
import {groupPdfItems,ocrItems,joinLines,buildDocumentStructure,layoutRegionsFromOperators} from './reading-layout.js';
import {preferNativeArticle} from './pdf-text-source.js';
import {translationManifest,textManifest,matchesSource} from './paragraph-document.js';
import {ParagraphClient} from './paragraph-client.js';
import {resolveParagraphWindow,resolvedTargetIds} from './paragraph-window.js';
import {ReaderController} from './reader-controller.js';
import {captureAnchor,anchorScrollTop} from './reader-model.js';
const $ = (q, root = document) => root.querySelector(q);
const $$ = (q, root = document) => [...root.querySelectorAll(q)];
const token = $('meta[name="app-token"]').content;
const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {documents:[],vocabulary:[],history:[],settings:{},hotkeys:{}};
let currentDoc = null, pdf = null, pdfjs = null, currentPage = 1, zoom = 0, renderTask = null, textLayer = null;
let renderSerial = 0, docSerial = 0, translateSerial = 0, parallelSerial = 0, debounceTimer, lastResult = null;
let pageText = '', pageParagraphs = [], currentContext = '', lastEvent = 0, selectionTimer, docText = '';
let passages=[],activePassage='',pdfItems=[],pdfViewport=null,pdfSize=null,pdfSpans=[],pageOcr=null,lastPageKey='';
let ignoreSourceScroll=0,ignoreTranslationScroll=0,sourceFrame=0,translationFrame=0;
let sourceIntentUntil=0,translationIntentUntil=0;
const ocrCache=new Map();
let pdfPageCache=new Map(),pdfRecord=null,pdfDocumentStructure=null;
let pdfSurface=null,structureInput=null,manifestInput=null;
let paragraphWindows=new Map(),resolvedWindow=null;
const instantRequest=new LatestSelectionRequest();
const pdfSelectionGesture=new PdfSelectionGesture($('#pdf-text'));
let selectionOwned=false,selectionDragging=false,lastSelectionKey='',currentSelectionHint='';
let clearingReaderSelection=false,selectionPending=false,instantFailure=null,lastResultKey='';
let paragraphViewSerial=0,paragraphViewTimer,paragraphRecords=new Map(),paragraphJob=null;
const paragraphClient=new ParagraphClient(api,{changed:job=>{
  if(job.document_id!==translationDocId())return;
  if(!sameTranslationVariant(job.items?.[0]) && job.items?.length)return;
  if(!paragraphJob || job.created>=paragraphJob.created)paragraphJob=job;
  for(const item of job.items){if(!sameTranslationVariant(item))continue;const previous=paragraphRecords.get(item.paragraph_id);if(!previous || item.updated>=previous.updated)paragraphRecords.set(item.paragraph_id,item);}
  renderParagraphResults();
},error:error=>{$('#paragraph-progress').textContent='连接暂时中断，正在恢复任务状态…';}});
function translationDocId(){return currentDoc?.id || 'demo-science-v1';}
function sameTranslationVariant(item){return item && item.source_language===($('#source-lang').value || state.settings.source || 'en') && item.target_language===($('#target-lang').value || state.settings.target || 'zh-CN') && item.provider===(state.settings.provider || 'auto') && (item.provider!=='custom' || item.requested_model===state.settings.model);}
function currentTranslationManifest(){
  const source=pdf && pdfDocumentStructure?pdfDocumentStructure:passages,id=translationDocId(),name=currentDoc?.name || 'A new chapter in cancer research';
  if(manifestInput?.source===source && manifestInput.id===id && manifestInput.name===name && manifestInput.page===currentPage)return manifestInput.value;
  const value=pdf && pdfDocumentStructure?translationManifest(pdfDocumentStructure,{pageNumber:currentPage,name}):textManifest({id,name,passages});
  manifestInput={source,id,name,page:currentPage,value};return value;
}
function scheduleParagraphView(){
  clearTimeout(paragraphViewTimer);paragraphViewTimer=setTimeout(()=>loadParagraphView().catch(()=>{}),60);
}
async function loadParagraphView(){
  const serial=++paragraphViewSerial,doc=translationDocId(),page=currentPage;
  const options={source:$('#source-lang').value,target:$('#target-lang').value,provider:state.settings.provider || 'auto'};
  if(options.provider==='custom')options.model=state.settings.model || '';
  const [response,job]=await Promise.all([paragraphClient.results(doc,pdf?page:null,options),paragraphClient.restore(doc)]);
  if(serial!==paragraphViewSerial || doc!==translationDocId() || page!==currentPage)return;
  paragraphRecords=new Map(response.items.map(item=>[item.paragraph_id,item]));paragraphJob=job?.items?.some(sameTranslationVariant)?job:null;
  if(job)for(const item of job.items){if(!sameTranslationVariant(item))continue;const previous=paragraphRecords.get(item.paragraph_id);if(!previous || item.updated>=previous.updated)paragraphRecords.set(item.paragraph_id,item);}
  renderParagraphResults();
}

function ensurePdfGraphics(record){
  if(record.graphicsReady)return Promise.resolve();
  if(!record.graphicsPromise)record.graphicsPromise=record.page.getOperatorList().then(operators=>{record.glyphMetrics=pdfGlyphMetrics(operators,pdfjs.OPS);record.regions=layoutRegionsFromOperators(operators,pdfjs.OPS,record.viewport.transform);record.graphicsReady=true;record.layouts.clear();},error=>{record.graphicsPromise=null;throw error;});
  return record.graphicsPromise;
}
function assignPdfStructure(pages,merge=false){
  if(merge && structureInput?.id===currentDoc.id){const map=new Map(structureInput.pages.filter(page=>resolvedWindow?.page===currentPage && resolvedWindow.mode===$('#column-mode').value || Math.abs(page.pageNumber-currentPage)<=1).map(page=>[page.pageNumber,page]));for(const page of pages)map.set(page.pageNumber,page);pages=[...map.values()];}
  pages=pages.slice().sort((a,b)=>a.pageNumber-b.pageNumber);
  if(structureInput?.id===currentDoc.id && structureInput.pages.length===pages.length && pages.every((page,index)=>page===structureInput.pages[index]))return false;
  structureInput={id:currentDoc.id,pages};pdfDocumentStructure=buildDocumentStructure({id:currentDoc.id,name:currentDoc.name,totalPages:pdf.numPages,pages});rememberTranslationContext(pdfDocumentStructure);return true;
}
async function loadPdfRecord(documentRef,pageNumber,graphics=false){
  const cache=pdfPageCache;
  if(cache.has(pageNumber)){const value=cache.get(pageNumber);cache.delete(pageNumber);cache.set(pageNumber,value);const record=await value;if(graphics)ensurePdfGraphics(record).catch(()=>{});return record;}
  const pending=(async()=>{
    const page=await documentRef.getPage(pageNumber),viewport=page.getViewport({scale:1});
    const record={page,pageNumber,viewport,content:null,regions:[],graphicsReady:false,layouts:new Map()};
    // Start graphics and text together only for the requested page, never neighbors.
    if(graphics)ensurePdfGraphics(record).catch(()=>{});record.content=await page.getTextContent();return record;
  })();
  cache.set(pageNumber,pending);
  // Keep only a small window of text data. Neighbor prefetch never renders image pixels.
  while(cache.size>5){
    const oldest=cache.keys().next().value,evicted=cache.get(oldest);cache.delete(oldest);
    // PDF.js also holds page operator/image resources. Best-effort cleanup only
    // releases idle evicted pages; an active render makes cleanup return false.
    Promise.resolve(evicted).then(record=>{if(record.page!==pdfRecord?.page)record.page.cleanup();}).catch(()=>{});
  }
  try{return await pending;}catch(error){if(cache.get(pageNumber)===pending)cache.delete(pageNumber);throw error;}
}
function effectivePageOcr(record,ocr){
  // Saved OCR is evidence, not an unconditional replacement for a reliable
  // native text layer. Use the same choice for rendering and neighboring pages.
  if(!ocr)return null;
  return preferNativeArticle(analyzeRecord(record,'auto',null).page,ocr)?null:ocr;
}
function analyzeRecord(record,mode='auto',ocr=null){
  ocr=effectivePageOcr(record,ocr);
  const key=mode+':'+(ocr?'ocr':'text'),cached=record.layouts.get(key);
  if(cached?.ocr===ocr)return cached.layout;
  const viewport=record.viewport;
  const items=ocr?ocrItems(ocr,viewport.width,viewport.height,{transform:viewport.transform}):record.content.items;
  // Native and OCR spans share original PDF coordinates, including crop/rotation.
  const layout=groupPdfItems(items,viewport.width,mode,{height:viewport.height,pageNumber:record.pageNumber,
    styles:ocr?{}:record.content.styles,transform:viewport.transform,
    regions:record.regions});
  record.layouts.set(key,{ocr,layout});return layout;
}
async function prefetchPdfNeighbors(documentRef,pageNumber,serial){
  const doc=currentDoc,mode=$('#column-mode').value,key=serial+':'+pageNumber+':'+mode,cache=paragraphWindows;
  const valid=()=>documentRef===pdf && serial===docSerial && doc.id===currentDoc?.id && pageNumber===currentPage && mode===$('#column-mode').value && cache===paragraphWindows;
  if(!cache.has(key)){
    const pending=resolveParagraphWindow({id:doc.id,name:doc.name,totalPages:documentRef.numPages,pageNumber,valid,
      loadPage:async number=>{
        const record=await loadPdfRecord(documentRef,number);
        // Layout metadata (rules/images) affects reading order and source hashes.
        // Parse it consistently on every participating page; no canvas rendering.
        await ensurePdfGraphics(record);
        const ocrKey=doc.id+':'+number;
        if(!ocrCache.has(ocrKey)){
          const saved=await api('ocr-page?doc='+encodeURIComponent(doc.id)+'&page='+number);
          ocrCache.set(ocrKey,saved.available?saved:null);
        }
        return analyzeRecord(record,mode,ocrCache.get(ocrKey)).page;
      }});
    cache.set(key,pending);
    pending.catch(()=>{if(cache.get(key)===pending)cache.delete(key);});
    while(cache.size>3)cache.delete(cache.keys().next().value);
  }
  const structure=await cache.get(key);if(!valid())return;
  resolvedWindow={page:pageNumber,mode};
  if(pdfDocumentStructure!==structure){
    pdfDocumentStructure=structure;rememberTranslationContext(structure);structureInput={id:doc.id,pages:structure.pages};
    const page=structure.pages.find(p=>p.pageNumber===pageNumber);if(page)applyPdfStructure(page);
  }
  return structure;
}
function pdfReadingStatus(page){
  if(page?.classification?.kind==='study-material')return '第 '+page.pageNumber+' 页 · 学习材料保留原版式 · 可选中文字翻译';
  return pageText.trim()?'第 '+(page?.pageNumber || currentPage)+' 页 · '+(page?.source==='ocr'?'已在本机识别 · ':'')+passages.length+' 个阅读段落 · 可划词翻译':'此页没有可用文字层，点击「识别本页文字」即可划词';
}
function applyPdfStructure(page){
  setPassages(page.paragraphs.filter(p=>!p.isDecoration && p.translatable!==false));
  $('#layout-label').textContent=(page.classification?.kind==='annotated-article'?'正文 / 词汇注释':page.classification?.kind==='study-material'?'学习材料 · 保留原页':page.columns===2?'左栏 → 右栏':'单栏')+' · '+passages.length+' 段';
  $('#layout-label').title=page.warnings.map(w=>w.message).join('\n') || '已按文字位置、字号、行距和缩进重组段落';
  Object.assign($('#pdf-page').dataset,{layoutVersion:String(page.schemaVersion),columnCount:String(page.columns),paragraphCount:String(passages.length)});
  for(const p of page.paragraphs)for(const index of p.itemIndices){if(pdfSpans[index])pdfSpans[index].dataset.blockKind=p.kind;}
  $('#reading-status').textContent=pdfReadingStatus(page);
}
const demoParagraphs = [
  'Scientific progress rarely arrives all at once. It grows from years of careful observation, unexpected discoveries, and the willingness to ask a better question. A breakthrough is often the moment when those separate efforts finally come together.',
  'In cancer research, scientists are exploring how the immune system can learn to recognize the unique features of a patient’s tumor. By studying its genetic information, researchers hope to design treatments that are more personal and more precise.',
  'The challenge is not only to develop new technology, but also to understand who may benefit from it. Clinical trials help researchers compare outcomes, measure risks, and test whether an encouraging idea can make a meaningful difference in everyday care.',
  'Every promising result opens another question. That is what makes science a continuing conversation: each new discovery becomes a starting point for the next generation of researchers.'
];

async function api(path, body, options = {}) {
  const init = {headers:{'X-App-Token':token},...options};
  if (body !== undefined) {init.method='POST';init.headers['Content-Type']='application/json';init.body=JSON.stringify(body);}
  const response = await fetch('/api/'+path,init);
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || '操作未完成，请重试');
  return result;
}
let readerPreferenceQueue=Promise.resolve();
async function readerPreference(value){
  Object.assign(state.settings,value);applyPreferences();
  const pending=readerPreferenceQueue.catch(()=>{}).then(()=>api('settings',value));readerPreferenceQueue=pending;
  await pending;return {ok:true};
}
const immersiveReader=new ReaderController({
  readSelection:readReaderSelection,
  api,settings:()=>state.settings,structure:()=>pdf?pdfDocumentStructure:null,manifest:currentTranslationManifest,
  translations:()=>paragraphRecords,job:()=>paragraphJob,pdf:()=>pdf,
  document:()=>({id:translationDocId(),name:currentDoc?.name || '阅读示例',kind:currentDoc?.kind || 'text',page:currentPage,total:pdf?.numPages || 1,imported:!!currentDoc}),
  preference:readerPreference,toast,translate:translateParagraphs,cancel:()=>paragraphClient.cancel(translationDocId()),
  source:(text,context)=>{immersiveReader.showLookup();setSource(text,context,{exact:true});},instant:translate,tab:setTab,
  mode:async mode=>{if(pdf && mode==='pdf' && state.settings.readerMode==='pdf')await renderPdf();},
  page:async(page,valid)=>{if(!pdf || !valid())return;currentPage=Math.max(1,Math.min(pdf.numPages,page));++parallelSerial;resetParallel();await renderPdf();if(valid()){await prefetchPdfNeighbors(pdf,currentPage,docSerial);await loadParagraphView();}},
  pdfLocate:async(paragraph,page,valid)=>{
    if(!valid())return false;
    const part=paragraph?.parts.find(p=>p.pageNumber===page);
    const physical=passages.find(p=>p.id===part?.paragraphId);
    if(!pdf && physical){activatePassage(physical.id,true,true);return true;}
    if(!physical || !part?.bbox?.every(Number.isFinite)){if(physical)activatePassage(physical.id,false,true);return false;}
    activePassage='';activatePassage(physical.id,true,true);return true;
  },
  highlight:(id,scroll=false)=>{const p=immersiveReader.paragraph(id),part=p?.parts.find(part=>part.pageNumber===currentPage);if(part && passages.some(p=>p.id===part.paragraphId)){activePassage='';activatePassage(part.paragraphId,scroll,false);}},
  active:id=>{activePassage=immersiveReader.paragraph(id)?.parts.find(part=>part.pageNumber===currentPage)?.paragraphId || '';}
});
const updateCenter=attachUpdateCenter($('#settings-dialog'),{
  api,confirm,saveReading:async()=>{await saveProgress();await immersiveReader.flushProgress();}
});
function toast(message,error=false) {
  const item=document.createElement('div');item.className='toast'+(error?' error':'');item.textContent=message;
  $('#toast-area').append(item);setTimeout(()=>item.remove(),error?6500:3000);
}
function date(value,full=false) {return new Date(value*1000).toLocaleString('zh-CN',full?{month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'}:{month:'short',day:'numeric'});}
function empty(iconName,title,text) {return `<div class="empty-state">${icon(iconName)}<h3>${esc(title)}</h3><p>${esc(text)}</p></div>`;}
async function refresh() {Object.assign(state,await api('state'));updateSidebar();if(['library','vocabulary','history'].includes(document.body.dataset.currentView))renderCollections();}
function updateSidebar() {
  $('#home-recent').innerHTML=state.documents.slice(0,6).map(d=>`<button class="home-book" data-doc="${esc(d.id)}"><span class="home-book-icon">${icon('file')}</span><span class="home-book-body"><strong title="${esc(d.name)}">${esc(d.name)}</strong><small>${d.kind==='pdf'?'PDF 文献':'文本文章'} · ${d.total>1?'第 '+(d.page || 1)+' / '+d.total+' 页':'第 '+(d.page || 1)+' 页'}</small>${Number.isFinite(Number(d.total)) && Number(d.total)>1?`<span class="home-book-progress" aria-hidden="true"><span style="width:${Math.min(100,Math.max(0,100*(Number(d.page)||1)/Number(d.total)))}%"></span></span>`:''}</span><span class="home-book-arrow" aria-hidden="true">${icon('chevron')}</span></button>`).join('') || '<div class="home-library-empty">你的下一篇好文章，放在这里。</div>';
  $('#doc-count').textContent=state.documents.length;$('#word-count').textContent=state.vocabulary.length;
  $('#recent-list').innerHTML=state.documents.slice(0,5).map(d=>`<button class="recent-item" data-doc="${esc(d.id)}" title="${esc(d.name)}">${icon('file')}<span>${esc(d.name)}</span></button>`).join('') || '<button class="recent-item" data-action="demo">'+icon('book')+'<span>从一篇阅读示例开始</span></button>';
}
function setView(view) {
  const result=$('#translation-result'),home=$('#home-result');
  if(home){
    if(!document.getElementById('reader-result-anchor')){const anchor=document.createElement('span');anchor.id='reader-result-anchor';result.before(anchor);}
    if(view==='home')home.append(result);else $('#reader-result-anchor').after(result);
    if(document.body.dataset.currentView!==view){invalidateInstant(true);currentContext='';currentSelectionHint='';}
  }

  document.body.dataset.currentView=view;$('#reader-more').open=false;
  $$('.view').forEach(v=>v.classList.toggle('active',v.id===view+'-view'));
  $$('.nav-item').forEach(v=>v.classList.toggle('active',v.dataset.view===view));
  $('#view-name').textContent={home:'首页',reader:'阅读空间',library:'我的书库',vocabulary:'生词本',history:'翻译记录'}[view];
  $('#sidebar').classList.remove('open');document.body.classList.remove('focus-mode');
  if (view!=='reader') refresh().catch(e=>toast(e.message,true));
  if (view==='reader' && pdf) setTimeout(()=>renderPdf(),100);
}
function applyPreferences() {
  applyAppearance(state.settings);
  document.documentElement.style.setProperty('--reading-size',(state.settings.fontSize || 19)+'px');
  $('.theme-button').innerHTML=icon(state.settings.theme==='dark'?'sun':'moon');
  $('#source-lang').value=state.settings.source || 'en';$('#target-lang').value=state.settings.target || 'zh-CN';
  $('#engine-label').textContent='设置：'+({auto:'智能选择翻译引擎',bing:'微软翻译',memory:'MyMemory 公共翻译',google:'Google 翻译',custom:'自定义 AI / 本地模型'}[state.settings.provider] || '智能选择翻译引擎');
  $('#selection-shortcut').textContent=state.settings.selectionHotkey || 'Alt+Q';$('#capture-shortcut').textContent=state.settings.captureHotkey || 'Ctrl+Alt+S';
  $('#sync-scroll').checked=state.settings.syncScroll!==false;
  immersiveReader.update();
}
async function preference(value) {if(['source','target','provider','model','apiBase','apiKey'].some(key=>key in value)){instantRequest.clearCache();invalidateInstant(true);}const response=await api('settings',value);Object.assign(state.settings,value);if(response.hotkeys)state.hotkeys=response.hotkeys;if(Object.keys(value).every(key=>['theme','appearance','backgroundFit','backgroundPosition','backgroundSmartFill'].includes(key))){applyAppearance(state.settings);$('.theme-button').innerHTML=icon(state.settings.theme==='dark'?'sun':'moon');}else applyPreferences();if(['source','target','provider','model','apiBase'].some(key=>key in value)){renderParagraphResults();scheduleParagraphView();}return response;}
function showDemo() {
  ++docSerial;++renderSerial;++parallelSerial;resetParallel();
  if (renderTask) renderTask.cancel();
  if (textLayer) textLayer.cancel();
  if (pdf) pdf.destroy();pdf=null;currentDoc=null;currentPage=1;zoom=0;
  pdfPageCache=new Map();paragraphWindows=new Map();resolvedWindow=null;pdfRecord=null;pdfDocumentStructure=null;structureInput=null;manifestInput=null;pdfSurface?.clear();textLayer=null;
  $('#article').classList.remove('hidden');$('#pdf-page').classList.add('hidden');$('#pdf-controls').classList.add('hidden');
  $('#pdf-reading-tools').classList.add('hidden');lastPageKey='';pageOcr=null;
  $('#export-pdf-structure').classList.add('hidden');
  $('#file-type').textContent='DEMO';$('#document-title').textContent='一篇关于科学的阅读示例';
  $('#article').innerHTML=`<div class="article-category">SCIENCE & POSSIBILITY</div><h2>A new chapter<br>in cancer research</h2><p class="article-deck">How curiosity, patience, and a personal approach<br>are opening new possibilities in medicine.</p><div class="article-meta"><span>拾译原创阅读示例</span><span>约 2 分钟</span><span>科学 · 医学</span></div><div class="article-body">${demoParagraphs.map((p,i)=>`<p data-paragraph="${i}">${esc(p).replace('breakthrough','<span class="key-word">breakthrough</span>')}</p>`).join('')}</div><blockquote>“Each new discovery becomes a starting point<br>for the next question.”</blockquote><p class="demo-note">这是一篇功能演示文章。点击左上角「导入文献」，开始阅读你自己的外刊或论文。</p>`;
  docText=demoParagraphs.join('\n\n');pageText=docText;pageParagraphs=[...demoParagraphs];
  setPassages(demoParagraphs.map((text,i)=>({id:'passage-'+i,text,itemIndices:[],lines:[]})));
  $('#reading-status').textContent='选中单词或句子，即可在右侧查看翻译';
  $('#paper-scroll').scrollTop=0;setView('reader');
}
async function importFiles(files) {
  const list=[...files];if(!list.length)return;
  let last=null;
  for(const file of list) {
    if(!/\.(pdf|txt|md)$/i.test(file.name)){toast('支持 PDF、TXT 和 Markdown 文件',true);continue;}
    if(file.size>80*1024*1024){toast(file.name+' 超过 80 MB，请使用更小的文件',true);continue;}
    toast('正在导入 '+file.name);
    try {
      const response=await fetch('/api/import?name='+encodeURIComponent(file.name),{method:'POST',headers:{'X-App-Token':token},body:await file.arrayBuffer()});
      const result=await response.json();if(!response.ok)throw new Error(result.error);last=result;
    } catch(e){toast(e.message || '文件导入失败',true);}
  }
  if(last){await refresh();await openDocument(last.id);toast('已加入你的本地书库');}
  $('#file-input').value='';
}
async function openDocument(id) {
  const serial=++docSerial;++parallelSerial;++renderSerial;resetParallel();
  setPassages([]);currentContext='';
  pdfPageCache=new Map();paragraphWindows=new Map();resolvedWindow=null;pdfRecord=null;pdfDocumentStructure=null;structureInput=null;manifestInput=null;pdfSurface?.clear();textLayer=null;
  if(renderTask)renderTask.cancel();if(textLayer)textLayer.cancel();
  const old=pdf;pdf=null;if(old)await old.destroy();
  currentDoc=await api('document/'+encodeURIComponent(id));if(serial!==docSerial)return;
  $('#file-type').textContent=currentDoc.kind==='pdf'?'PDF':'TEXT';$('#document-title').textContent=currentDoc.name;
  currentPage=currentDoc.page || 1;zoom=0;setView('reader');
  $('#column-mode').value='auto';lastPageKey='';pageOcr=null;pdfItems=[];pdfSpans=[];
  $('#doc-search').classList.add('hidden');$('#doc-search-input').value='';
  preference({lastDoc:id}).catch(()=>{});
  if(currentDoc.kind==='pdf') {
    $('#export-pdf-structure').classList.remove('hidden');
    $('#article').classList.add('hidden');$('#pdf-page').classList.remove('hidden');$('#pdf-controls').classList.remove('hidden');$('#pdf-reading-tools').classList.remove('hidden');
    $('#reading-status').textContent='正在打开 PDF…';
    try {
      if(!pdfjs) {pdfjs=await import('/vendor/pdf.min.mjs');pdfjs.GlobalWorkerOptions.workerSrc='/vendor/pdf.worker.min.mjs';}
      const task=pdfjs.getDocument({url:'/files/'+id,cMapUrl:'/vendor/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/standard_fonts/',wasmUrl:'/vendor/wasm/',isEvalSupported:false,disableAutoFetch:true});
      const loaded=await task.promise;
      if(serial!==docSerial){await loaded.destroy();return;}
      pdf=loaded;currentPage=Math.min(Math.max(1,currentPage),pdf.numPages);await renderPdf();
    }catch(e){if(serial===docSerial){toast('PDF 打开失败：'+(e.message || '请检查文件是否加密或损坏'),true);$('#reading-status').textContent='无法打开此 PDF，可尝试其他文件';}}
  } else {
    $('#export-pdf-structure').classList.add('hidden');
    $('#article').classList.remove('hidden');$('#pdf-page').classList.add('hidden');$('#pdf-controls').classList.add('hidden');
    $('#pdf-reading-tools').classList.add('hidden');
    docText=currentDoc.content;pageText=docText;
    pageParagraphs=docText.split(/\n\s*\n/).filter(x=>x.trim());
    if(pageParagraphs.length===1)pageParagraphs=docText.split(/\n/).filter(x=>x.trim());
    $('#article').innerHTML=`<div class="article-category">YOUR READING</div><h2>${esc(currentDoc.name.replace(/\.(txt|md)$/i,''))}</h2><div class="article-meta"><span>本地文献</span><span>${docText.length.toLocaleString()} 字符</span></div><div class="article-body">${pageParagraphs.map((p,i)=>`<p data-paragraph="${i}">${esc(p).replace(/\n/g,'<br>')}</p>`).join('')}</div>`;
    setPassages(pageParagraphs.map((text,i)=>({id:'passage-'+i,text,itemIndices:[],lines:[]})));
    $('#reading-status').textContent='选中文字即可翻译 · 内容已保存在本机';$('#paper-scroll').scrollTop=0;await saveProgress();
  }
}
async function saveProgress() {if(!currentDoc)return;await api('document/save',{id:currentDoc.id,page:currentPage,total:pdf?.numPages || 1});}
async function renderPdf() {
  if(!pdf)return;
  const serial=++renderSerial;const pageNumber=currentPage;const documentRef=pdf,documentId=currentDoc.id;
  const key=documentId+':'+pageNumber;const previousScroll=$('#paper-scroll').scrollTop;const samePage=key===lastPageKey;
  try {
    const record=await loadPdfRecord(documentRef,pageNumber,true);if(serial!==renderSerial)return;
    const page=record.page,unscaled=record.viewport;pdfRecord=record;
    if((state.settings.readerMode || 'split')!=='pdf'){
      pdfViewport=unscaled;pdfSize={width:unscaled.width,height:unscaled.height};pdfItems=record.content.items;pdfSpans=[];
      await ensurePdfGraphics(record);
      if(serial!==renderSerial)return;
      if(!ocrCache.has(key)){try{const cached=await api('ocr-page?doc='+encodeURIComponent(documentId)+'&page='+pageNumber);ocrCache.set(key,cached.available?cached:null);}catch{ocrCache.set(key,null);}}
      if(serial!==renderSerial)return;pageOcr=effectivePageOcr(record,ocrCache.get(key));rebuildLayout();lastPageKey=key;
      $('#page-input').value=pageNumber;$('#page-input').max=documentRef.numPages;$('#page-total').textContent='/ '+documentRef.numPages;
      await saveProgress();if(serial===renderSerial)prefetchPdfNeighbors(documentRef,pageNumber,docSerial).catch(()=>{});return;
    }
    const available=Math.max(240,$('#paper-scroll').clientWidth-35);
    const scale=zoom || available/unscaled.width;
    const ratio=Math.min(window.devicePixelRatio || 1,2);
    if(!ocrCache.has(key)){try{const cached=await api('ocr-page?doc='+encodeURIComponent(documentId)+'&page='+pageNumber);ocrCache.set(key,cached.available?cached:null);}catch{ocrCache.set(key,null);}}
    if(serial!==renderSerial)return;
    if(ocrCache.get(key)){await ensurePdfGraphics(record);if(serial!==renderSerial)return;}
    pageOcr=effectivePageOcr(record,ocrCache.get(key));
    pdfSurface ||= new PdfSurface({canvas:$('#pdf-canvas'),container:$('#pdf-text'),wrapper:$('#pdf-page'),TextLayer:pdfjs.TextLayer});
    const surface=await pdfSurface.present({page,content:record.content,scale,ratio,revision:pageOcr});
    if(serial!==renderSerial)return;
    pdfViewport=surface.viewport;pdfSize={width:unscaled.width,height:unscaled.height};
    textLayer=surface.layer;pdfItems=record.content.items;pdfSpans=surface.spans;
    surface.painted.then(ok=>{if(!ok && surface.error?.name!=='RenderingCancelledException' && serial===renderSerial)toast('原页绘制失败，可切换页面重试',true);});
    await ensurePdfGraphics(record);if(serial!==renderSerial)return;
    if(!ocrCache.has(key)){
      try{const cached=await api('ocr-page?doc='+encodeURIComponent(documentId)+'&page='+pageNumber);ocrCache.set(key,cached.available?cached:null);}catch{ocrCache.set(key,null);}
    }
    if(serial!==renderSerial)return;
    pageOcr=effectivePageOcr(record,ocrCache.get(key));if(pageOcr)renderOcrLayer(pageOcr);
    rebuildLayout();lastPageKey=key;
    $('#page-input').value=pageNumber;$('#page-input').max=documentRef.numPages;$('#page-total').textContent='/ '+documentRef.numPages;
    $('#zoom-label').textContent=zoom?Math.round(scale*100)+'%':'适合宽度';
    $('#reading-status').textContent=pdfReadingStatus(pdfDocumentStructure?.pages.find(p=>p.pageNumber===pageNumber));
    $('#paper-scroll').scrollTop=samePage?previousScroll:0;await saveProgress();
    prefetchPdfNeighbors(documentRef,pageNumber,docSerial).catch(()=>{});
  }catch(e){if(e.name!=='RenderingCancelledException' && e.name!=='AbortException' && serial===renderSerial)toast('页面渲染失败：'+e.message,true);}
}
function setPassages(value){
  const previous=activePassage,changed=value.length!==passages.length || value.some((paragraph,index)=>paragraph!==passages[index]);
  passages=value;if(changed){pageParagraphs=value.map(p=>p.text);pageText=pageParagraphs.join('\n\n');}
  $$('.article-body p').forEach((p,i)=>{p.dataset.passage=value[i]?.id || '';p.classList.remove('linked-active');});
  if(pdf){
    pdfSpans.forEach(s=>{if(s)delete s.dataset.passage;});
    for(const p of value)for(const index of p.itemIndices){if(pdfSpans[index])pdfSpans[index].dataset.passage=p.id;}
  }
  activePassage='';$('#pdf-highlights').replaceChildren();
  if(previous && value.some(p=>p.id===previous))activatePassage(previous);
  if(changed)scheduleParagraphView();
  immersiveReader.update();
}
function rebuildLayout(){
  if(!pdf || !pdfSize || !pdfRecord)return;
  const layout=analyzeRecord(pdfRecord,$('#column-mode').value,pageOcr);
  assignPdfStructure([layout.page],true);
  applyPdfStructure(pdfDocumentStructure.pages.find(page=>page.pageNumber===currentPage) || layout.page);
  const container=$('#pdf-text');
  if(!pageOcr)registerPdfGeometry(pdfSpans,pdfItems,pdfRecord.glyphMetrics);
  if(pdfSpans.filter(span=>span?.isConnected).every(span=>span.parentElement===container)){
    const fragment=document.createDocumentFragment();
    const added=new Set();
    for(const line of pdfSelectionLines(layout.allParagraphs,pdfItems)){
      let previous=null;
      for(const index of line.indices){
        const span=pdfSpans[index];if(!span || added.has(index))continue;
        const separator=previous===null?'':pdfFragmentSeparator(pdfItems[previous],pdfItems[index]);
        if(separator)fragment.append(document.createTextNode(separator));
        span.dataset.selectionLine=line.id;
        fragment.append(span);added.add(index);previous=index;
      }
      fragment.append(document.createElement('br'));
    }
    // Keep all original spans, including decorations and unassigned whitespace.
    pdfSpans.forEach((span,index)=>{if(span && !added.has(index))fragment.append(span);});
    container.replaceChildren(fragment);
  }
  $('#ocr-label').textContent=pageOcr?'重新识别本页':'识别本页文字';
  $('#ocr-label').title=!pageOcr && ocrCache.get(currentDoc.id+':'+currentPage)?'已保留历史 OCR；本页优先使用可靠的 PDF 原生文字与版面信息。':'';
}
function renderOcrLayer(result){
  const container=$('#pdf-text');container.replaceChildren();container.classList.add('ocr-layer');pdfSpans=[];
  const scaleX=pdfViewport.width/result.width,scaleY=pdfViewport.height/result.height;
  const measure=document.createElement('canvas').getContext('2d');
  for(const line of result.lines || []){
    for(const [index,word] of (line.words || []).entries()){
      const span=document.createElement('span');const size=Math.max(3,word.height*scaleY*.94);const text=word.text+(index<line.words.length-1?' ':'');
      span.textContent=text;span.style.left=word.x*scaleX+'px';span.style.top=word.y*scaleY+'px';span.style.fontSize=size+'px';span.style.fontFamily='Arial';span.style.height=word.height*scaleY+'px';
      measure.font=size+'px Arial';const width=measure.measureText(word.text).width || 1;span.style.transform='scaleX('+(word.width*scaleX/width)+')';span.style.transformOrigin='0 0';
      container.append(span);pdfSpans.push(span);
    }
    container.append(document.createElement('br'));
  }
}
async function recognizePage(){
  if(!pdf)return;const documentRef=pdf,documentSerial=docSerial,docId=currentDoc.id,pageNumber=currentPage,key=docId+':'+pageNumber;
  const stillCurrent=()=>pdf===documentRef && docSerial===documentSerial && currentDoc?.id===docId && currentPage===pageNumber;
  const button=$('[data-action="ocr-page"]');button.disabled=true;$('#ocr-label').textContent='正在本机识别…';
  const copy=document.createElement('canvas');
  try{
    // Immersive modes do not render #pdf-canvas. Render the captured page itself,
    // independently of display mode, zoom, device scale or a stale visible canvas.
    const page=await documentRef.getPage(pageNumber);if(!stillCurrent())return;
    const unscaled=page.getViewport({scale:1}),scale=Math.min(3,2300/Math.max(unscaled.width,unscaled.height));
    const viewport=page.getViewport({scale});copy.width=Math.max(1,Math.min(2300,Math.round(viewport.width)));copy.height=Math.max(1,Math.min(2300,Math.round(viewport.height)));
    await page.render({canvasContext:copy.getContext('2d',{alpha:false}),viewport}).promise;if(!stillCurrent())return;
    const raw=await new Promise(resolve=>copy.toBlob(resolve,'image/png'));
    if(!raw)throw new Error('本页图像无法生成，请重试');if(!stillCurrent())return;
    const response=await fetch('/api/ocr-page?doc='+encodeURIComponent(docId)+'&page='+pageNumber,{method:'POST',headers:{'X-App-Token':token},body:raw});
    const result=await response.json();if(!response.ok)throw new Error(result.error);ocrCache.set(key,result);paragraphWindows=new Map();resolvedWindow=null;
    if(stillCurrent()){
      ++parallelSerial;resetParallel();pageOcr=result;
      // The existing render path rebuilds this page's real layout in every mode;
      // only original-PDF mode creates an OCR selection layer.
      await renderPdf();if(!stillCurrent())return;
      prefetchPdfNeighbors(documentRef,pageNumber,documentSerial).catch(()=>{});$('#reading-status').textContent='第 '+pageNumber+' 页 · 本机识别完成，可直接划词与逐段翻译';toast('本页文字识别完成，结果已保存在本地');
    }
  }catch(error){if(stillCurrent())throw error;}
  finally{copy.width=0;copy.height=0;button.disabled=false;$('#ocr-label').textContent=pageOcr?'重新识别本页':'识别本页文字';}
}
function sourceElement(id){return pdf?$('#pdf-text [data-passage="'+id+'"]'):$('.article-body [data-passage="'+id+'"]');}
function sourceBounds(p){
  if(pdf && pdfViewport && p.lines.length){
    const pageRect=$('#pdf-page').getBoundingClientRect();const rectangles=p.lines.map(line=>pdfViewport.convertToViewportRectangle([line.x,line.y,line.x+line.width,line.y+line.height]));
    return {top:pageRect.top+Math.min(...rectangles.map(r=>Math.min(r[1],r[3]))),bottom:pageRect.top+Math.max(...rectangles.map(r=>Math.max(r[1],r[3])))};
  }
  return sourceElement(p.id)?.getBoundingClientRect();
}
function jumpToPassage(id,from='translation'){
  immersiveReader.navigationIntent();
  sourceIntentUntil=0;translationIntentUntil=0;
  ignoreSourceScroll=performance.now()+750;ignoreTranslationScroll=performance.now()+750;
  cancelAnimationFrame(sourceFrame);cancelAnimationFrame(translationFrame);sourceFrame=0;translationFrame=0;
  const automatic=state.settings.readerAutoLocate!==false;
  activatePassage(id,automatic && from==='translation',automatic && from==='source');
  const logical=immersiveReader.fromPhysical(id);
  if(logical){immersiveReader.activeId=logical.id;immersiveReader.view.highlight(logical.id);immersiveReader.saveProgress({id:logical.id,fraction:0,pane:from==='source'?'pdf':'translation'});}
}
function activatePassage(id,scrollSource=false,scrollTarget=false){
  const p=passages.find(p=>p.id===id);if(!p)return;
  if(activePassage!==id){
    activePassage=id;$$('.linked-active',$('#article')).forEach(e=>e.classList.remove('linked-active'));
    $$('#paragraph-results .parallel-item').forEach(e=>e.classList.toggle('linked-active',e.dataset.passage===id));
    $('#pdf-highlights').replaceChildren();
    if(pdf && pdfViewport){
      for(const line of p.lines){const r=pdfViewport.convertToViewportRectangle([line.x,line.y,line.x+line.width,line.y+line.height]);const div=document.createElement('div');div.className='source-highlight';Object.assign(div.style,{left:Math.min(r[0],r[2])+'px',top:Math.min(r[1],r[3])+'px',width:Math.abs(r[2]-r[0])+'px',height:Math.abs(r[3]-r[1])+'px'});$('#pdf-highlights').append(div);}
    }else sourceElement(id)?.classList.add('linked-active');
  }
  if(scrollSource){const bounds=sourceBounds(p),container=$('#paper-scroll');if(bounds){ignoreSourceScroll=performance.now()+750;container.scrollTo({top:container.scrollTop+bounds.top-container.getBoundingClientRect().top-35,behavior:'instant'});}}
  if(scrollTarget){const card=$('#paragraph-results [data-passage="'+id+'"]'),container=$('#translation-scroll');if(card){ignoreTranslationScroll=performance.now()+750;container.scrollTo({top:container.scrollTop+card.getBoundingClientRect().top-container.getBoundingClientRect().top-18,behavior:'instant'});}}
}
function pdfAnchorMetrics(column=null){
  const container=$('#paper-scroll'),origin=container.getBoundingClientRect().top;
  return passages.filter(p=>column===null || p.column===column || p.column==='span').map(p=>{
    const logical=immersiveReader.fromPhysical(p.id),bounds=sourceBounds(p);
    return logical && bounds?{id:logical.id,physicalId:p.id,top:bounds.top-origin+container.scrollTop,height:Math.max(1,bounds.bottom-bounds.top)}:null;
  }).filter(Boolean);
}
function translationAnchorMetrics(){
  const container=$('#translation-scroll'),origin=container.getBoundingClientRect().top;
  return $$('#paragraph-results .parallel-item').map(node=>{const rect=node.getBoundingClientRect();return {id:node.dataset.paragraphId,top:rect.top-origin+container.scrollTop,height:Math.max(1,rect.height)};});
}
function syncFromSource(){
  if(state.settings.readerMode!=='pdf' || performance.now()<ignoreSourceScroll || performance.now()>sourceIntentUntil)return;
  const container=$('#paper-scroll'),column=passages.find(p=>p.id===activePassage)?.column ?? passages.find(p=>typeof p.column==='number')?.column ?? null;
  const source=pdfAnchorMetrics(column),anchor=captureAnchor(source,container.scrollTop,container.clientHeight,40);if(!anchor)return;
  const target=$('#translation-scroll'),top=anchorScrollTop(anchor,translationAnchorMetrics(),Math.max(0,target.scrollHeight-target.clientHeight),24);
  if(state.settings.syncScroll!==false && !$('#paragraph-content').classList.contains('hidden') && top!==null){ignoreTranslationScroll=performance.now()+500;translationIntentUntil=0;target.scrollTo({top,behavior:'instant'});}
  const physical=source.find(p=>p.id===anchor.id);if(physical)activatePassage(physical.physicalId,false,false);
  immersiveReader.activeId=anchor.id;immersiveReader.saveProgress({...anchor,pane:'pdf'});
}
function syncFromTranslation(){
  if(state.settings.readerMode!=='pdf' || performance.now()<ignoreTranslationScroll || performance.now()>translationIntentUntil || $('#paragraph-content').classList.contains('hidden'))return;
  const container=$('#translation-scroll'),anchor=captureAnchor(translationAnchorMetrics(),container.scrollTop,container.clientHeight,24);if(!anchor)return;
  const target=$('#paper-scroll'),source=pdfAnchorMetrics(),top=anchorScrollTop(anchor,source,Math.max(0,target.scrollHeight-target.clientHeight),40);
  if(state.settings.syncScroll!==false && top!==null){ignoreSourceScroll=performance.now()+500;sourceIntentUntil=0;target.scrollTo({top,behavior:'instant'});}
  const physical=source.find(p=>p.id===anchor.id);if(physical)activatePassage(physical.physicalId,false,false);
  immersiveReader.activeId=anchor.id;immersiveReader.saveProgress({...anchor,pane:'translation'});
}

function invalidateInstant(clear=false){
  ++translateSerial;instantRequest.invalidate();clearTimeout(debounceTimer);if(clear){lastResult=null;lastResultKey='';instantFailure=null;}
  $('#translate-button').disabled=false;$('#translate-button span').textContent='翻译一下';
  if(clear){$('#translation-result').className='translation-result empty';$('#translation-result').textContent='选中文字，查看对应译文。';}
}
function sourceChanged(auto=true) {
  selectionPending=false;invalidateInstant(true);
  $('#char-count').textContent=$('#source-text').value.length.toLocaleString()+' / 18000';
  clearTimeout(debounceTimer);
  if(auto && state.settings.autoTranslate && $('#source-text').value.trim())debounceTimer=setTimeout(()=>translate(),750);
}
function setSource(text,context='',{exact=false}={}) {
  // Cleanup is a derived translation input; the native Range and PDF spans remain untouched.
  text=cleanupSelectedText(text,{evidence:[context]}).trim();if(!text)return;
  const key=instantKey(text,context);
  if(text===$('#source-text').value && context===currentContext && (instantRequest.active?.key===key || (lastResult && lastResultKey===key))){setTab(false);return;}
  if(text.length>18000){invalidateInstant(true);$('#source-text').value=text;currentContext=context;sourceChanged(false);setTab(false);toast('选中文字太长，请分段翻译（每次最多 18,000 字符）',true);return;}
  ++translateSerial;$('#translate-button').disabled=false;$('#translate-button span').textContent='翻译一下';
  $('#source-text').value=text;currentContext=context;sourceChanged(false);setTab(false);
  if(state.settings.autoTranslate)translate();
}
function instantTranslationContext(text,context=currentContext){
  if(document.body.dataset.currentView==='home')return {};
  return selectionTranslationContext({text,context,structure:pdf?pdfDocumentStructure:null,page:currentPage,paragraphId:immersiveReader.selection?.id});
}
function instantKey(text=$('#source-text').value.trim(),context=currentContext){
  return JSON.stringify([CONTEXT_STRATEGY,instantTranslationContext(text,context),translationDocId(),text,$('#source-lang').value,$('#target-lang').value,
    state.settings.provider,state.settings.model,state.settings.apiBase,context,currentSelectionHint,currentPage]);
}
function instantSelectionChanging(){return selectionDragging || selectionPending;}
function restoreCompletedInstant(){
  if(lastResult || instantRequest.pending || instantSelectionChanging())return;
  const result=instantRequest.cached(instantKey());
  if(result){result.cached=true;lastResult=result;lastResultKey=instantKey();renderTranslation(result);}
  else if(instantFailure?.key===instantKey())renderInstantError(instantFailure.message);
}
function setTab(parallel) {
  if(!parallel)immersiveReader.showLookup();
  $('#instant-tab').classList.toggle('active',!parallel);$('#paragraph-tab').classList.toggle('active',parallel);
  $('#instant-tab').setAttribute('aria-selected',!parallel);$('#paragraph-tab').setAttribute('aria-selected',parallel);
  $('#instant-content').classList.toggle('hidden',parallel);$('#paragraph-content').classList.toggle('hidden',!parallel);
  if(parallel)renderParagraphResults();
}
function setFocus(enabled){
  const changed=document.body.classList.contains('focus-mode')!==enabled;document.body.classList.toggle('focus-mode',enabled);
  if(changed && pdf)requestAnimationFrame(()=>renderPdf());
}
function resetParallel(){
  clearTimeout(selectionTimer);selectionDragging=false;selectionPending=false;lastSelectionKey='';hideSelectionTools();invalidateInstant(true);
  ++paragraphViewSerial;paragraphRecords=new Map();paragraphJob=null;
  $('#paragraph-results').replaceChildren();const button=$('[data-action="translate-paragraphs"]');
  button.disabled=false;button.innerHTML=icon('spark')+'翻译当前内容';
  activePassage='';$('#pdf-highlights').replaceChildren();$$('.article-body .linked-active').forEach(e=>e.classList.remove('linked-active'));
  $('#paragraph-progress').textContent='';$('#cancel-paragraphs').classList.add('hidden');$('#retry-paragraphs').classList.add('hidden');$('#export-paragraphs').classList.add('hidden');
}
async function translate() {
  clearTimeout(debounceTimer);const text=$('#source-text').value.trim();if(!text){toast('先选中或粘贴一段原文');return;}
  const home=document.body.dataset.currentView==='home';
  const lookup=home?(/^[A-Za-z]+(?:['’‐‑-][A-Za-z]+)*$/.test(text) && ['en','auto'].includes($('#source-lang').value)?{sentence:''}:null):localLookup({text,context:currentContext,hint:currentSelectionHint,structure:pdfDocumentStructure,page:currentPage,source:$('#source-lang').value,target:$('#target-lang').value});
  const key=instantKey(text),cached=instantRequest.cached(key);
  if(cached){cached.cached=true;lastResult=cached;lastResultKey=key;renderTranslation(cached);return;}
  const request=instantRequest.begin(key);if(!request)return;
  const serial=++translateSerial;lastResult=null;instantFailure=null;
  $('#translate-button').disabled=true;$('#translate-button span').textContent='正在翻译…';
  $('#translation-result').className='translation-result';$('#translation-result').innerHTML='<div class="loading-text"><span class="spinner"></span>正在理解这段文字…</div><div class="loading-shimmer"></div><div class="loading-shimmer"></div><div class="loading-shimmer"></div>';
  try {
    const options={text,source:$('#source-lang').value,target:$('#target-lang').value,provider:state.settings.provider};
    const result=lookup?.result || await api(lookup?'lookup':'translate',lookup?{...options,sentence:lookup.sentence,context:instantTranslationContext(text)}:{...options,...(/\s/.test(text)?{mode:'text',context:instantTranslationContext(text)}:{})},{signal:request.signal});
    if(serial!==translateSerial || !instantRequest.isCurrent(request))return;
    const completed={...result,source:text,...(lookup?.supplement?{originalNote:lookup.supplement,detailSupplementary:true}:{})};instantRequest.remember(key,completed);
    // A drag may be between pointerdown and its final Range. Retain the answer
    // in cache and present it only if that same target is still committed.
    if(!instantSelectionChanging()){lastResult=completed;lastResultKey=key;renderTranslation(completed);}
    if(lookup?.result)api('lookup-record',{result}).then(()=>refresh()).catch(()=>{});else refresh().catch(()=>{});
  }catch(e){if(serial===translateSerial){instantFailure={key,message:e.message};if(!instantSelectionChanging())renderInstantError(e.message);}}
  finally{instantRequest.finish(request);if(serial===translateSerial){$('#translate-button').disabled=false;$('#translate-button span').textContent='翻译一下';}}
}
function renderInstantError(message){$('#translation-result').innerHTML=`<div class="error-text">${esc(message)}<br><button class="text-button" data-action="translate">重试翻译${icon('arrow')}</button><button class="text-button" data-action="settings">切换引擎</button></div>`;}
function renderWordDetails(detail) {
  return `<section class="dictionary-section"><h4>${esc(detail.source || '详细释义')}${detail.cached?' · 缓存（原始来源）':''}</h4><p class="dictionary-definition"><span class="dictionary-pos">${esc(detail.pos)}</span>${esc(detail.meaning)}</p>${detail.context?`<p class="context-sentence">${esc(detail.context)}</p>`:''}${(detail.phrases || []).map(p=>`<div class="dictionary-phrase"><strong>${esc(p.text)}</strong><p>${esc(p.translation)}</p></div>`).join('')}${detail.forms?.length?`<p class="dictionary-forms">${detail.forms.map(f=>esc(f.name)+'：'+esc(f.value)).join(' · ')}</p>`:''}</section>`;
}
function renderTranslation(result) {
  // Cached and contextual results can legitimately have no dictionary extensions.
  const root=$('#translation-result');
  const detailKey=JSON.stringify([result.source,result.sentence || currentContext,result.text]);
  const keepOpen=root.dataset.detailKey===detailKey && !!root.querySelector('details.dictionary-section')?.open;
  root.dataset.detailKey=detailKey;
  const items=(value,valid)=>Array.isArray(value)?value.filter(item=>item && valid(item)):[];
  result={...result,
    english:items(result.english,e=>typeof e.definition==='string' && e.definition.trim()),
    phrases:items(result.phrases,p=>typeof p.text==='string' && p.text.trim()),
    synonyms:items(result.synonyms,w=>typeof w==='string' && w.trim()),
    examples:items(result.examples,e=>typeof e.text==='string' && e.text.trim()),
    forms:items(result.forms,f=>typeof f.value==='string' && f.value.trim())};
  $('#translation-result').className='translation-result';
  const saved=state.vocabulary.some(w=>w.word.toLowerCase()===result.source.toLowerCase());
  const phonetics=result.phonetics || {};const headword=result.headword || result.source;
  const phones=['uk','us'].filter(k=>phonetics[k]).map(k=>`<button class="phone-button" data-speak="${esc(headword)}" data-speak-lang="${k==='uk'?'en-GB':'en-US'}">${k==='uk'?'英':'美'} /${esc(phonetics[k])}/ ${icon('volume')}</button>`).join('');
  const details=result.isWord?`${result.english?.length?`<section class="dictionary-section"><h4>英文解释 · WordNet</h4>${result.english.map(e=>`<p class="dictionary-definition"><span class="dictionary-pos">${esc(e.pos)}</span>${esc(e.definition)}</p>`).join('')}</section>`:''}${result.phrases?.length?`<section class="dictionary-section"><h4>常用搭配</h4>${result.phrases.map(p=>`<div class="dictionary-phrase"><strong>${esc(p.text)}</strong><p>${esc(p.translation)}</p></div>`).join('')}</section>`:''}${result.synonyms?.length?`<section class="dictionary-section"><h4>近义词 · 点击继续查词</h4><div class="synonym-chips">${result.synonyms.map(w=>`<button data-lookup="${esc(w)}">${esc(w)}</button>`).join('')}</div></section>`:''}${result.examples?.length?`<section class="dictionary-section"><h4>双语例句</h4>${result.examples.map(e=>`<div class="dictionary-example"><blockquote>${esc(e.text)}</blockquote><p>${esc(e.translation)}</p><cite>${esc(e.source)}</cite></div>`).join('')}</section>`:''}${result.forms?.length?`<p class="dictionary-forms">${result.forms.map(f=>esc(f.name)+'：'+esc(f.value)).join(' · ')}</p>`:''}`:'';
  if(result.isWord){
    const sentence=result.sentence || currentContext;
    $('#translation-result').innerHTML=`<div class="result-header"><span class="label">${icon('spark')}单词释义</span><span>${esc(result.engine || '来源未记录')}${result.cached?' · 缓存（原始来源）':''}</span></div><div class="result-word">${esc(result.source)}</div>${headword.toLowerCase()!==result.source.toLowerCase() || result.pos?`<div class="dictionary-lemma">${esc(headword)} ${esc(result.pos || '')}</div>`:''}<div class="result-text">${esc(result.text)}</div>${result.aiWarning?`<p class="source-warning" role="status">${esc(result.aiWarning)}</p>`:''}${result.contextNote?`<p class="context-sentence">${esc(result.contextNote)}</p>`:''}${sentence?`<section class="dictionary-section"><h4>原句</h4><p class="context-sentence">${esc(sentence)}</p></section>`:''}<details class="dictionary-section dictionary-details"${keepOpen?' open':''}><summary>详细释义与操作</summary><div class="dictionary-details-body">${phones?`<div class="dictionary-phone">${phones}</div>`:''}${result.originalNote?`<section class="dictionary-section"><h4>PDF 原文自带解释${result.detailSupplementary?' · 短语补充':''}</h4><p class="context-sentence">${esc(result.originalNote)}</p></section>`:''}${details}<div class="word-details-slot">${result.wordDetails?renderWordDetails(result.wordDetails):''}</div>${!result.wordDetails && !phones && !result.originalNote && !details?'<p class="dictionary-empty">展开后按需加载详细释义。</p>':''}<div class="result-actions"><button data-action="copy-translation">${icon('copy')}复制</button><button data-action="speak-source">${icon('volume')}读原文</button><button class="${saved?'saved':''}" data-action="save-word">${icon('star')}${saved?'已收藏':'收藏'}</button></div></div></details>`;
    return;
  }
  $('#translation-result').innerHTML=`<div class="result-header"><span class="label">${icon('spark')}${result.isWord?'单词释义':'译文'}</span><span>${esc(result.engine || '来源未记录')}${result.cached?' · 缓存（原始来源）':''}</span></div>${result.isWord?`<div class="result-word">${esc(headword)}</div>${headword.toLowerCase()!==result.source.toLowerCase()?`<div class="dictionary-lemma">选中：${esc(result.source)} · 词典关联词条</div>`:''}${phones?`<div class="dictionary-phone">${phones}</div>`:''}`:''}<div class="result-text">${esc(result.text)}</div>${result.aiWarning?`<p class="source-warning" role="status">${esc(result.aiWarning)}</p>`:''}<div class="result-actions"><button data-action="copy-translation">${icon('copy')}复制</button><button data-action="speak-source">${icon('volume')}读原文</button><button class="${saved?'saved':''}" data-action="save-word">${icon('star')}${saved?'已收藏':'收藏'}</button></div>${currentContext?`<section class="dictionary-section"><h4>当前文章中的语境</h4><p class="context-sentence">${esc(currentContext)}</p></section>`:''}${details}`;
}
async function saveWord() {
  if(!lastResult)return;
  const savedResult=lastResult,context=currentContext;
  await api('vocabulary',{word:savedResult.source,translation:savedResult.text,context,phonetic:savedResult.phonetic || '',detail:savedResult});
  await refresh();
  // Saving an older selection must not redraw or replace the current result.
  if(lastResult===savedResult)renderTranslation(savedResult);
  toast('已收藏到生词本');
}
const detailRequests=new Map();
async function ensureWordDetails() {
  const result=lastResult,root=$('#translation-result'),disclosure=root.querySelector('.dictionary-details');
  if(!result?.isWord || !disclosure?.open)return;
  if((result.originalNote && !result.detailSupplementary) || ['english','phrases','forms','examples'].some(k=>Array.isArray(result[k]) && result[k].length))return;
  const sentence=result.sentence || currentContext,options={text:result.source,sentence,source:$('#source-lang').value,target:$('#target-lang').value};
  const key=JSON.stringify([1,...Object.values(options),state.settings.provider,state.settings.apiBase,state.settings.model,state.settings.aiFastMode]);
  const slot=disclosure.querySelector('.word-details-slot');if(!slot)return;
  const valid=()=>lastResult===result && slot.isConnected &&
    key===JSON.stringify([1,result.source,result.sentence || currentContext,$('#source-lang').value,$('#target-lang').value,state.settings.provider,state.settings.apiBase,state.settings.model,state.settings.aiFastMode]);
  if(result.wordDetails && result.wordDetailsKey===key){slot.innerHTML=renderWordDetails({...result.wordDetails,cached:true});return;}
  disclosure.querySelector('.dictionary-empty')?.remove();
  slot.innerHTML='<p role="status" class="loading-text"><span class="spinner"></span>正在加载详细释义…</p>';
  try {
    let pending=detailRequests.get(key);
    if(!pending){
      // Bound wait even if the browser loses the local server connection.
      const seconds=Math.min(600,Math.max(15,state.settings.aiTimeoutSeconds || 180));
      pending=api('word-details',options,{signal:AbortSignal.timeout((seconds+20)*1000)});
      detailRequests.set(key,pending);
      pending.finally(()=>{if(detailRequests.get(key)===pending)detailRequests.delete(key);}).catch(()=>{});
    }
    const detail=await pending;
    result.wordDetails=detail;result.wordDetailsKey=key;
    if(valid())slot.innerHTML=renderWordDetails(detail);
  }catch(e){if(valid())slot.innerHTML=`<p class="error-text">${esc(e.name==='TimeoutError'?'详情加载超时，请重试。':e.message)}</p><button class="text-button" data-action="retry-word-details">重试详情</button>`;}
}
document.addEventListener('toggle',event=>{
  if(event.target.matches?.('#translation-result .dictionary-details') && event.target.isConnected && event.target.open)ensureWordDetails();
},true);
function speak(text,lang='en-US') {
  if(!('speechSynthesis' in window)){toast('当前浏览器不支持朗读',true);return;}
  speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.lang=lang;utterance.rate=.85;
  const voice=speechSynthesis.getVoices().find(v=>v.lang.toLowerCase().startsWith(lang.toLowerCase()) && v.localService);
  if(voice)utterance.voice=voice;utterance.onerror=()=>toast('朗读暂时不可用，请检查 Windows 语音组件',true);speechSynthesis.speak(utterance);
}
async function translateParagraphs(ids=null,force=false) {
  setTab(true);const doc=translationDocId(),serial=docSerial,page=currentPage,previous=currentTranslationManifest();
  // Await complete logical paragraphs, independent of currently rendered pages.
  if(pdf)await prefetchPdfNeighbors(pdf,currentPage,docSerial);
  if(doc!==translationDocId() || serial!==docSerial || page!==currentPage)return;
  const manifest=currentTranslationManifest();
  if(!manifest.target_ids.length){toast('这页没有可识别的文字，请先点击「识别本页文字」');return;}
  clearTimeout(paragraphViewTimer);++paragraphViewSerial;
  const button=$('[data-action="translate-paragraphs"]');button.disabled=true;
  try{
    await paragraphClient.submit(manifest,{source:$('#source-lang').value,target:$('#target-lang').value,provider:state.settings.provider},
      {ids:resolvedTargetIds(manifest,previous,ids),force});
  }finally{if(doc===translationDocId())renderParagraphResults();}
}
function renderParagraphResults(){
  if((state.settings.readerMode || 'split')!=='pdf'){
    $('#paragraph-results').replaceChildren();immersiveReader.update();return;
  }
  const manifest=currentTranslationManifest(),ids=new Set(manifest.target_ids);
  const paragraphs=manifest.paragraphs.filter(p=>ids.has(p.paragraph_id));
  const target=$('#paragraph-results'),cards=new Map([...target.children].map(card=>[card.dataset.paragraphId,card])),remaining=new Set(cards.values());
  const labels={not_started:'尚未翻译',queued:'等待翻译',running:'正在翻译…',retrying:'连接重试中…',succeeded:'翻译完成',failed:'翻译失败',cancelled:'已取消'};
  let retryable=0;
  for(const [index,p] of paragraphs.entries()){
    const item=paragraphRecords.get(p.paragraph_id),result=item && matchesSource(item,p) &&
      item.source_language===$('#source-lang').value && item.target_language===$('#target-lang').value && item.provider===state.settings.provider &&
      (item.provider!=='custom' || item.requested_model===state.settings.model)?item:null;
    const status=result?.status || 'not_started';if(['failed','cancelled'].includes(status))retryable++;
    const physical=p.source_parts.find(part=>part.page_number===currentPage) || p.source_parts[0];
    let card=cards.get(p.paragraph_id);
    if(!card){card=document.createElement('section');card.className='parallel-item';card.tabIndex=0;card.dataset.paragraphId=p.paragraph_id;target.append(card);}
    if(target.children[index]!==card)target.insertBefore(card,target.children[index] || null);
    remaining.delete(card);card.dataset.passage=physical.paragraph_id;card.dataset.jumpPassage=physical.paragraph_id;
    card.dataset.status=status;card.setAttribute('aria-label','定位第 '+(index+1)+' 段原文');
    const signature=JSON.stringify([index,p,result,status]);
    if(card._signature===signature)continue;card._signature=signature;
    const warnings=(result?.warnings || []).filter(w=>w.severity!=='info');
    const model=result?.model && ({bing:'微软翻译',google:'Google 翻译',memory:'MyMemory',identity:'原文保留'}[result.model] || result.model);
    card.innerHTML=`<div class="parallel-number">PASSAGE ${String(index+1).padStart(2,'0')}<span class="passage-status">${esc(labels[status])}</span></div><p class="parallel-source">${esc(p.text)}</p><div class="parallel-translation">${result?.translation?esc(result.translation):`<span class="${status==='failed'?'error-text':'loading-text'}">${esc(result?.error || labels[status])}</span>`}</div><div class="paragraph-meta">${result?.model?`<span>${esc(model)}${result.cached?' · 缓存':''}</span>`:''}${p.source_parts.map(part=>`<button class="text-button" data-locate-page="${part.page_number}" title="定位 PDF 原始位置">第 ${part.page_number} 页${icon('arrow')}</button>`).join('')}</div>${warnings.length?`<div class="paragraph-warning" role="status">待核对 · ${warnings.map(w=>esc(w.message)).join('；')}</div>`:''}${result?.capabilities?.context_aware===false && result.model!=='identity'?'<p class="paragraph-capability">公共引擎 · 未启用 AI 上下文</p>':''}${result?`<button class="text-button paragraph-retry" data-retry-paragraph="${esc(p.paragraph_id)}">${status==='succeeded'?'重新翻译此段':'重试此段'}</button>`:''}`;
  }
  for(const card of remaining)card.remove();
  const progress=paragraphJob?.progress,running=paragraphJob?.status==='active';
  $('#paragraph-progress').textContent=progress?`${running?'后台翻译':'本批结果'} · ${progress.succeeded} / ${progress.total} 段完成${progress.failed?' · '+progress.failed+' 段失败':''}${progress.cancelled?' · '+progress.cancelled+' 段已取消':''}${progress.cached?' · '+progress.cached+' 段缓存':''}`:'';
  $('#cancel-paragraphs').classList.toggle('hidden',!running);$('#retry-paragraphs').classList.toggle('hidden',!retryable);
  $('#retry-paragraphs').disabled=running;$$('.paragraph-retry',target).forEach(button=>button.disabled=running);
  $('#export-paragraphs').classList.toggle('hidden',!paragraphs.some(p=>paragraphRecords.get(p.paragraph_id)?.translation));
  const button=$('[data-action="translate-paragraphs"]');button.disabled=running || !paragraphs.length;button.innerHTML=running?'<span class="spinner"></span>后台正在翻译':icon('spark')+'翻译当前内容';
  if(activePassage)$$('#paragraph-results .parallel-item').forEach(card=>card.classList.toggle('linked-active',card.dataset.passage===activePassage));
  immersiveReader.update();
}
async function locateTranslatedParagraph(id,page){
  await immersiveReader.locate(id,{page,original:true});
}

function renderCollections() {
  const query=($('#library-search').value || '').toLowerCase();
  const docs=state.documents.filter(d=>d.name.toLowerCase().includes(query));
  $('#library-grid').innerHTML=docs.map(d=>`<div class="library-card"><div class="book-cover">${icon('book')}</div><div class="book-info"><span class="file-type">${d.kind==='pdf'?'PDF':'TEXT'}</span><h3>${esc(d.name)}</h3><div class="book-progress"><span>${d.kind==='pdf'?`已读至 ${d.page} / ${d.total} 页`:'文本阅读'}</span><span>${date(d.opened)}</span></div></div><button class="book-open" data-doc="${esc(d.id)}" aria-label="阅读 ${esc(d.name)}"></button><button class="book-delete" data-delete-doc="${esc(d.id)}" title="从书库删除">${icon('trash')}</button></div>`).join('');
  if(query && !docs.length)$('#library-grid').innerHTML=empty('search','没有找到这篇文献','试试其他关键词。');
  const wordQuery=($('#vocab-search').value || '').toLowerCase();
  const words=state.vocabulary.filter(w=>(w.word+' '+w.translation).toLowerCase().includes(wordQuery));
  $('#vocab-total').textContent=state.vocabulary.length+' 个收藏';
  $('#vocabulary-list').innerHTML=words.map(w=>`<div class="vocab-card"><div class="vocab-word"><h3><button data-word-view="${esc(w.id)}" title="查看完整词典卡片">${esc(w.word)}</button></h3>${w.phonetic?`<p class="phonetic">/${esc(w.phonetic)}/</p>`:""}<small>${date(w.added)} 收藏</small></div><div class="vocab-meaning">${esc(w.translation)}${w.context?`<div class="vocab-context">${esc(w.context)}</div>`:''}</div><div class="vocab-actions"><button class="bare" data-speak="${esc(w.word)}" title="朗读">${icon('volume')}</button><button class="bare" data-delete-word="${esc(w.id)}" title="移除收藏">${icon('trash')}</button></div></div>`).join('') || empty('star',wordQuery?'暂时没有找到这个词':'把第一次遇见，留给下一次熟悉',wordQuery?'试试搜索英文单词或中文释义。':'翻译后点击「收藏」，单词与句子就会出现在这里。');
  const hq=($('#history-search').value || '').toLowerCase();
  const history=state.history.filter(h=>(h.source+' '+h.translation).toLowerCase().includes(hq));
  $('#history-list').innerHTML=history.map(h=>`<div class="history-card"><div class="history-meta"><span class="status-dot"></span><span>${esc(h.engine)}</span><button class="bare" data-history="${h.id}" title="重新打开这条翻译">${icon('arrow')}</button><time>${date(h.added,true)}</time></div><div class="history-content"><p class="history-source">${esc(h.source)}</p><p class="history-translation">${esc(h.translation)}</p></div></div>`).join('') || empty('clock',hq?'没有找到相关记录':'每一次理解，都值得被记住',hq?'换个关键词试试。':'你的翻译记录会自动保存在这里。');
}
const connectionTest=attachConnectionTest(document,api);
let settingsSession=0;
function showSettings() {
  $('#settings-dialog').dataset.settingsSession=String(++settingsSession);
  $('#setting-auto').checked=!!state.settings.autoTranslate;$('#setting-clipboard').checked=!!state.settings.clipboardWatch;
  $('#setting-provider').value=state.settings.provider || 'auto';$('#custom-api').classList.toggle('hidden',state.settings.provider!=='custom');
  $('#setting-api-base').value=state.settings.apiBase || '';$('#setting-api-key').value=state.settings.apiKey || '';$('#setting-ai-timeout').value=state.settings.aiTimeoutSeconds ?? 180;$('#setting-ai-batch').value=String(state.settings.aiBatchSize ?? 1);$('#setting-ai-fast').checked=state.settings.aiFastMode!==false;$('#setting-model').value=state.settings.model || '';
  $('#setting-selection-key').value=state.settings.selectionHotkey || 'Alt+Q';$('#setting-capture-key').value=state.settings.captureHotkey || 'Ctrl+Alt+S';
  $('#setting-noactivate').checked=state.settings.popupNoActivate!==false;$('#setting-pinned').checked=state.settings.popupPinned!==false;$('#setting-restore-clipboard').checked=state.settings.restoreClipboard!==false;
  renderHotkeyStatus();
  $('#settings-dialog').showModal();connectionTest.load();updateCenter.refresh();
  const versionBox=$('#runtime-version-info');
  if(versionBox)api('runtime-info').then(info=>{
    $('#settings-software-version').textContent=info.version;
    versionBox.innerHTML=`<dt>UI 版本</dt><dd>2.0</dd><dt>构建编号</dt><dd>${esc(info.build_id || '源码候选 · 未打包')}</dd><dt>构建时间</dt><dd>${esc(info.built_at || '未打包')}</dd><dt>运行程序</dt><dd>${esc(info.executable)}</dd>${info.stable===null?'':`<dt>稳定版标识</dt><dd>${info.stable?'当前稳定版':'其他版本'}</dd>`}`;
    $('#runtime-data-directory').textContent=info.data_directory || '当前进程未提供数据路径';
  }).catch(()=>{versionBox.textContent='当前进程未提供版本信息，请从桌面固定入口重新启动。';$('#settings-software-version').textContent='版本信息暂不可用';$('#runtime-data-directory').textContent='实际路径读取失败，未更改任何数据';});
}
function renderHotkeyStatus(){
  if($('#settings-dialog')?.open===false)hotkeyNotes.clear();
  const retry=$('[data-action=retry-hotkeys]');
  if(retry?.addEventListener && !retry.dataset.feedbackReady){retry.dataset.feedbackReady='true';retry.addEventListener('click',()=>{hotkeyNotes.clear();renderHotkeyStatus();});}
  if(hotkeyDraft){$('#setting-selection-key').value=hotkeyDraft.selectionHotkey;$('#setting-capture-key').value=hotkeyDraft.captureHotkey;}
  let ready=0;
  for(const name of ['selection','capture']){
    const detail=state.hotkeys[name+'Detail'] || {},ok=!!state.hotkeys[name],saved=state.settings[name==='selection'?'selectionHotkey':'captureHotkey'] || (name==='capture'?'Ctrl+Alt+S':'Alt+Q');
    if(ok)ready++;
    // A stored preference is not proof that Windows registered it. In a failed
    // replacement the native service reports the restored, actually usable key.
    if(!hotkeyPending && ok && detail.key && detail.key!==saved)hotkeyInput(name).value=detail.key;
    const note=hotkeyNotes.get(name);
    if(hotkeyPending && hotkeyDraft?.[name==='capture'?'captureHotkey':'selectionHotkey']!==saved)hotkeyFieldStatus(name,'正在保存并注册…','saving');
    else if(note)hotkeyFieldStatus(name,note.message,note.kind);
    else if(ok)hotkeyFieldStatus(name,detail.key && detail.key!==saved?`当前可用 ${detail.key}；已保存的 ${saved} 尚未启用`:'已注册 · '+(detail.key || saved),'ready');
    else hotkeyFieldStatus(name,detail.code?hotkeyRegistrationMessage(detail):'配置已保存；尚未注册，请在桌面客户端重新检测',detail.code?'registration-error':'unregistered');
  }
  $('#hotkey-status').textContent=ready===2?'两个快捷键均已就绪':'快捷键自动保存；实际可用状态见各输入框下方。';
}
let hotkeySaveQueue=Promise.resolve();
let hotkeyPending=0,hotkeyDraft=null;
const hotkeyNotes=new Map();
function hotkeyInput(name){return $(name==='capture'?'#setting-capture-key':'#setting-selection-key');}
function hotkeyFieldStatus(name,message,kind='ready'){
  const input=hotkeyInput(name),row=input?.closest?.('.hotkey-row');if(!row)return;
  let note=row.querySelector('.hotkey-field-note');
  if(!note){note=document.createElement('small');note.id='hotkey-'+name+'-feedback';note.className='hotkey-field-note';note.setAttribute('role','status');note.setAttribute('aria-live','polite');row.append(note);input.setAttribute('aria-describedby',note.id);}
  note.textContent=message;note.dataset.state=kind;
  input.setAttribute('aria-invalid',String(['invalid','duplicate','registration-error','error'].includes(kind)));
}
function hotkeyRegistrationMessage(detail){
  if(detail.code===1409)return 'Windows 未能注册此组合，可能已被占用；无法确定具体占用者。';
  if(detail.code===5)return 'Windows 拒绝全局快捷键访问；请在普通桌面会话中重新检测。';
  if(detail.code===87)return 'Windows 不接受此快捷键组合，请选择其他组合。';
  return 'Windows 全局快捷键注册未成功'+(detail.code?'（错误 '+detail.code+'）':'')+'，请重新检测。';
}
function hotkeyFeedback(name,message,kind){hotkeyNotes.set(name,{message,kind});hotkeyFieldStatus(name,message,kind);}
function hotkeyAutoStatus(status){if(typeof document!=='undefined')document.dispatchEvent(new CustomEvent('settings-auto-status',{detail:{section:'floating',state:status}}));}
function saveHotkeys(changedName=''){
  const values={selectionHotkey:$('#setting-selection-key').value,captureHotkey:$('#setting-capture-key').value};
  const names=['selection','capture'].filter(name=>!changedName || name===changedName);
  if(values.selectionHotkey===values.captureHotkey){for(const name of names)hotkeyFeedback(name,'应用内重复：划词和截图需要使用不同组合；原组合未改变。','duplicate');$('#setting-selection-key').value=state.settings.selectionHotkey || 'Alt+Q';$('#setting-capture-key').value=state.settings.captureHotkey || 'Ctrl+Alt+S';return Promise.resolve({ok:false,localValidation:true});}
  hotkeyPending++;hotkeyDraft=values;
  const sameInputs=()=>values.selectionHotkey===$('#setting-selection-key').value && values.captureHotkey===$('#setting-capture-key').value;
  for(const name of names){hotkeyNotes.delete(name);hotkeyFieldStatus(name,'正在保存并注册…','saving');}
  $('#hotkey-status').textContent='正在保存并注册快捷键…';
  const pending=hotkeySaveQueue.catch(()=>{}).then(async()=>{
    hotkeyAutoStatus('saving');
    try{
      const response=await api('settings',values);Object.assign(state.settings,values);
      if(response.hotkeys)state.hotkeys=response.hotkeys;
      $('#selection-shortcut').textContent=state.hotkeys.selection && state.hotkeys.selectionDetail?.key || values.selectionHotkey;$('#capture-shortcut').textContent=state.hotkeys.capture && state.hotkeys.captureDetail?.key || values.captureHotkey;
      const registrationFailed=response.binding && !response.binding.ok;
      if(sameInputs()){
        if(registrationFailed)for(const name of names){const detail=response.binding.bindings?.[name];if(detail && !detail.ok)hotkeyFeedback(name,hotkeyRegistrationMessage(detail)+' 当前可用组合以原绑定状态为准。','registration-error');}
        renderHotkeyStatus();
        if(registrationFailed)for(const name of names){const detail=state.hotkeys[name+'Detail'];if(state.hotkeys[name] && detail?.key)hotkeyInput(name).value=detail.key;}
      }
      hotkeyAutoStatus(registrationFailed?'error':'saved');
      return response;
    }catch(error){
      if(sameInputs()){
        $('#setting-selection-key').value=state.settings.selectionHotkey || 'Alt+Q';
        $('#setting-capture-key').value=state.settings.captureHotkey || 'Ctrl+Alt+S';
        const duplicate=/需要使用不同|重复/.test(error.message),invalid=/请使用|需要包含|影响常用|请选择其他快捷键/.test(error.message),registration=/Windows|注册|被占用/.test(error.message);
        const message=registration?'Windows 未能注册新组合，已保留原设置；请重新检测。无法确定具体占用者。':error.message;
        for(const name of names)hotkeyFeedback(name,(duplicate?'应用内重复：':invalid?'无效组合：':registration?'':'保存失败：')+message,duplicate?'duplicate':invalid?'invalid':registration?'registration-error':'error');
        $('#hotkey-status').textContent=message;
      }
      hotkeyAutoStatus('error');throw error;
    }
  }).finally(()=>{hotkeyPending--;if(!hotkeyPending)hotkeyDraft=null;});
  hotkeySaveQueue=pending;return pending;
}
async function confirm(title,text,ok='确认') {
  $('#confirm-title').textContent=title;$('#confirm-text').textContent=text;$('#confirm-ok').textContent=ok;
  const dialog=$('#confirm-dialog');dialog.showModal();
  return new Promise(resolve=>{
    const done=value=>{dialog.close();$('#confirm-ok').onclick=null;$('#confirm-cancel').onclick=null;dialog.oncancel=null;resolve(value);};
    $('#confirm-ok').onclick=()=>done(true);$('#confirm-cancel').onclick=()=>done(false);dialog.oncancel=e=>{e.preventDefault();done(false);};
  });
}
function download(name,data,type='text/plain;charset=utf-8') {
  const url=URL.createObjectURL(new Blob([data],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function exportVocabulary() {
  if(!state.vocabulary.length){toast('收藏一些单词后，就可以导出了');return;}
  const csvCell=value=>'"'+String(/^[=+\-@]/.test(String(value))?"'"+value:value).replace(/"/g,'""')+'"';
  const rows=[['单词或句子','中文释义','原文语境','收藏时间'],...state.vocabulary.map(w=>[w.word,w.translation,w.context,new Date(w.added*1000).toISOString()])];
  download('拾译生词本.csv','\ufeff'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n'),'text/csv;charset=utf-8');
}
function searchDocument() {
  const query=$('#doc-search-input').value.trim().toLowerCase();let count=0,first=null;
  $$('.reader-search-hit',immersiveReader.view.root).forEach(node=>node.classList.remove('reader-search-hit'));
  $$('#pdf-text .search-hit').forEach(node=>node.classList.remove('search-hit'));
  if((state.settings.readerMode || 'split')!=='pdf'){
    // Search the shared model, not the hidden legacy PDF/text DOM. Counting once
    // per language also avoids double-counting the same paragraph in split panes.
    const matches=new Set();
    if(query)for(const paragraph of immersiveReader.model.paragraphs){
      if(pdf && !paragraph.pageNumbers.includes(currentPage))continue;
      let occurrences=0;
      for(const text of [paragraph.text,paragraph.translation]){
        const value=String(text || '').toLowerCase();let offset=0,index=value.indexOf(query);
        while(index>=0){occurrences++;offset=index+query.length;index=value.indexOf(query,offset);}
      }
      if(occurrences){count+=occurrences;matches.add(paragraph.id);first ||= paragraph.id;}
    }
    if(first){
      immersiveReader.navigationIntent();immersiveReader.activeId=first;
      immersiveReader.view.ensureVisible(first);immersiveReader.view.restore({id:first,fraction:0});
    }
    for(const node of $$('[data-reader-id]',immersiveReader.view.root))node.classList.toggle('reader-search-hit',matches.has(node.dataset.readerId));
    $('#search-count').textContent=query?count+' 处（当前页）':'';return;
  }else if(pdf){
    $$('#pdf-text span').forEach(span=>{const hit=query && span.textContent.toLowerCase().includes(query);span.classList.toggle('search-hit',!!hit);if(hit){count++;first ||= span;}});
  }else{
    $$('mark.search-hit',$('#article')).forEach(m=>m.replaceWith(document.createTextNode(m.textContent)));
    $('#article').normalize();
    if(query){
      const walker=document.createTreeWalker($('#article'),NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
      for(const node of nodes){const text=node.textContent;let index=0,position=text.toLowerCase().indexOf(query);if(position<0)continue;const fragment=document.createDocumentFragment();while(position>=0){fragment.append(document.createTextNode(text.slice(index,position)));const mark=document.createElement('mark');mark.className='search-hit';mark.textContent=text.slice(position,position+query.length);fragment.append(mark);first ||= mark;count++;index=position+query.length;position=text.toLowerCase().indexOf(query,index);}fragment.append(document.createTextNode(text.slice(index)));node.replaceWith(fragment);}
    }
  }
  $('#search-count').textContent=query?count+' 处（当前页）':'';first?.scrollIntoView({block:'center',behavior:'smooth'});
}
const actions={
  home:()=>setView('home'),'quick-translate':()=>{setView('reader');immersiveReader.showLookup();$('#source-text').focus();},demo:showDemo,import:()=>$('#file-input').click(),settings:showSettings,
  theme:()=>preference({theme:state.settings.theme==='dark'?'light':'dark'}),
  capture:()=>api('action',{action:'capture'}),
  'show-popup':()=>api('action',{action:'show-popup'}),
  'ocr-page':recognizePage,
  'export-structure':()=>{if(!pdfDocumentStructure){toast('请等待本页解析完成');return;}download(currentDoc.name.replace(/\.pdf$/i,'')+'-阅读结构.json',JSON.stringify(pdfDocumentStructure,null,2),'application/json;charset=utf-8');},
  'reset-hotkeys':()=>{$('#setting-selection-key').value='Alt+Q';$('#setting-capture-key').value='Ctrl+Alt+S';return saveHotkeys();},
  'retry-hotkeys':async()=>{await api('action',{action:'retry-hotkeys'});toast('正在重新检测快捷键');setTimeout(()=>refresh().then(renderHotkeyStatus).catch(e=>toast(e.message,true)),1600);},
  clipboard:()=>api('action',{action:'clipboard'}),
  'open-folder':()=>api('action',{action:'open-folder'}),
  'paste-article':()=>$('#paste-dialog').showModal(),
  'close-paste':()=>$('#paste-dialog').close(),
  'save-article':async()=>{const d=await api('text-document',{name:$('#article-name').value,text:$('#article-paste').value});$('#paste-dialog').close();$('#article-name').value='';$('#article-paste').value='';await refresh();await openDocument(d.id);},
  'close-settings':()=>$('#settings-dialog').close(),
  'save-settings':async()=>{
    const dialog=$('#settings-dialog');if(dialog.dataset.saving==='true')return;
    const session=dialog.dataset.settingsSession;
    // Capture this click's ordinary draft. Independently auto-saved hotkeys must
    // never be overwritten by an older, delayed full-form submission.
    const values={autoTranslate:$('#setting-auto').checked,clipboardWatch:$('#setting-clipboard').checked,provider:$('#setting-provider').value,apiBase:$('#setting-api-base').value.trim(),apiKey:$('#setting-api-key').value.trim(),model:$('#setting-model').value.trim(),aiTimeoutSeconds:Number($('#setting-ai-timeout').value),aiBatchSize:Number($('#setting-ai-batch').value),aiFastMode:$('#setting-ai-fast').checked,popupNoActivate:$('#setting-noactivate').checked,popupPinned:$('#setting-pinned').checked,restoreClipboard:$('#setting-restore-clipboard').checked};
    dialog.dataset.saving='true';dialog.dispatchEvent(new Event('settings-saving'));
    try{await hotkeySaveQueue.catch(()=>{});const response=await preference(values);if(session===dialog.dataset.settingsSession){dialog.dispatchEvent(new Event('settings-saved'));dialog.close();}toast(response.binding && !response.binding.ok?'偏好已保存；当前环境无法注册全局快捷键，详情见设置。':'偏好已保存');}
    catch(error){if(session===dialog.dataset.settingsSession)dialog.dispatchEvent(new Event('settings-save-failed'));throw error;}
    finally{delete dialog.dataset.saving;dialog.dispatchEvent(new Event('settings-save-settled'));}
  },
  quit:async()=>{if(await confirm('结束这次阅读？','将关闭拾译后台和全局快捷键。下次双击启动即可继续。','退出')){await api('action',{action:'quit'});$('#settings-dialog').close();document.body.innerHTML='<div style="display:grid;place-content:center;height:100vh;text-align:center"><h1>下次阅读，再见。</h1><p style="margin-top:20px;color:#829087">拾译已退出，你可以关闭这个窗口。</p></div>'; }},
  translate,example:()=>setSource('breakthrough',demoParagraphs[0]),instant:()=>setTab(false),paragraphs:()=>immersiveReader.setMode('split'),'translate-paragraphs':translateParagraphs,
  'page-translate':translateParagraphs,
  'paragraph-sidebar':()=>{if(state.settings.readerMode==='pdf')setTab(true);else{immersiveReader.showLookup(false);return immersiveReader.setMode('split');}},
  'cancel-paragraphs':()=>paragraphClient.cancel(translationDocId()),
  'retry-paragraphs':()=>translateParagraphs(currentTranslationManifest().target_ids.filter(id=>['failed','cancelled'].includes(paragraphRecords.get(id)?.status))),
  'export-paragraphs':()=>{
    const manifest=currentTranslationManifest();const data={...manifest,translations:manifest.paragraphs.filter(p=>manifest.target_ids.includes(p.paragraph_id)).map(p=>{const result=paragraphRecords.get(p.paragraph_id);return result && matchesSource(result,p)?result:null;}).filter(Boolean)};
    const link=document.createElement('a');link.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));link.download=(currentDoc?.name || '拾译')+'-段落译文.json';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
  },
  glossary:async()=>{const result=await api('document-glossary?doc='+encodeURIComponent(translationDocId()));$('#glossary-input').value=result.terms.map(term=>term.source+' = '+term.target).join('\n');$('#glossary-dialog').dataset.doc=translationDocId();$('#glossary-dialog').showModal();},
  'close-glossary':()=>$('#glossary-dialog').close(),
  'save-glossary':async()=>{const terms=$('#glossary-input').value.split(/\n/).filter(line=>line.trim()).map(line=>{const index=line.indexOf('=');if(index<1)throw new Error('每行请使用 英文 = 中文 的格式');return {source:line.slice(0,index).trim(),target:line.slice(index+1).trim()};});await api('document-glossary',{document_id:$('#glossary-dialog').dataset.doc,terms});$('#glossary-dialog').close();toast('术语表已保存，下一批翻译将使用这些译法');},
  'retry-word-details':()=>ensureWordDetails(),
  'clear-source':()=>{++translateSerial;clearTimeout(debounceTimer);$('#source-text').value='';sourceChanged(false);lastResult=null;$('#translate-button').disabled=false;$('#translate-button span').textContent='翻译一下';$('#translation-result').className='translation-result empty';$('#translation-result').innerHTML='<h3>给下一句，留一点空间</h3><p>选中文字，继续阅读。</p>';},
  swap:async()=>{const a=$('#source-lang').value,b=$('#target-lang').value;await preference({source:b,target:a==='auto'?'en':a});if($('#source-text').value.trim())translate();},
  'copy-translation':async()=>{if(lastResult){await navigator.clipboard.writeText(lastResult.text);toast('译文已复制');}},
  'speak-source':()=>{if(lastResult)speak(lastResult.source,$('#source-lang').value==='zh-CN'?'zh-CN':$('#source-lang').value==='auto'?'en-US':$('#source-lang').value);},
  'save-word':saveWord,
  'font-up':()=>((state.settings.readerMode || 'split')==='pdf'?preference({fontSize:Math.min(28,(state.settings.fontSize || 19)+1)}):readerPreference({readerEnglishSize:Math.min(36,(state.settings.readerEnglishSize || 18)+1),readerChineseSize:Math.min(36,(state.settings.readerChineseSize || 18)+1)})),
  'font-down':()=>((state.settings.readerMode || 'split')==='pdf'?preference({fontSize:Math.max(14,(state.settings.fontSize || 19)-1)}):readerPreference({readerEnglishSize:Math.max(12,(state.settings.readerEnglishSize || 18)-1),readerChineseSize:Math.max(12,(state.settings.readerChineseSize || 18)-1)})),
  focus:()=>setFocus(!document.body.classList.contains('focus-mode')),
  'prev-page':async()=>{if(pdf && currentPage>1){immersiveReader.navigationIntent();++parallelSerial;resetParallel();currentPage--;await renderPdf();}},
  'next-page':async()=>{if(pdf && currentPage<pdf.numPages){immersiveReader.navigationIntent();++parallelSerial;resetParallel();currentPage++;await renderPdf();}},
  'zoom-in':async()=>{if(pdf){zoom=Math.min(3,(zoom || ($('#paper-scroll').clientWidth-35)/((await pdf.getPage(currentPage)).getViewport({scale:1}).width))*1.15);await renderPdf();}},
  'zoom-out':async()=>{if(pdf){zoom=Math.max(.3,(zoom || ($('#paper-scroll').clientWidth-35)/((await pdf.getPage(currentPage)).getViewport({scale:1}).width))/1.15);await renderPdf();}},
  'fit-pdf':()=>{zoom=0;return renderPdf();},
  'search-doc':()=>{$('#doc-search').classList.toggle('hidden');if(!$('#doc-search').classList.contains('hidden'))$('#doc-search-input').focus();},
  'close-search':()=>{$('#doc-search').classList.add('hidden');$('#doc-search-input').value='';searchDocument();},
  'export-vocab':exportVocabulary,
  'clear-history':async()=>{if(state.history.length && await confirm('清空翻译记录？','仅删除本机翻译记录，收藏的单词仍然保留。','清空记录')){await api('history/clear',{});await refresh();toast('记录已清空');}},
  menu:()=>$('#sidebar').classList.toggle('open')
};
document.addEventListener('click',async event=>{
  const button=event.target.closest('[data-action],button[data-view],[data-doc],[data-delete-doc],[data-delete-word],[data-speak],[data-history],[data-lookup],[data-jump-passage],[data-word-view],[data-retry-paragraph],[data-locate-page]');if(!button)return;
  if(button.tagName==='A')event.preventDefault();
  try{
    if(button.dataset.action)await actions[button.dataset.action]?.();
    else if(button.dataset.retryParagraph)await translateParagraphs([button.dataset.retryParagraph],true);
    else if(button.dataset.locatePage)await locateTranslatedParagraph(button.closest('[data-paragraph-id]').dataset.paragraphId,Number(button.dataset.locatePage));
    else if(button.dataset.view)setView(button.dataset.view);
    else if(button.dataset.doc)await openDocument(button.dataset.doc);
    else if(button.dataset.deleteDoc){
      const doc=state.documents.find(d=>d.id===button.dataset.deleteDoc);
      if(await confirm('从本地书库移除？','删除「'+doc.name+'」的书库副本。你原来的文件不受影响。','移除')){await api('document/delete',{id:doc.id});if(currentDoc?.id===doc.id)showDemo();await refresh();}
    }
    else if(button.dataset.deleteWord){await api('vocabulary/delete',{id:button.dataset.deleteWord});await refresh();toast('已移除收藏');}
    else if(button.dataset.speak)speak(button.dataset.speak,button.dataset.speakLang || 'en-US');
    else if(button.dataset.lookup)setSource(button.dataset.lookup);
    else if(button.dataset.jumpPassage)jumpToPassage(button.dataset.jumpPassage);
    else if(button.dataset.wordView){const w=await api('vocabulary/'+encodeURIComponent(button.dataset.wordView));let detail={};try{detail=JSON.parse(w.detail || '{}');}catch{}setView('reader');setTab(false);currentContext=w.context;$('#source-text').value=w.word;sourceChanged(false);lastResult={isWord:/^[a-zA-Z'-]{1,70}$/.test(w.word),...detail,source:w.word,text:w.translation,engine:detail.engine || '本地生词本'};renderTranslation(lastResult);}
    else if(button.dataset.history){const h=state.history.find(h=>String(h.id)===button.dataset.history);setView('reader');$('#source-text').value=h.source;sourceChanged(false);setTab(false);lastResult={source:h.source,text:h.translation,engine:h.engine,cached:true};renderTranslation(lastResult);}
  }catch(e){toast(e.message,true);}
});
function prepareHomeInput(text){
  selectionOwned=false;selectionDragging=false;selectionPending=false;currentContext='';currentSelectionHint='';lastSelectionKey='';hideSelectionTools();
  $('#source-text').value=text;sourceChanged(false);
}
$('#home-source-text')?.addEventListener('input',()=>prepareHomeInput($('#home-source-text').value));
document.addEventListener('home-translate',event=>{
  const text=String(event.detail || '');if(!text.trim())return;
  if($('#source-text').value!==text || currentContext)prepareHomeInput(text);
  translate();
});
$('#source-text').addEventListener('input',()=>{selectionOwned=false;lastSelectionKey='';currentContext='';currentSelectionHint='';hideSelectionTools();++translateSerial;$('#translate-button').disabled=false;$('#translate-button span').textContent='翻译一下';sourceChanged();});
$('#source-lang').addEventListener('change',()=>preference({source:$('#source-lang').value}));
$('#target-lang').addEventListener('change',()=>preference({target:$('#target-lang').value}));
$('#file-input').addEventListener('change',e=>importFiles(e.target.files).catch(e=>toast(e.message,true)));
$('#setting-provider').addEventListener('change',()=>$('#custom-api').classList.toggle('hidden',$('#setting-provider').value!=='custom'));
for(const id of ['setting-selection-key','setting-capture-key']){
  const input=$('#'+id);input.addEventListener('focus',()=>{input.classList.add('capturing');input.title='现在按下新的快捷键，例如 Ctrl+Alt+Q';});input.addEventListener('blur',()=>input.classList.remove('capturing'));
  input.addEventListener('keydown',e=>{
    if(e.key==='Tab' || e.repeat)return;
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();input.blur();return;}
    e.preventDefault();e.stopPropagation();let key='';
    if(/^Key[A-Z]$/.test(e.code))key=e.code.slice(3);else if(/^Digit\d$/.test(e.code))key=e.code.slice(5);else if(/^F(?:[1-9]|1[0-2])$/.test(e.code))key=e.code;
    const name=id==='setting-capture-key'?'capture':'selection';
    if(!key){if(!['Control','Alt','Shift','Meta'].includes(e.key))hotkeyFeedback(name,'无效组合：请使用 Ctrl 或 Alt 加字母、数字或 F1–F12。','invalid');return;}
    if(!e.ctrlKey && !e.altKey){hotkeyFeedback(name,'无效组合：请同时按住 Ctrl 或 Alt，原组合未改变。','invalid');return;}
    const candidate=[e.ctrlKey?'Ctrl':'',e.altKey?'Alt':'',e.shiftKey?'Shift':'',key].filter(Boolean).join('+');
    if(candidate===hotkeyInput(name==='capture'?'selection':'capture').value){hotkeyFeedback(name,'应用内重复：划词和截图需要使用不同组合；原组合未改变。','duplicate');return;}
    input.value=candidate;saveHotkeys(name).catch(()=>{});
  });
}
$('#sync-scroll').addEventListener('change',()=>preference({syncScroll:$('#sync-scroll').checked}).catch(e=>toast(e.message,true)));
$('#column-mode').addEventListener('change',()=>{++parallelSerial;resetParallel();rebuildLayout();prefetchPdfNeighbors(pdf,currentPage,docSerial).catch(()=>{});toast('阅读顺序已调整，可以重新生成对照');});
$('#paper-scroll').addEventListener('scroll',()=>{if(!sourceFrame)sourceFrame=requestAnimationFrame(()=>{sourceFrame=0;syncFromSource();});});
$('#translation-scroll').addEventListener('scroll',()=>{if(!translationFrame)translationFrame=requestAnimationFrame(()=>{translationFrame=0;syncFromTranslation();});});
function isScrollbarPointer(event,container){
  if(event.type!=='pointerdown' || event.target!==container || container.scrollHeight<=container.clientHeight)return false;
  const rect=container.getBoundingClientRect();
  return event.clientX>=rect.left+container.clientLeft+container.clientWidth && event.clientX<rect.right;
}
for(const [selector,source] of [['#paper-scroll',true],['#translation-scroll',false]]){
  const container=$(selector);
  for(const name of ['wheel','touchmove','pointerdown','keydown'])container.addEventListener(name,event=>{
    if(name==='pointerdown' && !isScrollbarPointer(event,container))return;
    if(name==='keydown' && (event.target.closest('input,textarea,select') || !['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(event.key)))return;
    if(source){sourceIntentUntil=performance.now()+1400;translationIntentUntil=0;ignoreSourceScroll=0;}
    else{translationIntentUntil=performance.now()+1400;sourceIntentUntil=0;ignoreTranslationScroll=0;}
  },{passive:true});
}
$('#paper-scroll').addEventListener('click',event=>{const target=event.target.closest('[data-passage]');if(target && !window.getSelection()?.toString().trim())jumpToPassage(target.dataset.passage,'source');});
['library-search','vocab-search','history-search'].forEach(id=>$('#'+id).addEventListener('input',renderCollections));
function goToInputPage(){
  if(!pdf)return;const desired=Math.max(1,Math.min(pdf.numPages,Number($('#page-input').value) || 1));
  if(desired===currentPage)return;
  immersiveReader.navigationIntent();++parallelSerial;resetParallel();currentPage=desired;renderPdf();
}
$('#page-input').addEventListener('change',goToInputPage);
$('#page-input').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();goToInputPage();}});
$('#doc-search-input').addEventListener('keydown',e=>{if(e.key==='Enter')searchDocument();});
function hideSelectionTools(){
  immersiveReader.selection=null;$('#reader-selection-menu').classList.add('hidden');
  immersiveReader.view.closeContext();
}
function commitReaderSelection(){
  selectionPending=false;
  const selected=immersiveReader.handleSelection();
  $('#pdf-highlights').classList.toggle('hidden',!!selected);
  if(!selected){selectionOwned=false;lastSelectionKey='';restoreCompletedInstant();return;}
  const key=JSON.stringify([docSerial,currentPage,selected.text,selected.id]);
  selectionOwned=true;if(key===lastSelectionKey){restoreCompletedInstant();return;}lastSelectionKey=key;
  const paragraph=immersiveReader.paragraph(selected.id);
  currentSelectionHint=selectionHint(window.getSelection(),selected.text);
  setSource(selected.text,paragraph?.text || '',{exact:true});restoreCompletedInstant();
}
document.addEventListener('pointerdown',event=>{
  if(event.button!==0 || event.target.closest('button,summary,dialog,input,select,textarea') || !event.target.closest('#reader-surface,#paper-scroll'))return;
  if(isScrollbarPointer(event,$('#paper-scroll')))return;
  sourceIntentUntil=0;translationIntentUntil=0;
  clearingReaderSelection=!!readReaderSelection(window.getSelection());
  immersiveReader.navigationIntent();
  pdfSelectionGesture.start(event);selectionDragging=true;selectionPending=true;clearTimeout(selectionTimer);
  hideSelectionTools();$('#pdf-highlights').classList.add('hidden');
});
document.addEventListener('selectionchange',()=>{
  // Transient selection changes never change the translation pane's mode/content.
  if(document.activeElement?.closest('textarea,input,dialog,#reader-selection-menu,.reader-context-menu'))return;
  if(!readReaderSelection(window.getSelection()) && !selectionOwned)return;
  selectionPending=true;hideSelectionTools();
  clearTimeout(selectionTimer);
  if(!selectionDragging)selectionTimer=setTimeout(commitReaderSelection,100);
});
// A click used to dismiss a selection is not a paragraph-navigation command.
document.addEventListener('click',event=>{
  if(clearingReaderSelection && !event.target.closest('button,a,input,textarea,select,summary,dialog') &&
      event.target.closest('#reader-surface,#paper-scroll') && !readReaderSelection(window.getSelection()))event.stopPropagation();
  clearingReaderSelection=false;
},true);
document.addEventListener('pointermove',event=>pdfSelectionGesture.move(event));
document.addEventListener('pointerup',event=>{pdfSelectionGesture.end(event);if(selectionDragging){selectionDragging=false;clearTimeout(selectionTimer);selectionTimer=setTimeout(commitReaderSelection,0);}});
document.addEventListener('pointercancel',()=>{pdfSelectionGesture.cancel();selectionDragging=false;selectionPending=false;clearingReaderSelection=false;clearTimeout(selectionTimer);hideSelectionTools();restoreCompletedInstant();});
$('#pdf-text').addEventListener('dblclick',event=>{
  selectPdfWord(event,$('#pdf-text'));clearTimeout(selectionTimer);selectionTimer=setTimeout(commitReaderSelection,0);
});
// Toolbar buttons must not collapse the selection before their click handler.
$('#reader-selection-menu').addEventListener('pointerdown',event=>event.preventDefault());

document.addEventListener('keydown',e=>{
  if(e.defaultPrevented || e.target.classList.contains('hotkey-input') || e.target.closest('[role=separator],dialog'))return;
  const passage=e.target.closest('[data-jump-passage]');if(passage && e.target===passage && (e.key==='Enter' || e.key===' ')){e.preventDefault();jumpToPassage(passage.dataset.jumpPassage);return;}
  if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='o'){e.preventDefault();$('#file-input').click();}
  if((e.ctrlKey||e.metaKey) && e.key==='Enter'){e.preventDefault();translate();}
  if(e.key==='Escape'){setFocus(false);$('#sidebar').classList.remove('open');}
  if(!e.target.closest('textarea,input,select') && pdf && $('#reader-view').classList.contains('active')){
    if(e.key==='ArrowRight'){e.preventDefault();actions['next-page']();}
    if(e.key==='ArrowLeft'){e.preventDefault();actions['prev-page']();}
  }
});
let dragCount=0;
document.addEventListener('dragenter',e=>{if([...e.dataTransfer.types].includes('Files')){e.preventDefault();dragCount++;$('#drag-overlay').classList.remove('hidden');}});
document.addEventListener('dragover',e=>{if([...e.dataTransfer.types].includes('Files'))e.preventDefault();});
document.addEventListener('dragleave',e=>{if(--dragCount<=0){dragCount=0;$('#drag-overlay').classList.add('hidden');}});
document.addEventListener('drop',e=>{e.preventDefault();dragCount=0;$('#drag-overlay').classList.add('hidden');if(e.dataTransfer.files.length)importFiles(e.dataTransfer.files).catch(e=>toast(e.message,true));});
let resizeTimer;
function fitVisiblePdf(){
  clearTimeout(resizeTimer);
  if(document.body.classList.contains('companion-resizing'))return;
  if(!pdf || zoom || state.settings.readerMode!=='pdf' || document.body.dataset.currentView!=='reader')return;
  const available=Math.max(240,$('#paper-scroll').clientWidth-35);
  if(pdfSurface?.current && Math.abs(pdfSurface.current.viewport.width-available)<1)return;
  resizeTimer=setTimeout(()=>{if(pdf && !zoom && state.settings.readerMode==='pdf' && document.body.dataset.currentView==='reader')renderPdf();},150);
}
document.addEventListener('companion-resize-start',()=>clearTimeout(resizeTimer));
document.addEventListener('companion-resize-end',fitVisiblePdf);
window.addEventListener('resize',fitVisiblePdf);
if(typeof ResizeObserver!=='undefined')new ResizeObserver(fitVisiblePdf).observe($('#paper-scroll'));
async function pollEvents() {
  try{
    const events=await api('events?since='+lastEvent);
    for(const e of events){lastEvent=Math.max(lastEvent,e.id);if(e.kind==='translation'){if(document.body.dataset.currentView==='home' || instantRequest.pending || (selectionOwned && readReaderSelection(window.getSelection())))continue;$('#source-text').value=e.source;sourceChanged(false);currentContext='';lastResult=e;setTab(false);renderTranslation(e);refresh().catch(()=>{});}else if(e.kind==='hotkeys'){state.hotkeys=e.status;if($('#settings-dialog').open)renderHotkeyStatus();}else if(e.kind==='vocabulary'){refresh().catch(()=>{});}}
  }catch(e){/* A closed background host should not create repeated dialogs. */}
  setTimeout(pollEvents,1500);
}
async function reportCandidateReady(){
  const nonce=$('meta[name="shiyi-update-nonce"]')?.content;
  if(!nonce)return;
  if(document.readyState!=='complete')await new Promise(resolve=>window.addEventListener('load',resolve,{once:true}));
  // Edge can throttle animation frames for a window behind another app.
  // The host separately checks its native visibility and process ownership.
  const deadline=performance.now()+18000;
  while(performance.now()<deadline){
    const view=document.body.dataset.currentView;
    const section=(view==='home' || view==='reader') && $('#'+view+'-view.active');
    const waitingForPdf=view==='reader' && currentDoc?.kind==='pdf' &&
      (!pdf || lastPageKey!==currentDoc.id+':'+currentPage ||
       (state.settings.readerMode==='pdf' && !pdfSurface?.current?.complete));
    if(section && section.getClientRects().length && !waitingForPdf){
      try{await api('update-ready',{nonce,view});return;}catch{}
    }
    await new Promise(resolve=>setTimeout(resolve,120));
  }
}
async function init(){
  try{await refresh();applyPreferences();showDemo();if(state.settings.lastDoc && state.documents.some(d=>d.id===state.settings.lastDoc))await openDocument(state.settings.lastDoc);else setView('home');pollEvents();reportCandidateReady().catch(()=>{});}
  catch(e){toast('连接本地程序失败，请重新双击启动拾译。'+e.message,true);}
}
setupAppearance({get:()=>state.settings,save:async value=>{const response=await api('settings',value);Object.assign(state.settings,value);return response;}});
init();

// Menus do not retain stale state when keyboard users move back into reading.
document.addEventListener('keydown',event=>{if(event.key==='Escape'){const menu=$('#reader-more');if(menu.open){menu.open=false;menu.querySelector('summary').focus();}$('#sidebar').classList.remove('open');}});
document.addEventListener('pointerdown',event=>{if(!event.target.closest('#reader-more'))$('#reader-more').open=false;});
