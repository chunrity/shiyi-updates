/** Immersive reading presentation. Consumes parsed paragraphs and translations only. */
import {captureAnchor,anchorScrollTop} from './reader-model.js';

const escape=value=>String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusLabels={not_started:'尚未翻译',queued:'等待翻译',running:'正在翻译',retrying:'正在重试',succeeded:'已翻译',failed:'翻译失败',cancelled:'已取消'};
const $=(selector,root)=>root.querySelector(selector);
const $$=(selector,root)=>[...root.querySelectorAll(selector)];

export class BilingualReader{
  constructor(root,hooks={}){
    this.root=root;this.hooks=hooks;this.model={paragraphs:[],blocks:[]};this.settings={};this.mode='split';
    this.documentId='';this.activeId='';this.windowStart=0;this.windowSize=60;this.collapsed=new Set();
    this.intent={};this.silent={};this.frames={};this.figureGate=0;
    this.metricCache={};this.geometryEpoch=0;
    this.root.innerHTML=`<section class="reader-pane reader-source" data-pane="source" tabindex="0" aria-label="英文原文"><div class="reader-pane-label"><span>ENGLISH</span><span>原文</span></div><div class="reader-flow"></div></section><div class="reader-divider" role="separator" aria-label="调整中英文栏宽" aria-orientation="vertical" aria-valuemin="30" aria-valuemax="70" aria-valuenow="50" tabindex="0"></div><section class="reader-pane reader-target" data-pane="translation" tabindex="0" aria-label="中文译文"><div class="reader-pane-label"><span>TRANSLATION</span><span>译文</span></div><div class="reader-flow"></div></section><section class="reader-pane reader-combined" data-pane="combined" tabindex="0" aria-label="逐段阅读"><div class="reader-flow"></div></section>`;
    this.panes={source:$('.reader-source',root),translation:$('.reader-target',root),combined:$('.reader-combined',root)};
    for(const [name,pane] of Object.entries(this.panes)){
      const user=()=>{this.intent[name]=performance.now()+1200;this.silent[name]=0;};
      for(const type of ['wheel','touchstart','pointerdown','keydown'])pane.addEventListener(type,user,{passive:true});
      pane.addEventListener('scroll',()=>{
        if(this.frames[name])return;
        this.frames[name]=requestAnimationFrame(()=>{this.frames[name]=0;this.onScroll(name);});
      },{passive:true});
    }
    this.root.addEventListener('click',event=>this.onClick(event));
    this.root.addEventListener('keydown',event=>{
      const article=event.target.closest('[data-reader-id]');
      if(article && event.target===article && ['Enter',' '].includes(event.key)){
        event.preventDefault();this.select(article.dataset.readerId,{from:article.closest('[data-pane]').dataset.pane});
      }
    });
    this.contextMenu=document.createElement('div');this.contextMenu.className='reader-context-menu hidden';this.contextMenu.setAttribute('role','toolbar');this.contextMenu.setAttribute('aria-label','段落操作');this.root.append(this.contextMenu);
    document.addEventListener('pointerdown',event=>{if(!event.target.closest('.reader-context-menu,[data-reader-more]'))this.closeContext();});
    this.root.addEventListener('keydown',event=>{if(event.key==='Escape')this.closeContext(true);});
    this.installDivider();
    if(typeof ResizeObserver!=='undefined'){
      this.resizeObserver=new ResizeObserver(()=>this.invalidateGeometry());
      for(const pane of Object.values(this.panes)){this.resizeObserver.observe(pane);this.resizeObserver.observe($('.reader-flow',pane));}
    }
    this.root.addEventListener('toggle',()=>this.invalidateGeometry(),true);
    document.fonts?.addEventListener('loadingdone',()=>this.invalidateGeometry());
  }
  setData(model,settings,{pageNumber=1,totalPages=1,documentId=model.documentId,job=null,reset=false,originalPdf=true}={}){
    const settingsKey=JSON.stringify(['readerMode','readerShowTranslation','readerFont','readerEnglishSize','readerChineseSize','readerLineHeight','readerWidth','readerSplit','syncScroll','readerAutoLocate'].map(key=>settings[key]));
    if(!reset && this.model===model && this.settingsKey===settingsKey && this.pageNumber===pageNumber && this.documentId===documentId){this.job=job;return;}
    this.settingsKey=settingsKey;
    const oldAnchors=this.anchors(),changedDoc=this.documentId!==documentId;
    if(changedDoc){this.windowStart=0;this.activeId='';this.collapsed.clear();++this.figureGate;}
    const structureKey=value=>JSON.stringify(value.blocks.map(b=>[b.id,b.kind,b.pageNumber,b.rect,b.bbox,b.paragraph?.text]));
    const sameStructure=this.pageNumber===pageNumber && (this.model===model || structureKey(this.model)===structureKey(model));
    const mode=settings.readerMode || 'split',modeChanged=this.mode!==mode;
    this.model=model;this.settings=settings;this.documentId=documentId;this.pageNumber=pageNumber;this.totalPages=totalPages;this.job=job;
    this.originalPdf=originalPdf;this.mode=mode;this.applySettings();this.invalidateGeometry();
    if(changedDoc || reset || !sameStructure || modeChanged){
      if(!sameStructure)this.windowStart=0;
      this.render();
      if(!changedDoc && !reset){const anchor=oldAnchors[this.visiblePane()] || Object.values(oldAnchors).find(Boolean);if(anchor)this.restore(anchor);}
    }else this.patchTranslations();
    this.root.dataset.paragraphCount=String(model.paragraphs.length);
    this.root.dataset.renderedParagraphs=String($$('[data-reader-id]',this.root).length);
  }
  applySettings(){
    this.root.dataset.mode=this.mode;
    this.root.dataset.material=String(!!this.model.materialMode);
    this.root.classList.toggle('hide-translations',this.settings.readerShowTranslation===false);
    this.root.classList.toggle('reader-sans',this.settings.readerFont==='sans');
    const values={'--reader-en-size':(this.settings.readerEnglishSize || 18)+'px','--reader-zh-size':(this.settings.readerChineseSize || 18)+'px',
      '--reader-leading':this.settings.readerLineHeight || 1.9,'--reader-width':(this.settings.readerWidth || 760)+'px','--reader-split':(this.settings.readerSplit || 50)+'%'};
    for(const [key,value] of Object.entries(values))this.root.style.setProperty(key,value);
    $('.reader-divider',this.root).setAttribute('aria-valuenow',String(this.settings.readerSplit || 50));
    this.invalidateGeometry();
  }
  visiblePane(){return this.mode==='split'?'source':'combined';}
  invalidateGeometry(){this.geometryEpoch++;this.metricCache={};}
  metrics(name){
    if(this.metricCache[name])return this.metricCache[name];
    const pane=this.panes[name],origin=pane.getBoundingClientRect().top;
    return this.metricCache[name]=$$('[data-reader-id]',pane).map(node=>{const rect=node.getBoundingClientRect();return {id:node.dataset.readerId,top:rect.top-origin+pane.scrollTop,height:Math.max(1,rect.height)};});
  }
  anchors(){return Object.fromEntries(Object.entries(this.panes).map(([name,pane])=>[name,pane.clientHeight?captureAnchor(this.metrics(name),pane.scrollTop,pane.clientHeight,48):null]));}
  restore(anchor,paneName=null){
    if(!anchor)return;
    this.ensureVisible(anchor.id);
    const names=paneName?[paneName]:(this.mode==='split'?['source','translation']:['combined']);
    for(const name of names){const pane=this.panes[name],top=anchorScrollTop(anchor,this.metrics(name),Math.max(0,pane.scrollHeight-pane.clientHeight),48);if(top!==null){this.silent[name]=performance.now()+400;this.intent[name]=0;pane.scrollTo({top,behavior:'instant'});}}
    this.highlight(anchor.id);
  }
  onScroll(name){
    if(performance.now()<(this.silent[name] || 0) || performance.now()>(this.intent[name] || 0))return;
    this.closeContext();
    if(!this.panes[name].clientHeight)return;
    const anchor=captureAnchor(this.metrics(name),this.panes[name].scrollTop,this.panes[name].clientHeight,48);
    if(!anchor)return;
    this.highlight(anchor.id);
    this.hooks.progress?.({...anchor,pane:name});
    if(this.mode!=='split' || this.settings.syncScroll===false)return;
    const target=name==='source'?'translation':'source',pane=this.panes[target];
    const top=anchorScrollTop(anchor,this.metrics(target),Math.max(0,pane.scrollHeight-pane.clientHeight),48);
    if(top!==null){this.silent[target]=performance.now()+450;this.intent[target]=0;pane.scrollTo({top,behavior:'instant'});}
  }
  render(){
    this.closeContext();this.invalidateGeometry();
    const all=this.model.blocks;
    this.windowStart=Math.min(this.windowStart,Math.max(0,all.length-this.windowSize));
    const blocks=all.length>80?all.slice(this.windowStart,this.windowStart+this.windowSize):all;
    const notice=all.length>80?`<div class="reader-window-nav"><button data-reader-window="prev" ${this.windowStart===0?'disabled':''}>上一组</button><span>本页内容 ${this.windowStart+1}–${this.windowStart+blocks.length} / ${all.length}</span><button data-reader-window="next" ${this.windowStart+blocks.length>=all.length?'disabled':''}>下一组</button></div>`:'';
    const pageHeader=`<div class="reader-page-heading"><span>${this.originalPdf?'第 '+this.pageNumber+' / '+this.totalPages+' 页':'本地文章'}</span><button data-reader-original="${this.pageNumber}">查看${this.originalPdf?'原始 PDF':'原文'} ↗</button></div>`;
    for(const name of Object.keys(this.panes)){
      const flow=$('.reader-flow',this.panes[name]);
      if(this.mode==='pdf' || (this.model.materialMode?name!=='combined':this.mode==='split'?name==='combined':name!=='combined')){flow.replaceChildren();continue;}
      flow.innerHTML=pageHeader+notice+blocks.map(block=>['image','original'].includes(block.kind)?this.imageHTML(block,name):this.paragraphHTML(block.paragraph || block,name)).join('')+
        (this.originalPdf && !this.model.materialMode?`<details class="reader-original-elements"><summary>${this.model.annotated?'查看原页注释、自带译文与图表':'查看本页图表与原始版式'}</summary><p>${this.model.annotated?'正文与词汇、脚注、学习材料已分区。原页自带中文没有冒充 AI 译文，也未猜测一一对应关系。':'复杂表格、图形与公式以原始页面为准。'}下方直接渲染 PDF。</p><div class="reader-page-preview" data-preview-page="${this.pageNumber}"></div><button data-reader-original="${this.pageNumber}">在 PDF 中查看 ↗</button></details>`:'')+notice;
      flow.querySelector('.reader-original-elements')?.addEventListener('toggle',event=>{if(event.target.open)this.loadPagePreview(event.target);});
    }
    this.observeImages();
    if(this.activeId)this.highlight(this.activeId);
    if(!blocks.length)for(const pane of Object.values(this.panes))$('.reader-flow',pane).innerHTML=`<div class="reader-empty"><h3>原始文献随时可读</h3><p>本页没有可重组的文字。扫描页可先使用「识别本页文字」。</p><button data-reader-original="${this.pageNumber}">查看原始 PDF</button></div>`;
  }
  paragraphHTML(p,pane){
    if(!p?.id)return '';
    const heading=p.kind==='title'?'h2':p.kind==='heading'?'h3':p.kind==='subtitle'?'h4':'p';
    const source=`<${heading} class="reader-source-text" data-reader-language="source" lang="en">${escape(p.text)}</${heading}>`;
    const target=this.translationHTML(p,heading);
    const meta=`<button class="reader-paragraph-more" data-reader-more="${escape(p.id)}" title="段落操作" aria-label="段落操作" aria-expanded="false">···</button>`;
    let content=pane==='source'?source:pane==='translation'?target:this.mode==='chinese'?target:
      source+`<button class="reader-fold" data-reader-fold="${escape(p.id)}" aria-expanded="${!this.collapsed.has(p.id)}">${this.collapsed.has(p.id)?'展开中文':'收起中文'}</button><div class="reader-fold-content" ${this.collapsed.has(p.id)?'hidden':''}>${target}</div>`;
    if(pane==='combined' && this.mode==='chinese')content+=`<details class="reader-source-peek"><summary>查看英文原文</summary>${source}</details>`;
    return `<article class="reader-paragraph reader-kind-${escape(p.kind)}" data-reader-id="${escape(p.id)}" data-status="${escape(p.status)}" tabindex="0" aria-label="${pane==='source'?'英文':'中文'}段落${p.pageNumbers?.length>1?'，跨页':''}">${content}${meta}</article>`;
  }
  translationHTML(p,tag='p'){
    if(p.kind==='formula')return `<div class="reader-translated" data-reader-language="translation"><pre class="reader-formula">${escape(p.text)}</pre><span class="reader-status">原始公式</span></div>`;
    const warning=p.warnings?.filter(item=>item.severity!=='info') || [];
    const state=p.needsReview?'待核对':statusLabels[p.status] || '尚未翻译';
    const text=p.translation?`<${tag} lang="zh-CN" class="reader-target-text">${escape(p.translation)}</${tag}>`:`<p class="reader-pending">${escape(state)}${p.translationResult?.error?' · '+escape(p.translationResult.error):''}</p>`;
    return `<div class="reader-translated" data-reader-language="translation">${text}<div class="reader-status-row">${p.translation?`<span class="reader-status ${warning.length?'reader-review':''}">${escape(state)}</span><span class="reader-status">${escape(p.translationResult?.engine || '来源未记录')}${p.translationResult?.cached?' · 缓存（原始来源）':''}</span>`:''}${p.status==='running' || p.status==='queued' || p.status==='retrying'?'<span class="reader-busy" aria-label="正在处理"></span>':['failed','cancelled'].includes(p.status)?`<button data-reader-retry="${escape(p.id)}">重试此段</button>`:''}</div>${warning.length?`<details class="reader-quality"><summary>译文检查提示</summary>${warning.map(w=>`<p>${escape(w.message)}</p>`).join('')}</details>`:''}</div>`;
  }
  patchTranslations(){
    const byId=new Map(this.model.paragraphs.map(p=>[p.id,p]));
    let changed=false;for(const node of $$('[data-reader-id]',this.root)){
      const p=byId.get(node.dataset.readerId);if(!p)continue;
      const signature=JSON.stringify([p.status,p.translation,p.warnings,p.needsReview,p.translationResult?.error]);
      if(node._translationSignature===signature)continue;
      node._translationSignature=signature;node.dataset.status=p.status;
      changed=true;
      for(const translated of $$('.reader-translated',node)){
        const template=document.createElement('template');template.innerHTML=this.translationHTML(p,p.kind==='title'?'h2':p.kind==='heading'?'h3':p.kind==='subtitle'?'h4':'p');
        translated.replaceWith(template.content.firstElementChild);
      }
      for(const button of $$('[data-reader-copy="translation"],[data-reader-copy="bilingual"]',node))button.disabled=!p.translation;
    }
    if(changed)this.invalidateGeometry();
  }
  imageHTML(block,pane){
    return `<figure class="reader-figure" data-reader-image="${escape(block.id)}" data-pane-image="${pane}"><div class="reader-image-slot"><span>${escape(block.label || '原始 PDF 图片')} · 第 ${block.pageNumber} 页</span></div><figcaption><button data-reader-original="${block.pageNumber}">${block.fullPage?'学习材料保持原始版式 · 查看原页':'查看图片所在原页'} ↗</button></figcaption></figure>`;
  }
  observeImages(){
    this.imageObserver?.disconnect();
    this.imageObserver=new IntersectionObserver(entries=>{
      for(const entry of entries)if(entry.isIntersecting){this.imageObserver.unobserve(entry.target);this.loadImage(entry.target);}
    },{rootMargin:'160px'});
    for(const image of $$('[data-reader-image]',this.root))this.imageObserver.observe(image);
  }
  async loadImage(node){
    const block=this.model.blocks.find(block=>block.id===node.dataset.readerImage);if(!block)return;
    const generation=this.figureGate;
    try{const image=await this.hooks.figure?.(block);if(generation!==this.figureGate || !node.isConnected || !image)return;
      const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;canvas.getContext('2d').drawImage(image,0,0);canvas.setAttribute('role','img');canvas.setAttribute('aria-label','PDF 原始图片，第 '+block.pageNumber+' 页');
      $('.reader-image-slot',node).replaceChildren(canvas);
      this.invalidateGeometry();
    }catch{if(node.isConnected)$('.reader-image-slot',node).textContent='图片暂时无法预览，可点击查看原页';}
  }
  async loadPagePreview(details){
    const slot=$('.reader-page-preview',details);if(!slot || slot.childElementCount || slot.dataset.loading)return;
    slot.dataset.loading='true';slot.textContent='正在渲染原始页面…';const generation=this.figureGate;
    try{const image=await this.hooks.figure?.({pageNumber:Number(slot.dataset.previewPage),fullPage:true});
      if(!image || generation!==this.figureGate || !slot.isConnected)return;
      const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;canvas.getContext('2d').drawImage(image,0,0);canvas.setAttribute('role','img');canvas.setAttribute('aria-label','本页原始 PDF 图表与版式');slot.replaceChildren(canvas);this.invalidateGeometry();
    }catch{slot.textContent='预览暂时不可用，请使用「在 PDF 中查看」。';}
    finally{delete slot.dataset.loading;}
  }
  ensureVisible(id){
    const index=this.model.blocks.findIndex(block=>(block.paragraph?.id || block.id)===id);
    if(index>=0 && this.model.blocks.length>80 && (index<this.windowStart || index>=this.windowStart+this.windowSize)){
      this.windowStart=Math.max(0,index-10);this.render();
    }
  }
  highlight(id){
    if(this.activeId===id && this.highlightedEpoch===this.geometryEpoch)return;
    this.activeId=id;
    this.highlightedEpoch=this.geometryEpoch;
    for(const node of $$('[data-reader-id]',this.root))node.classList.toggle('reader-active',node.dataset.readerId===id);
    clearTimeout(this.highlightTimer);this.root.classList.add('reader-locating');
    this.highlightTimer=setTimeout(()=>this.root.classList.remove('reader-locating'),1400);
  }
  select(id,{from='source',force=false,fraction=0}={}){
    this.ensureVisible(id);this.highlight(id);
    if(force || this.settings.readerAutoLocate!==false)this.restore({id,fraction},this.mode==='split'?(from==='source'?'translation':'source'):'combined');
    this.hooks.locate?.(id,{from,force,local:true});
    this.hooks.progress?.({id,fraction,pane:from});
  }
  closeContext(restoreFocus=false){
    if(!this.contextMenu || this.contextMenu.classList.contains('hidden'))return;
    this.contextMenu.classList.add('hidden');this.contextTrigger?.setAttribute('aria-expanded','false');
    if(restoreFocus && this.contextTrigger?.isConnected)this.contextTrigger.focus();
  }
  openContext(id,trigger){
    const p=this.model.paragraphs.find(p=>p.id===id);if(!p)return;
    document.querySelector('#reader-selection-menu')?.classList.add('hidden');
    this.closeContext();this.contextId=id;this.contextTrigger=trigger;
    this.contextMenu.innerHTML=(p.pageNumbers || []).map(page=>`<button data-reader-original="${page}" data-logical-id="${escape(id)}">定位第 ${page} 页原文 ↗</button>`).join('')+
      `<button data-reader-copy="source">复制英文</button><button data-reader-copy="translation" ${!p.translation?'disabled':''}>复制中文</button><button data-reader-copy="bilingual" ${!p.translation?'disabled':''}>复制中英对照</button><button data-reader-note="${escape(id)}">添加阅读笔记</button><button data-reader-retry="${escape(id)}" ${['running','queued','retrying'].includes(p.status)?'disabled':''}>${p.translation?'重新翻译':'翻译此段'}</button>`;
    this.contextMenu.classList.remove('hidden');trigger.setAttribute('aria-expanded','true');
    const rect=trigger.getBoundingClientRect(),menu=this.contextMenu;
    menu.style.left=Math.max(8,Math.min(rect.right-menu.offsetWidth,window.innerWidth-menu.offsetWidth-8))+'px';
    menu.style.top=Math.max(8,Math.min(rect.bottom+5,window.innerHeight-menu.offsetHeight-8))+'px';
    menu.querySelector('button')?.focus();
  }
  onClick(event){
    const button=event.target.closest('button');const article=event.target.closest('[data-reader-id]');
    if(button){
      if(button.dataset.readerMore){this.openContext(button.dataset.readerMore,button);return;}
      if(button.closest('.reader-context-menu'))this.closeContext();
      if(button.dataset.readerOriginal){this.hooks.original?.(button.dataset.logicalId || article?.dataset.readerId,Number(button.dataset.readerOriginal));return;}
      if(button.dataset.readerRetry){this.hooks.retry?.(button.dataset.readerRetry);return;}
      if(button.dataset.readerNote){this.hooks.note?.(button.dataset.readerNote);return;}
      if(button.dataset.readerCopy){this.hooks.copy?.(article?.dataset.readerId || this.contextId,button.dataset.readerCopy);return;}
      if(button.dataset.readerFold){const id=button.dataset.readerFold;this.collapsed.has(id)?this.collapsed.delete(id):this.collapsed.add(id);const anchor=this.anchors()[this.visiblePane()];this.render();this.restore(anchor);return;}
      if(button.dataset.readerWindow){this.windowStart=Math.max(0,this.windowStart+(button.dataset.readerWindow==='next'?this.windowSize:-this.windowSize));this.render();for(const pane of Object.values(this.panes))pane.scrollTop=0;return;}
    }
    if(event.target.closest('summary,details,button,a,input') || window.getSelection()?.toString().trim())return;
    if(article)this.select(article.dataset.readerId,{from:article.closest('[data-pane]').dataset.pane});
  }
  installDivider(){
    const divider=$('.reader-divider',this.root);let dragging=false;
    const update=clientX=>{const rect=this.root.getBoundingClientRect(),percent=Math.max(30,Math.min(70,(clientX-rect.left)/rect.width*100));this.settings={...this.settings,readerSplit:Math.round(percent)};this.applySettings();};
    divider.addEventListener('pointerdown',event=>{dragging=true;divider.setPointerCapture(event.pointerId);document.body.classList.add('reader-resizing');});
    divider.addEventListener('pointermove',event=>{if(dragging)update(event.clientX);});
    const stop=()=>{if(!dragging)return;dragging=false;document.body.classList.remove('reader-resizing');this.hooks.settings?.({readerSplit:this.settings.readerSplit});};
    divider.addEventListener('pointerup',stop);divider.addEventListener('pointercancel',stop);
    divider.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','Home'].includes(event.key))return;event.preventDefault();const percent=event.key==='Home'?50:Math.max(30,Math.min(70,(this.settings.readerSplit || 50)+(event.key==='ArrowRight'?2:-2)));this.settings={...this.settings,readerSplit:percent};this.applySettings();this.hooks.settings?.({readerSplit:percent});});
  }
}
