/** PDF glyph advances, independent of the browser's substitute font. */
export function pdfGlyphMetrics(operators,OPS){
  const fonts=new Map();let font=null;const stack=[];
  for(let i=0;i<operators.fnArray.length;i++){
    const fn=operators.fnArray[i],args=operators.argsArray[i];
    if(fn===OPS.save)stack.push(font);
    else if(fn===OPS.restore)font=stack.pop() ?? null;
    else if(fn===OPS.setFont)font=args[0];
    else if((fn===OPS.showText || fn===OPS.showSpacedText) && font){
      let metrics=fonts.get(font);if(!metrics)fonts.set(font,metrics=new Map());
      for(const glyph of args[0] || [])if(glyph && typeof glyph==='object' && glyph.unicode && glyph.width>0){
        const chars=[...glyph.unicode];
        for(const char of chars)if(!metrics.has(char))metrics.set(char,glyph.width/chars.length);
      }
    }
  }
  return fonts;
}
export function glyphBoundaries(text,metrics){
  if(!metrics)return null;
  const widths=[];
  for(const char of text){
    const width=metrics.get(char) ?? (/\s/u.test(char)?metrics.get(' ') ?? 250:null);
    if(!(width>0))return null;
    for(let i=0;i<char.length;i++)widths.push(width/char.length);
  }
  const total=widths.reduce((a,b)=>a+b,0);if(!total)return null;
  let value=0;return [0,...widths.map(width=>(value+=width)/total)];
}
// Metadata follows the native text node through DOM reordering, not its index.
export const pdfTextGeometry=new WeakMap();
export function registerPdfGeometry(spans,items,fonts){
  for(let i=0;i<items.length;i++){
    const span=spans[i],item=items[i];if(!span?.firstChild || !item.transform)continue;
    const t=item.transform;
    if(item.dir!=='rtl' && Math.abs(t[1])<.001 && Math.abs(t[2])<.001 && item.width>0){
      pdfTextGeometry.set(span.firstChild,{width:item.width,fontHeight:Math.abs(t[3]),boundaries:glyphBoundaries(item.str,fonts?.get(item.fontName))});
    }
  }
}
/** Preserve explicit DOM characters; browsers invent spaces around drop caps. */
export function pdfRangeText(range,root){
  const doc=root.ownerDocument,walker=doc.createTreeWalker(root,5); // elements + text
  const parts=[];let node;
  while((node=walker.nextNode())){
    if(!range.intersectsNode(node))continue;
    if(node.nodeType===3){
      const start=node===range.startContainer?range.startOffset:0;
      const end=node===range.endContainer?range.endOffset:node.length;
      parts.push(node.textContent.slice(start,end));
    }else if(node.tagName==='BR')parts.push('\n');
  }
  return parts.join('').trim();
}

/** Presentation order only: attach raised reference marks to their visual line. */
export function pdfSelectionLines(paragraphs,items){
  const lines=paragraphs.flatMap(p=>p.lines.map((line,index)=>({id:p.id+':'+index,indices:[...line.itemIndices]})));
  for(const mark of lines){
    const visible=mark.indices.filter(i=>items[i]?.str.trim());
    if(visible.length!==1 || !/^[*†‡§\d]+$/u.test(items[visible[0]].str))continue;
    const m=items[visible[0]],mt=m.transform,mh=Math.abs(mt[3]);let match=null,distance=Infinity;
    for(const line of lines){
      if(line===mark)continue;
      const candidates=line.indices.map(i=>items[i]).filter(i=>i?.str.trim());
      if(!candidates.some(i=>/[a-zA-Z]{2}/.test(i.str)))continue;
      for(const item of candidates){
        const t=item.transform,h=Math.abs(t[3]),dx=mt[4]-(t[4]+item.width),dy=mt[5]-t[5];
        if(mh<h*.95 && dy>=0 && dy<h*.65 && dx>=-h*.1 && dx<h*.6 && dx+dy<distance){match=line;distance=dx+dy;}
      }
    }
    if(match){match.indices.push(...mark.indices);match.indices.sort((a,b)=>items[a].transform[4]-items[b].transform[4]);mark.indices=[];}
  }
  return lines.filter(line=>line.indices.length);
}
