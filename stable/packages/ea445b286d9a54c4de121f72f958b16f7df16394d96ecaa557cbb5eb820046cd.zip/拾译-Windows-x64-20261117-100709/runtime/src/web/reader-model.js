/** Read-only boundary between parsed PDFs, translation DTOs and reader rendering. */
import {translationManifest,matchesSource} from './paragraph-document.js';

const STATES=new Set(['not_started','queued','running','retrying','succeeded','failed','cancelled']);
const own=(value,key)=>Object.prototype.hasOwnProperty.call(value || {},key);
const finite=value=>typeof value==='number' && Number.isFinite(value);
const clonePart=part=>({...part,bbox:part.bbox?.slice(),rect:part.rect?.slice(),lineIds:[...(part.lineIds || [])]});

function matchingVariant(result,options){
  for(const [key,field] of [['source','source_language'],['target','target_language'],['provider','provider'],['model','requested_model']]){
    if(own(options,key) && String(result[field] ?? '')!==String(options[key] ?? ''))return false;
  }
  return true;
}

function sameRevision(result,paragraph,logical,documentId){
  if(result.document_id!==documentId || !matchesSource(result,paragraph))return false;
  // These are all remaining fields included in the backend's source_hash. Do not
  // reimplement its hashing algorithm in the rendering layer.
  for(const key of ['kind','section','reading_order'])if(own(result,key) && result[key]!==paragraph[key])return false;
  const expectedHash=logical.source_hash ?? logical.sourceHash ?? paragraph.source_hash;
  return expectedHash===undefined || result.source_hash===expectedHash;
}

function headingLevel(paragraph){
  if(paragraph.kind==='title')return 1;
  if(paragraph.kind==='subtitle')return 2;
  const numbering=paragraph.text.match(/^\s*(\d+(?:\.\d+)*)(?:[.)]?\s)/);
  return numbering?Math.min(6,numbering[1].split('.').length+1):2;
}

function mappedParagraphs(manifest,translations,options,logicalById,physical){
  const documentId=manifest.document.document_id;
  const rows=translations instanceof Map?[...translations.values()]:Array.isArray(translations)?translations:translations?.items || [];
  const candidates=new Map();
  for(const row of rows){
    if(!row || !matchingVariant(row,options))continue;
    if(!candidates.has(row.paragraph_id))candidates.set(row.paragraph_id,[]);
    candidates.get(row.paragraph_id).push(row);
  }
  return manifest.paragraphs.map(source=>{
    const logical=logicalById.get(source.paragraph_id),parts=logical.parts.map(clonePart);
    const valid=(candidates.get(source.paragraph_id) || []).filter(row=>sameRevision(row,source,logical,documentId));
    // Request completion order does not determine display order or source pairing.
    const result=valid.reduce((latest,row)=>!latest || Number(row.updated || 0)>=Number(latest.updated || 0)?row:latest,null);
    const warnings=(result?.warnings || []).map(warning=>typeof warning==='object'?{...warning}:warning);
    let status=STATES.has(result?.status)?result.status:'not_started';
    let translation=typeof result?.translation==='string'?result.translation:'';
    if(status==='succeeded' && !translation.trim()){
      status='failed';warnings.push({code:'empty-translation',severity:'warning',message:'翻译服务没有返回译文，可重新翻译此段'});
    }
    if(status!=='succeeded')translation='';
    const first=parts[0],original=physical.get(first.pageNumber+':'+first.paragraphId);
    return {id:source.paragraph_id,documentId,text:source.text,kind:source.kind,section:source.section,
      parts,pageNumbers:[...new Set(parts.map(part=>part.pageNumber))].sort((a,b)=>a-b),
      readingOrder:source.reading_order,fontSize:logical.fontSize ?? original?.fontSize,
      sourceParts:source.source_parts,sourceHash:result?.source_hash ?? logical.source_hash ?? logical.sourceHash ?? null,
      translation,translationResult:result,status,warnings,
      needsReview:Boolean(result?.needs_review || warnings.some(warning=>typeof warning==='object' && warning.severity!=='info')),
      error:result?.error || null,continuesAcrossPages:parts.length>1};
  });
}

function parsedOutline(paragraphs){
  return paragraphs.filter(p=>['title','subtitle','heading'].includes(p.kind)).map(p=>({
    id:p.id,text:p.text,level:headingLevel(p),pageNumber:p.pageNumbers[0],source:'parsed'}));
}

/** Text documents use the same source/result contract without fabricating PDF coordinates. */
export function modelFromManifest(manifest,translations=[],{pageNumber=null,options={}}={}){
  if(!manifest)return {documentId:'',blocks:[],paragraphs:[],outline:[]};
  const logicalById=new Map(manifest.paragraphs.map(source=>[source.paragraph_id,{...source,
    parts:source.source_parts.map(part=>({pageNumber:part.page_number,paragraphId:part.paragraph_id,
      bbox:part.bbox,rect:part.rect,lineIds:part.line_ids || []}))}]));
  const allParagraphs=mappedParagraphs(manifest,translations,options,logicalById,new Map());
  const paragraphs=allParagraphs.filter(p=>pageNumber===null || p.pageNumbers.includes(pageNumber));
  const blocks=paragraphs.map(paragraph=>({id:paragraph.id,kind:paragraph.kind,paragraph,
    pageNumber:paragraph.pageNumbers[0],readingOrder:paragraph.readingOrder}));
  return {documentId:manifest.document.document_id,paragraphs,blocks,outline:parsedOutline(allParagraphs)};
}

/**
 * A sparse, immutable view of the currently loaded document window. A logical
 * cross-page paragraph is rendered once; its parts retain every original page.
 * Passing pageNumber selects paragraphs that overlap that page, not just starts.
 */
export function createReaderModel(structure,translations=[],{pageNumber=null,options={}}={}){
  if(!structure)return {documentId:'',blocks:[],paragraphs:[],outline:[]};
  const manifest=translationManifest(structure),documentId=structure.id;
  const logicalById=new Map(structure.paragraphs.map(p=>[p.id,p]));
  const physical=new Map(),blockOrder=new Map();
  for(const page of structure.pages){
    for(const paragraph of page.paragraphs)physical.set(page.pageNumber+':'+paragraph.id,paragraph);
    for(const block of page.blocks || [])for(const id of block.paragraphIds || [])blockOrder.set(page.pageNumber+':'+id,block.readingOrder);
  }
  const allParagraphs=mappedParagraphs(manifest,translations,options,logicalById,physical);
  const outline=parsedOutline(allParagraphs);
  const paragraphs=allParagraphs.filter(p=>pageNumber===null || p.pageNumbers.includes(pageNumber));
  const blocks=paragraphs.map(paragraph=>{
    const part=paragraph.parts.find(part=>part.pageNumber===pageNumber) || paragraph.parts[0];
    const original=physical.get(part.pageNumber+':'+part.paragraphId);
    return {id:paragraph.id,kind:paragraph.kind,paragraph,pageNumber:part.pageNumber,
      bbox:part.bbox?.slice(),rect:part.rect?.slice(),
      readingOrder:blockOrder.get(part.pageNumber+':'+part.paragraphId) ?? original?.readingOrder ?? paragraph.readingOrder};
  });
  for(const page of structure.pages){
    if(pageNumber!==null && page.pageNumber!==pageNumber)continue;
    if(page.classification?.kind==='study-material'){
      blocks.push({id:'material-page-'+page.pageNumber,kind:'original',pageNumber:page.pageNumber,fullPage:true,
        rect:[0,0,page.width,page.height],readingOrder:0,label:'学习材料 · 原始版式',tags:page.classification.tags});continue;
    }
    for(const block of page.blocks || []){
      if(block.kind!=='image' && block.kind!=='table')continue;
      if(block.role==='metadata')continue; // Small header artwork stays available in the original-page preview.
      // Complex tables are preserved as original-PDF regions, never fake cells.
      blocks.push({id:block.id,kind:block.kind==='image'?'image':'original',originalKind:block.kind,
        pageNumber:page.pageNumber,bbox:block.bbox?.slice(),rect:block.rect?.slice(),readingOrder:block.readingOrder});
    }
  }
  blocks.sort((a,b)=>a.pageNumber-b.pageNumber || a.readingOrder-b.readingOrder);
  const currentPage=structure.pages.find(page=>page.pageNumber===pageNumber);
  return {documentId,blocks,paragraphs,outline,materialMode:currentPage?.classification?.kind==='study-material',
    annotated:currentPage?.classification?.kind==='annotated-article'};
}

const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
function validMetrics(metrics){
  return (metrics || []).filter(metric=>metric && typeof metric.id==='string' && finite(metric.top) && finite(metric.height) && metric.height>0)
    .slice().sort((a,b)=>a.top-b.top);
}

/** Capture a paragraph ID and its visible fractional position in content pixels. */
export function captureAnchor(metrics,scrollTop,viewportHeight=0,inset=24){
  const ordered=validMetrics(metrics);if(!ordered.length)return null;
  const offset=finite(inset)?Math.max(0,inset):24;
  const top=(finite(scrollTop)?Math.max(0,scrollTop):0)+Math.min(offset,viewportHeight>0?viewportHeight:offset);
  const metric=ordered.find(metric=>metric.top+metric.height>top) || ordered.at(-1);
  return {id:metric.id,fraction:clamp((top-metric.top)/metric.height,0,1)};
}

/** Resolve the same semantic anchor in a column with different paragraph heights. */
export function anchorScrollTop(anchor,targetMetrics,maxScroll=Infinity,inset=24){
  if(!anchor || typeof anchor.id!=='string')return null;
  const metric=validMetrics(targetMetrics).find(metric=>metric.id===anchor.id);if(!metric)return null;
  const fraction=finite(anchor.fraction)?clamp(anchor.fraction,0,1):0;
  const limit=finite(maxScroll)?Math.max(0,maxScroll):Infinity;
  return clamp(metric.top+metric.height*fraction-(finite(inset)?Math.max(0,inset):24),0,limit);
}

/** Bound dense-page DOM work while keeping a stable-ID navigation target visible. */
export function windowItems(items,anchorId,{before=12,after=24}={}){
  const values=Array.isArray(items)?items:[];
  const count=value=>finite(value)?Math.max(0,Math.floor(value)):0;
  const index=Math.max(0,values.findIndex(item=>item.id===anchorId));
  const start=Math.max(0,index-count(before)),end=Math.min(values.length,index+count(after)+1);
  return {items:values.slice(start,end),start,end,beforeCount:start,afterCount:values.length-end};
}

/** Cancel stale asynchronous page/paragraph locations after a newer user intent. */
export function createNavigationGate(){
  let generation=0;
  return {begin:()=>++generation,isCurrent:ticket=>ticket>0 && ticket===generation,cancel:()=>{generation++;}};
}
