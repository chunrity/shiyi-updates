/** Presentation-only companion sizing. Parsing and translation are not involved. */
export const COMPANION_WIDTH={default:400,min:320,max:480,main:480};
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
export function companionWidth(value){return Number.isFinite(value)?Math.round(clamp(value,320,480)):400;}
export function companionBounds(space,gap=16){
  space=Math.max(0,space);gap=Math.max(0,gap);
  const overlay=space<COMPANION_WIDTH.main+gap+COMPANION_WIDTH.min;
  const max=Math.max(0,Math.min(480,overlay?Math.min(400,space-24,Math.max(320,space-360)):space-gap-COMPANION_WIDTH.main));
  return {overlay,min:Math.min(320,max),max};
}

export function recommendedCompanionWidth(space,viewportWidth,mode='pdf',gap=16){
  const b=companionBounds(space,gap);
  const desired=400+((Number.isFinite(viewportWidth)?viewportWidth:1200)-1200)/20;
  // Reserve more room for both text columns when recommending a split-view width.
  const main=mode==='split'?640:COMPANION_WIDTH.main;
  const max=b.overlay?b.max:Math.max(b.min,Math.min(b.max,space-gap-main));
  return Math.round(clamp(Math.round(desired/4)*4,b.min,max));
}

export class CompanionPanel{
  constructor({workspace,panel,handle,recommend,settings,save,error=()=>{}}){
    Object.assign(this,{workspace,panel,handle,recommendButton:recommend,settings,save,error});
    this.preferred=400;this.drag=null;this.frame=0;this.saveQueue=Promise.resolve();
    if(!workspace || !panel || !handle)return;
    recommend?.addEventListener('click',()=>this.recommend());
    handle.addEventListener('pointerdown',event=>{
      if(event.button!==0 || event.isPrimary===false || this.drag)return;
      event.preventDefault();this.begin();this.drag={pointer:event.pointerId,x:event.clientX,width:this.width,previous:this.preferred};
      handle.setPointerCapture(event.pointerId);
    });
    handle.addEventListener('pointermove',event=>{
      if(!this.drag || this.drag.pointer!==event.pointerId)return;
      this.preview=this.drag.width+this.drag.x-event.clientX;this.schedule();
    });
    handle.addEventListener('pointerup',event=>{if(this.drag?.pointer===event.pointerId)this.finish(true);});
    handle.addEventListener('pointercancel',()=>this.finish(false));
    handle.addEventListener('lostpointercapture',()=>{if(this.drag)this.finish(false);});
    handle.addEventListener('keydown',event=>{
      if(event.key==='Escape' && this.drag){event.preventDefault();this.finish(false);return;}
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
      event.preventDefault();event.stopPropagation();
      if(!this.drag){this.begin();this.drag={pointer:null,previous:this.preferred,width:this.width};}
      const b=this.bounds(),step=event.shiftKey?32:16;
      this.preview=event.key==='Home'?b.min:event.key==='End'?b.max:this.width+(event.key==='ArrowLeft'?step:-step);
      this.render();clearTimeout(this.keyTimer);this.keyTimer=setTimeout(()=>this.finish(true),250);
    });
    handle.addEventListener('keyup',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key) && this.drag?.pointer===null)this.finish(true);});
    window.addEventListener('blur',()=>{this.finish(false);this.endRecommendation();});
    window.addEventListener('pagehide',()=>{this.finish(false);this.endRecommendation();});
    if(typeof ResizeObserver!=='undefined'){
      this.observer=new ResizeObserver(()=>this.schedule());this.observer.observe(workspace);this.observer.observe(panel);
    }else window.addEventListener('resize',()=>this.schedule());
    this.update();
  }
  bounds(){return companionBounds(this.workspace.clientWidth,parseFloat(getComputedStyle(this.workspace).columnGap)||16);}
  recommended(){return recommendedCompanionWidth(this.workspace.clientWidth,window.innerWidth,this.settings().readerMode,parseFloat(getComputedStyle(this.workspace).columnGap)||16);}
  update(){
    if(!this.workspace)return;
    const s=this.settings();if(!this.drag)this.preferred=this.pendingWidth ?? companionWidth(s.companionWidth);
    // Reuse the existing typography controls, at a comfortable sidebar scale.
    const sizes={'--companion-en-size':Math.max(12,(s.readerEnglishSize || 18)-3)+'px',
      '--companion-zh-size':Math.max(12,(s.readerChineseSize || 18)-2)+'px'};
    for(const [key,value] of Object.entries(sizes))if(this.panel.style.getPropertyValue(key)!==value)this.panel.style.setProperty(key,value);
    this.schedule();
  }
  schedule(){if(this.frame)return;this.frame=requestAnimationFrame(()=>{this.frame=0;this.render();});}
  render(){
    if(!this.workspace || !this.workspace.clientWidth){if(this.handle)this.handle.hidden=true;return;}
    const b=this.bounds();let target=this.drag?this.preview ?? this.width:this.preferred,done=false;
    if(this.recommending){
      const t=this.recommending.duration?Math.min(1,(performance.now()-this.recommending.started)/this.recommending.duration):1;
      target=this.recommending.from+(target-this.recommending.from)*(1-(1-t)**3);done=t>=1;if(!done)this.schedule();
    }
    this.width=Math.round(clamp(target,b.min,b.max));
    const value=this.width+'px';if(this.workspace.style.getPropertyValue('--companion-width')!==value)this.workspace.style.setProperty('--companion-width',value);
    const overlay=String(b.overlay);if(this.workspace.dataset.companionOverlay!==overlay)this.workspace.dataset.companionOverlay=overlay;
    if(this.recommendButton){
      const next=this.recommended(),current=this.preferred===next && this.width===next && !this.drag;
      this.recommendButton.dataset.recommended=String(current);
      this.recommendButton.title='推荐 '+next+' 像素；当前 '+this.width+' 像素。点击应用，拖动可自定义';
    }
    const visible=this.panel.getClientRects().length>0 && getComputedStyle(this.panel).display!=='none';
    this.handle.hidden=!visible;this.handle.tabIndex=visible?0:-1;
    for(const [key,value] of Object.entries({'aria-valuemin':Math.round(b.min),'aria-valuemax':Math.round(b.max),'aria-valuenow':this.width,'aria-valuetext':this.width+' 像素'})){
      if(this.handle.getAttribute(key)!==String(value))this.handle.setAttribute(key,String(value));
    }
    if(done)this.endRecommendation();
  }
  endRecommendation(notify=true){
    if(!this.recommending)return;
    this.recommending=null;document.body.classList.remove('companion-recommending','companion-resizing');
    if(notify)this.workspace.dispatchEvent(new CustomEvent('companion-resize-end',{bubbles:true}));
  }
  recommend(){
    if(this.drag || this.recommending)return;
    const next=companionWidth(this.recommended()),from=this.width;
    if(this.preferred===next)return;
    this.preferred=next;
    if(from!==next){
      this.begin();document.body.classList.add('companion-recommending');
      this.recommending={from,started:performance.now(),duration:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?0:140};
    }
    this.persist(next);this.schedule();
  }
  persist(next){
    // The button and the accepted drag gesture share the same width and write queue.
    if(this.pendingWidth===next)return;
    this.pendingWidth=next;const ticket={width:next};this.pendingWrite=ticket;
    this.saveQueue=this.saveQueue.catch(()=>{}).then(()=>this.save(next)).then(()=>{
      if(this.pendingWrite===ticket){this.pendingWrite=null;this.pendingWidth=null;}this.update();
    }).catch(error=>{if(this.pendingWrite===ticket){this.pendingWrite=null;this.pendingWidth=null;this.update();this.error(error);}});
  }
  begin(){
    this.endRecommendation(false);
    clearTimeout(this.keyTimer);document.body.classList.add('companion-resizing');
    this.workspace.dispatchEvent(new CustomEvent('companion-resize-start',{bubbles:true}));
  }
  finish(commit){
    if(!this.drag)return;
    clearTimeout(this.keyTimer);if(this.frame){cancelAnimationFrame(this.frame);this.frame=0;}this.render();
    const drag=this.drag,changed=this.width!==drag.width,next=changed?companionWidth(this.width):drag.previous;this.drag=null;this.preview=null;
    this.preferred=commit?next:drag.previous;document.body.classList.remove('companion-resizing');
    if(drag.pointer!==null && this.handle.hasPointerCapture(drag.pointer))this.handle.releasePointerCapture(drag.pointer);
    this.render();this.workspace.dispatchEvent(new CustomEvent('companion-resize-end',{bubbles:true}));
    if(commit && changed && (next!==companionWidth(this.settings().companionWidth) || this.pendingWidth!=null && this.pendingWidth!==next)){
      // One local save per completed gesture; never one save per pointermove.
      this.persist(next);
    }
  }
}
