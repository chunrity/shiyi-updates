param([int]$Left, [int]$Top, [int]$Width, [int]$Height, [string]$ImagePath = '', [switch]$AsJson)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$awaitMethod = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
function Await-Result($Operation, $ResultType) {
    $task = $awaitMethod.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
    $task.GetAwaiter().GetResult()
}
if ($ImagePath) {
    $bitmap = [System.Drawing.Bitmap]::new($ImagePath)
} else {
    $bitmap = [System.Drawing.Bitmap]::new($Width,$Height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.CopyFromScreen($Left,$Top,0,0,$bitmap.Size)
    $graphics.Dispose()
}
if ([Math]::Max($bitmap.Width,$bitmap.Height) -gt 2500) {
    $ratio = 2500.0 / [Math]::Max($bitmap.Width,$bitmap.Height)
    $resized = [System.Drawing.Bitmap]::new($bitmap,[System.Drawing.Size]::new([int]($bitmap.Width*$ratio),[int]($bitmap.Height*$ratio)))
    $bitmap.Dispose(); $bitmap = $resized
}
$imageWidth = $bitmap.Width; $imageHeight = $bitmap.Height
$memory = [System.IO.MemoryStream]::new()
$bitmap.Save($memory,[System.Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()
$stream = [Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
$writer = [Windows.Storage.Streams.DataWriter]::new($stream)
$writer.WriteBytes($memory.ToArray())
$null = Await-Result ($writer.StoreAsync()) ([uint32])
$null = $writer.DetachStream()
$stream.Seek(0)
$decoder = Await-Result ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$software = Await-Result ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US'))
if ($null -eq $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if ($null -eq $engine) { throw 'OCR language pack unavailable' }
$result = Await-Result ($engine.RecognizeAsync($software)) ([Windows.Media.Ocr.OcrResult])
if ($AsJson) {
    $lines = @($result.Lines | ForEach-Object {
        @{ text=$_.Text; words=@($_.Words | ForEach-Object {
            @{text=$_.Text;x=$_.BoundingRect.X;y=$_.BoundingRect.Y;width=$_.BoundingRect.Width;height=$_.BoundingRect.Height}
        }) }
    })
    [Console]::Write((@{text=$result.Text;lines=$lines;width=$imageWidth;height=$imageHeight;available=$true} | ConvertTo-Json -Depth 8 -Compress))
} else { [Console]::Write($result.Text) }
$software.Dispose(); $stream.Dispose(); $memory.Dispose()
